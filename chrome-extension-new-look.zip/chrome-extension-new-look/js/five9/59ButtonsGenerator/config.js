export const defaultButtons = [
  {
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "LEADS",
    "main": true,
    "bgColor": "#9edf7f",
    "textColor": "#000000",
    "fontSize": "16",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "IN RANGE \n LIVE TFR 💰",
    "parentButton": "LEADS",
    "keyword": "IN RANGE Live Transfer - Agent",
    "bgColor": "#55f231",
    "textColor": "black",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "IN RANGE\n WEB FORM 🤑",
    "parentButton": "LEADS",
    "keyword": "IN RANGE Web Form - Agent",
    "bgColor": "#55f231",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "ABOVE RANGE \n👍🏼",
    "parentButton": "LEADS",
    "keyword": "Above Range Web Form - Agent",
    "bgColor": "#eee496",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "FULL RETAIL\n👌🏼",
    "parentButton": "LEADS",
    "keyword": "Full Retail Web Form - Agent",
    "bgColor": "#ec7f4d",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "CREATIVE\n IN RANGE 🤑",
    "parentButton": "LEADS",
    "keyword": "Creative InRange 20 Less - Agent",
    "bgColor": "#9edf7f",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "CREATIVE\n ABOVE 👍🏼",
    "parentButton": "LEADS",
    "keyword": "Creative AboveRange 21 Over - Agent",
    "bgColor": "#9edf7f",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "ALREADY\n✓SENT✓",
    "parentButton": "LEADS",
    "keyword": "Already SENT - Agent",
    "bgColor": "#999999",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "NOT AVAILABLE HUMAN [H]",
    "main": true,
    "keyword": "Not Available Human - Agent",
    "bgColor": "#0AB4E3",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "NOT AVAILABLE MACHINE [M]",
    "main": true,
    "keyword": "Not Available Machine - Agent",
    "bgColor": "#C5D0D3",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "VOICEMAIL [V]",
    "main": true,
    "keyword": "Voicemail - Agent",
    "bgColor": "#B4C307 ",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "WRONG NUMBER [W]",
    "main": true,
    "keyword": "Wrong Number - Agent",
    "bgColor": "#B4742A",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "RIGHT NAME \nWRONG HOME",
    "main": true,
    "keyword": "Right Name -  Wrong Home - Agent",
    "bgColor": "#c91d59",
    "textColor": "#ffffff",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "NOT INTERESTED [N]",
    "main": true,
    "keyword": "Not Interested - Agent",
    "bgColor": "#D73D33",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "CALLBACK [C]",
    "main": true,
    "keyword": "Callback - Agent",
    "bgColor": "#165F95",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "MLS\nLISTED [L]",
    "main": true,
    "keyword": "Listed on MLS - Agent",
    "bgColor": "#691DE5",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "SOLD\nHOME [S]",
    "main": true,
    "keyword": "Already Sold Home - Agent",
    "bgColor": "#4EA525",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "DNC",
    "main": true,
    "bgColor": "#D21844",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "NOT\nINTERESTED",
    "parentButton": "DNC",
    "keyword": "DNC Not Interested - Agent",
    "bgColor": "#D21844",
    "textColor": "white",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "WRONG NUMBER",
    "parentButton": "DNC",
    "keyword": "DNC Wrong Number - Agent",
    "bgColor": "#D21844",
    "textColor": "white",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "DNC ROBOKILLER🤖",
    "parentButton": "DNC",
    "keyword": "DNC Robokiller - Agent",
    "bgColor": "#d21844",
    "textColor": "#ffffff",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "DEAD PERSON",
    "parentButton": "DNC",
    "keyword": "Dead Person - Agent",
    "bgColor": "#D21844",
    "textColor": "white",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "FR OVER RANGE\n😵‍💫",
    "main": true,
    "keyword": "FR OVER RANGE - Agent",
    "bgColor": "#ec7f4d",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "VOICE BREAKING-UP",
    "main": true,
    "keyword": "Voice Breaking Up - Agent",
    "bgColor": "#691DE5",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  }
]


export const buttons = JSON.parse(JSON.stringify(defaultButtons));

  export const addStyles = () => {
    const css = `
      #dispoContainer { display: flex; align-items: initial; justify-content: center; flex-wrap: wrap; background-color: #f2f2f2; }
      .dispo_main_button { margin: 1em 0; padding: 0 10px; cursor: pointer; position: relative; }
      .dispo_sub_button { display: none; position: relative; }
      .dispo_main_button:hover .dispo_sub_button, .dispo_main_button:focus .dispo_sub_button { display: block; padding-top: 3px; }
      .button-label { display: flex; align-items: center; justify-content: center; height: 100%; width: 100%; white-space: pre-wrap; text-align: center; font-family: Arial, sans-serif; }
    `;
    const style = document.createElement('style');
    style.appendChild(document.createTextNode(css));
    document.head.appendChild(style);
  };
  
  
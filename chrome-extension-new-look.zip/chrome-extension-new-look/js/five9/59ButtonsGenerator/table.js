//table.js
import { buttons } from "./config.js";

function createDataTable() {
  const table = document.createElement("table");
  table.id = "dataTable";
  table.classList.add("display");

  const thead = document.createElement("thead");
  const tr = document.createElement("tr");

  ["LABEL", "MAIN", "parentButton", "BG COLOR", "Text Color", "Font Size", "Font Weight"].forEach((headerText) => {
    const th = document.createElement("th");
    th.innerText = headerText;
    tr.appendChild(th);
  });

  thead.appendChild(tr);
  table.appendChild(thead);
  document.querySelector('.container').appendChild(table);
}

function updateDataTable() {
  const table = $("#dataTable").DataTable();
  table.clear();

  buttons.forEach((button) => {
    table.row.add([
      button.label || null,
      button.main ? "Yes" : "No",
      button.parentButton || null, // Use null instead of an empty string for undefined values
      button.bgColor || null,
      button.textColor || null,
      button.fontSize || null,
      button.fontWeight || null,
    ]);
  });

  table.draw();
}

function initializeDataTable() {
  createDataTable();
  $(document).ready(() => {
    $("#dataTable").DataTable({
      data: buttons.slice(1).map((button) => [ // Filter out the first element using slice(1)
        button.label,
        button.main ? "Yes" : "No",
        button.parentButton || "", 
        button.bgColor || "",
        button.textColor || "",
        button.fontSize || "",
        button.fontWeight || "",
      ]),
      columns: [
        { title: "LABEL" },
        { title: "MAIN" },
        { title: "parentButton" },
        { title: "BG COLOR" },
        { title: "Text Color" },
        { title: "Font Size" },
        { title: "Font Weight" },
      ],
      paging: false,
      ordering: false,
    });
  });
}


export { updateDataTable, initializeDataTable };

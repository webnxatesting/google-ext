document.addEventListener('DOMContentLoaded', () => {
    const tourBtn = document.getElementById('tour-btn');
  
    tourBtn.addEventListener('click', () => {
      startTour();
    });
  });
  
  function startTour() {
    introJs().setOptions({
      steps: [
        { title: 'Welcome to the Five9 Disposition Buttons Builder',
          intro: 'Part of the 59 Chrome Addon Suite',
        },
        {
          element: '#dispoContainer',
          title: 'Preview Section',
          intro: 'Preview the final look of the buttons as you edit them. \n Press and hold the RIGHT CLICK to clone a button. \n Press and hold the LEFT CLICK to remove a button.',
        },
        {
          element: '#label',
          title: 'Label',
          intro: 'Give it a name to the button.',
        },
        {
          element: '#newButtonForm > div:nth-child(1) > label:nth-child(3)',
          title: 'Is it a Main button?',
          intro: 'Hit check if the button is a main button. Leave unchecked if it is a sub-button.',
        },
        {
          element: '#parentButton',
          title: 'Parent Button',
          intro: 'To create a Sub-Button, choose the Main Button Parent',
        },
        {
          element: '#keyword',
          title: 'Five9 Disposition Names',
          intro: 'The Five9 dispositions names. Make it exactly as they appear on Five9.',
        },
        {
          element: '#generatedCode',
          title: 'Generated Code',
          intro: 'The generated code to use in the 59 Chrome Extension Suite',
        }
      ]
    }).start();
  }
  
// main.js
import { addStyles, buttons } from "./config.js";
import {
  createSVGButton,
  addButtonEventListener,
  initDispositions,
  createNewButton,
} from "./uiModule1.js";
import { updateTextArea } from "./generatedCode.js";
import "./generatedCode.js";
//import { initializeDataTable, updateDataTable } from "./table.js";

export function updateParentLabelDropdown() {
  const parentButtonSelect = document.querySelector("#parentButton");
  parentButtonSelect.innerHTML = "";
  buttons
    .filter((button) => button.main)
    .forEach((button) => {
      var option = document.createElement("option");
      option.value = button.label;
      option.textContent = button.label;
      parentButtonSelect.appendChild(option);
    });
}

function loadButtons() {
  document.addEventListener("DOMContentLoaded", () => {
    // Check if Five9BtnsCode_003 is available in the chrome.storage.local
    chrome.storage.local.get("Five9BtnsCode_003", (data) => {
      let loadedButtons = buttons;
      if (data.Five9BtnsCode_003) {
        try {
          loadedButtons = JSON.parse(data.Five9BtnsCode_003);
        } catch (error) {
          console.error("Error parsing Five9BtnsCode_003:", error);
        }
      }

      // Initialize the dispositions with loadedButtons
      initDispositions(loadedButtons);
      updateParentLabelDropdown();
      //initializeDataTable(); 
    });
  });
}

addStyles();
loadButtons();

document.getElementById("newButtonForm").addEventListener("submit", (event) => {
  event.preventDefault();
  event = event.target;
  const newButton = createNewButton(event);
  buttons.push(newButton);
  var parent = newButton.main
    ? document.getElementById("dispoContainer")
    : buttons.find((button) => button.label === newButton.parentButton).element;
  var clazz = newButton.main ? "dispo_main_button" : "dispo_sub_button";
  clazz = createSVGButton(newButton, clazz, parent);
  newButton.element = clazz;
  newButton.keyword && addButtonEventListener(clazz, newButton.keyword);
  newButton.main && updateParentLabelDropdown();
  updateTextArea();
  //updateDataTable(); 
});

const widthInput = document.getElementById("width");
const heightInput = document.getElementById("height");

function updateButtonPreview() {
  const previewButton = document.querySelector("#previewButton");
  if (previewButton) {
    previewButton.setAttribute("width", widthInput.value);
    previewButton.setAttribute("height", heightInput.value);
  }

  // Update the width and height of the buttons in the buttons array
  buttons.forEach((button) => {
    button.buttonsWidth = parseInt(widthInput.value);
    button.buttonsHeight = parseInt(heightInput.value);
  });
  // Update the dispositions container to reflect the new dimensions
  initDispositions(buttons);
  // Update the generated code textarea
  updateTextArea(); // Add this line
}

widthInput.addEventListener("input", updateButtonPreview);
heightInput.addEventListener("input", updateButtonPreview);

//spectrum code jQuery code
$(document).ready(function () {
  $(".spectrum").spectrum({
    preferredFormat: "hex",
    showInput: true,
    showPalette: true,
    showSelectionPalette: true,
    maxSelectionSize: 10,
    palette: [
      ["#000", "#444", "#666", "#999", "#ccc", "#eee", "#f3f3f3", "#fff"],
      ["#4EA525", "#f90", "#3D88BF", "#75B211", "#A4A703", "#687751", "#4C6363", "#E5DE2A"],
      [
        "#f4cccc",
        "#fce5cd",
        "#fff2cc",
        "#d9ead3",
        "#d0e0e3",
        "#cfe2f3",
        "#d9d2e9",
        "#ead1dc",
      ],
    ],
  });
});

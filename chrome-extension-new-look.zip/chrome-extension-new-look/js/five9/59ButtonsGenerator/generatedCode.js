//generatedCode.js
import { updateParentLabelDropdown } from './main.js';
import { buttons, defaultButtons } from './config.js';
import { initDispositions } from './uiModule1.js';

// Extracts the version from the manifest description
function extractVersionFromDescription(description) {
    const versionPattern = /five9_buttons: ##Version:(\d+\.\d+)/;
    const matches = description.match(versionPattern);
    return matches ? parseFloat(matches[1]) : 0;
}


// Load and check version
function checkAndUpdateVersion() {
    const description = chrome.runtime.getManifest().description;
    const manifestVersion = extractVersionFromDescription(description);
    console.log(manifestVersion);

    chrome.storage.local.get(['version', 'Five9BtnsCode_003'], (result) => {
        const storageVersion = parseFloat(result.version || '0');

        if (manifestVersion > storageVersion || !result.Five9BtnsCode_003) {
            // Set buttons to default and update local storage
            const defaultButtonsCode = JSON.stringify(defaultButtons, null, 2);
            chrome.storage.local.set({
                'Five9BtnsCode_003': defaultButtonsCode,
                'version': manifestVersion.toString()
            });
            loadStoredCode();
        } else {
            loadStoredCode();
        }
    });
}

checkAndUpdateVersion();

function loadStoredCode() {
    chrome.storage.local.get('Five9BtnsCode_003', (result) => {
        if (result.Five9BtnsCode_003) {
            if (updateButtonsArray(result.Five9BtnsCode_003)) {
                const dispoContainer = document.getElementById("dispoContainer");
                initDispositions(buttons, dispoContainer.parentElement);
            } else {
                initDispositions(buttons);
            }
            updateTextArea();
        } else {
            initDispositions(buttons);
            updateTextArea();
        }
    });
}
loadStoredCode();

export function updateTextArea() {
    const clonedButtons = JSON.parse(JSON.stringify(buttons)); // Create a deep copy of the buttons array

    // Remove the 'element' property from each button object in the clonedButtons array
    clonedButtons.forEach(button => {
        delete button.element;
    });

    const code = JSON.stringify(clonedButtons, null, 2);
    const generatedCodeTextarea = document.getElementById('generatedCode');
    generatedCodeTextarea.value = code;
}

function updateButtonsArray(text) {
    try {
        const newButtons = JSON.parse(text);
        buttons.forEach((button) => {
            if (button.element) {
                button.element.remove();
            }
        });
        buttons.length = 0;
        buttons.push(...newButtons);
        updateParentLabelDropdown();
        initDispositions(buttons);
        //updateDataTable(); comment out to make it work on the Chrome Extension
        updateTextArea();
        return true;
    } catch (error) {
        console.error('Error parsing textarea content:', error);
        return false;
    }
}

function updateParentLabels() {
    const codeTextArea = document.getElementById('generatedCode');
    const modifiedButtons = JSON.parse(codeTextArea.value);
    modifiedButtons.forEach((modifiedButton, index) => {
      const originalButton = buttons[index];
  
      // Check if the main button label has changed
      if (modifiedButton.main && originalButton.label !== modifiedButton.label) {
        const oldLabel = originalButton.label;
        const newLabel = modifiedButton.label;
  
        // Update the parentButton of the other objects
        modifiedButtons.forEach((button) => {
          if (button.parentButton === oldLabel) {
            button.parentButton = newLabel;
          }
        });
  
        // Update the visual appearance of the children buttons
        buttons.forEach((button) => {
          if (button.parentButton === oldLabel) {
            button.parentButton = newLabel;
            const buttonLabel = button.element.querySelector(".button-label");
            const newText = buttonLabel.innerText.replace(oldLabel, newLabel);
            buttonLabel.innerText = newText;
          }
        });
  
        // Update the original button label
        originalButton.label = newLabel;
  
        // Preserve the cursor position
        const cursorStart = codeTextArea.selectionStart;
        const cursorEnd = codeTextArea.selectionEnd;
  
        // Update the text area with the modified buttons
        codeTextArea.value = JSON.stringify(modifiedButtons, null, 2);
  
        // Restore the cursor position
        codeTextArea.setSelectionRange(cursorStart, cursorEnd);
      }
    });
  }
  

const codeTextArea = document.getElementById('generatedCode');
codeTextArea.addEventListener('input', updateParentLabels);

const saveButton = document.getElementById('saveButton');
setTimeout(() => {
    saveButton.click();
}, 1500);
saveButton.addEventListener('click', () => {
    const text = codeTextArea.value;
    if (updateButtonsArray(text)) {
        const dispoContainer = document.getElementById("dispoContainer");
        initDispositions(buttons, dispoContainer.parentElement);
        updateTextArea();
        
        // Update the chrome.storage.local item with the new text
        chrome.storage.local.set({'Five9BtnsCode_003': text});
    } else {
        initDispositions(buttons);
    }
});
updateTextArea();

function resetToDefault() {
    // Reset the buttons array to the default values from config.js
    const defaultButtonsCopy = JSON.parse(JSON.stringify(defaultButtons));
    buttons.length = 0;
    buttons.push(...defaultButtonsCopy);
  
    // Update the textarea and dispoContainer
    updateTextArea();
    const dispoContainer = document.getElementById("dispoContainer");
    initDispositions(buttons, dispoContainer.parentElement);
  
    // Update the chrome.storage.local item with the default buttons code
    const defaultButtonsCode = JSON.stringify(defaultButtons, null, 2);
    chrome.storage.local.set({ 'Five9BtnsCode_003': defaultButtonsCode });
  }

const resetButton = document.getElementById('resetButton');
resetButton.addEventListener('click', resetToDefault);

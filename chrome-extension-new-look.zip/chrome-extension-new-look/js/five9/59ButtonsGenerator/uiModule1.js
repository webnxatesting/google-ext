// uiModule1.js
import { buttons } from "./config.js";
import { initDispositions } from "./uiModule2.js";
import { updateTextArea } from "./generatedCode.js";
const EmojiMart = window.EmojiMart;
function createSVGButton(options, clazz, parent) {
  const { buttonsWidth: width = 93, buttonsHeight: height = 32 } = buttons[0];
  const button = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  button.setAttribute("width", width);
  button.setAttribute("height", height);

  if (options.label) {
    button.innerHTML = `
      <rect width="${width}" height="${height}" fill="${options.bgColor}"></rect>
      <foreignObject x="0" y="0" width="${width}" height="${height}">
        <div class="button-label" style="font-size: ${options.fontSize}px; font-weight: ${options.fontWeight}; color: ${options.textColor};">${options.label.toUpperCase()}</div>
      </foreignObject>`;
  }

  const div = document.createElement("div", { is: "custom-div" });
  div.appendChild(button);
  div.className = clazz;
  parent && parent.appendChild(div);

  if (clazz !== "preview-button") {
    div.addEventListener("dblclick", () => createLightbox(options));
  }
  return div;
}

function addButtonEventListener(button, keyword) {
  button.addEventListener("click", () => console.log(`Keyword: ${keyword}`));
}

function createNewButton(form) {
  const formData = new FormData(form);
  return Object.fromEntries(formData.entries());
}

function updateButton(button) {
  const svg = button.element.querySelector("svg");
  const rect = svg.querySelector("rect");
  const div = svg.querySelector(".button-label");

  rect.setAttribute("fill", button.bgColor);
  div.style.color = button.textColor;
  div.style.fontSize = `${button.fontSize}px`;

  updateTextArea();
}

let openedLightboxes = [];

function rgbToHex(rgb) {
  const match = rgb.match(/(\d+)/g);
  return match ? `#${((1 << 24) + (Number(match[0]) << 16) + (Number(match[1]) << 8) + Number(match[2])).toString(16).slice(1)}` : rgb;
}

function createElement(type, className, id) {
  const element = document.createElement(type);
  if (className) element.className = className;
  if (id) element.id = id;
  return element;
}

function createFontSizeInput(button, value, onInput) {
  const fontSizeDiv = createElement("div", null, "setFontSize");
  const fontSizeLabel = createElement("label");
  fontSizeLabel.setAttribute("for", "setFontSizeInput");
  fontSizeLabel.innerText = "Font Size: ";

  const fontSizeInput = createElement("input", null, "setFontSizeInput");
  Object.assign(fontSizeInput, { type: "number", name: "width", value, min: 1, style: "width: 3em;" });

  fontSizeInput.addEventListener("input", () => {
    const newSize = fontSizeInput.value;
    onInput(newSize);
    button.fontSize = newSize;
    updateTextArea();
  });

  fontSizeDiv.append(fontSizeLabel, fontSizeInput);
  return fontSizeDiv;
}
function createLabelPreviewInput(button, onInput) {
  const labelPreviewDiv = createElement("div", null, "setLabel");
  const labelPreviewLabel = createElement("label");
  labelPreviewLabel.setAttribute("for", "labelPreviewInput");
  labelPreviewLabel.innerText = "Label: ";

  const labelPreviewInput = createElement("input", null, "labelPreviewInput");
  Object.assign(labelPreviewInput, { type: "text", value: button.label, style: "width: 30em;"});

  labelPreviewInput.addEventListener("input", () => {
    const newLabel = labelPreviewInput.value;
    onInput(newLabel);

    // Save the old label before updating the button's label
    const oldLabel = button.label;
    button.label = newLabel;

    // Update main buttons and sub buttons' parentButton labels if button is a main button
    if (button.main) {
      buttons.forEach((btn) => {
        if (btn.parentButton === oldLabel) {
          const btnLabel = btn.element.querySelector(".button-label");
          const newText = btnLabel.innerText.replace(oldLabel, newLabel);
          btnLabel.innerText = newText;
          btn.parentButton = newLabel;
        }
      });
    }

    updateTextArea();
  });

   // Create an EmojiPicker container element
   const emojiPickerContainer = createElement("div", null, "emojiPickerContainer");

   // Create a new EmojiPicker instance
   const pickerOptions = {
     onEmojiSelect: (emoji) => {
       labelPreviewInput.value += emoji.native;
       labelPreviewInput.dispatchEvent(new Event("input"));
     },
   };
   const picker = new EmojiMart.Picker(pickerOptions);
 
   // Append the EmojiPicker to the container and then to the labelPreviewDiv
   emojiPickerContainer.appendChild(picker);
   labelPreviewDiv.append(labelPreviewLabel, labelPreviewInput, emojiPickerContainer);
 
  return labelPreviewDiv;
}


function createLightbox(button) {
  const lightbox = createElement("div", "lightbox");
  lightbox.addEventListener("click", (e) => e.target === lightbox && closeLightbox(lightbox));
  const lightboxContent = createElement("div", "lightbox-content");
  const buttonLabel = button.element.querySelector(".button-label");
  const buttonLabelColor = window.getComputedStyle(buttonLabel).color;
  const bgColorPicker = createElement("input", "spectrum", "bgColorPicker");
  Object.assign(bgColorPicker, { type: "color", value: button.bgColor });

  const textColorPicker = createElement("input", "spectrum", "textColorPicker");
  Object.assign(textColorPicker, { type: "color", value: rgbToHex(buttonLabelColor) });

  lightboxContent.append(bgColorPicker, textColorPicker);

  const livePreview = createSVGButton(button, "preview-button", lightboxContent);
  livePreview.innerHTML = button.element.innerHTML;

  const updatePreview = (selector, attribute, value) => livePreview.querySelector(selector).setAttribute(attribute, value);

  bgColorPicker.addEventListener("input", () => {
    updatePreview("rect", "fill", bgColorPicker.value);
    button.bgColor = bgColorPicker.value;
    updateButton(button);
  });

  textColorPicker.addEventListener("input", () => {
    updatePreview(".button-label", "style", `color: ${textColorPicker.value}`);
    button.textColor = textColorPicker.value;
    updateButton(button);
  });

  const fontSizeInput = createFontSizeInput(button, button.fontSize, (newSize) => {
    livePreview.querySelector(".button-label").style.fontSize = `${newSize}px`;
    button.fontSize = newSize;
    updateButton(button);
  });

  lightboxContent.appendChild(fontSizeInput);

  const labelPreviewInputDiv = createLabelPreviewInput(button, (newLabel) => {
    livePreview.querySelector(".button-label").innerText = newLabel;
    buttonLabel.innerText = newLabel;
  });
  lightboxContent.appendChild(labelPreviewInputDiv);

  const saveButton = createElement("button");
  saveButton.innerText = "Save";
  saveButton.addEventListener("click", () => {
    button.fontSize = fontSizeInput.querySelector("#setFontSizeInput").value;
    Object.assign(button, { bgColor: bgColorPicker.value, textColor: textColorPicker.value });
    updateButton(button);
    closeLightbox(lightbox);
    updateTextArea();
  });

  lightboxContent.appendChild(saveButton);
  lightbox.appendChild(lightboxContent);
  document.body.appendChild(lightbox);

  openedLightboxes.push(lightbox);

  if (openedLightboxes.length > 1) {
    const secondLightbox = openedLightboxes.pop();
    secondLightbox.querySelector("button").click();
  }
}

function closeLightbox(lightbox) {
  lightbox.remove();
  openedLightboxes = openedLightboxes.filter((item) => item !== lightbox);
}

export { createSVGButton, addButtonEventListener, initDispositions, createNewButton, createLightbox };




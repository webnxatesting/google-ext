import { updateParentLabelDropdown } from "./main.js";
import { updateTextArea } from "./generatedCode.js";
import { updateDataTable } from './table.js';
import { buttons } from "./config.js";
import { createSVGButton, addButtonEventListener, createLightbox } from './uiModule1.js';

class CustomDiv extends HTMLDivElement {
    constructor() {
      super();
    }
  
    connectedCallback() {
      this.addEventListener("mousedown", event => {
        if (event.button === 2) {
          this.startCloneTimer(event);
        } else {
          this.startHoldTimer(event);
        }
      });
  
      this.addEventListener("mouseup", event => {
        this.cancelHoldTimer(event);
        this.cancelCloneTimer(event);
      });
  
      this.addEventListener("mouseleave", event => {
        this.cancelHoldTimer(event);
        this.cancelCloneTimer(event);
      });
  
    }
  
    startHoldTimer(event) {
      event.preventDefault();
      event.stopPropagation();
  
      this.holdTimeout = setTimeout(() => {
        this.deleteButton();
      }, 1500); // 1.5 seconds
  
      this.showProgressBar();
    }
  
    startCloneTimer(event) {
        event.preventDefault();
        event.stopPropagation();
        this.cloneTimeout = setTimeout(() => {
          // Pass the button object and the clone and remove actions to the createLightbox function
          createLightbox({element: this, ...this.button}, () => this.cloneButton(), () => this.deleteButton());
        }, 2000); // 2 seconds
        this.showProgressBar(true);
      }
  
    cancelHoldTimer(event) {
      clearTimeout(this.holdTimeout);
      this.hideProgressBar();
    }
  
    cancelCloneTimer(event) {
      clearTimeout(this.cloneTimeout);
      this.hideProgressBar();
    }
  
    
    deleteButton() {
      const index = buttons.findIndex(button => button.element === this);
      if (index !== -1) {
        // Delete child elements
        const childElements = buttons.filter(button => button.parentButton === buttons[index].label);
        childElements.forEach(childElement => {
          const childIndex = buttons.findIndex(button => button.element === childElement.element);
          if (childIndex !== -1) {
            buttons.splice(childIndex, 1);
            childElement.element.remove();
            updateDataTable(); // Update the table after deleting the child button
            updateTextArea();
          }
        });
    
        this.parentElement.removeChild(this);
        buttons.splice(index, 1);
        updateParentLabelDropdown();
        updateDataTable(); // Update the table after deleting the button
        updateTextArea();
      }
    }
    
    
    cloneButton() {
      const index = buttons.findIndex(button => button.element === this);
      if (index !== -1) {
        const clonedButton = { ...buttons[index] };
        const clonedButtonLabel = this.getClonedButtonLabel(clonedButton.label);
        clonedButton.label = clonedButtonLabel;
        delete clonedButton.element;
        buttons.push(clonedButton);
        const clazz = clonedButton.main ? "dispo_main_button" : "dispo_sub_button";
        const parent = clonedButton.main ? document.getElementById("dispoContainer") : buttons.find(button => button.label === clonedButton.parentButton).element;
        const newButton = createSVGButton(clonedButton, clazz, parent);
        clonedButton.element = newButton;
        clonedButton.keyword && addButtonEventListener(newButton, clonedButton.keyword);
        clonedButton.main && updateParentLabelDropdown();
        updateDataTable();
        updateTextArea();
    
        const cloneChildElements = (parentButton, newParentButton) => {
          const childElements = buttons.filter(button => button.parentButton === parentButton.label);
          childElements.forEach(childElement => {
            const clonedChildElement = { ...childElement };
            const clonedChildElementLabel = this.getClonedButtonLabel(clonedChildElement.label);
            clonedChildElement.label = clonedChildElementLabel;
            delete clonedChildElement.element;
            buttons.push(clonedChildElement);
            const childClazz = clonedChildElement.main ? "dispo_main_button" : "dispo_sub_button";
            const newChildButton = createSVGButton(clonedChildElement, childClazz, newParentButton);
            clonedChildElement.element = newChildButton;
            clonedChildElement.keyword && addButtonEventListener(newChildButton, clonedChildElement.keyword);
            clonedChildElement.main && updateParentLabelDropdown();
            updateDataTable();
            updateTextArea();
            cloneChildElements(childElement, newChildButton);
          });
        };
    
        cloneChildElements(buttons[index], newButton);
      }
    }
    
    
      
    getClonedButtonLabel(label) {
      let count = 0;
      let clonedLabel = label;
      while (buttons.some(button => button.label === clonedLabel)) {
        count++;
        clonedLabel = `${label} (copy ${count})`;
      }
      return clonedLabel;
    }
    
      showProgressBar(cloneMode = false) {
        const progressBar = document.createElement("div");
        progressBar.className = "progress-bar";
        progressBar.style.width = "0%";
        progressBar.style.height = "5px";
        progressBar.style.backgroundColor = cloneMode ? "green" : "blue";
        progressBar.style.position = "absolute";
        progressBar.style.bottom = "0";
        progressBar.style.transition = "width 3s linear";
        this.appendChild(progressBar);
        this.progressBar = progressBar;
        requestAnimationFrame(() => {
          progressBar.style.width = "100%";
        });
      }
    
      hideProgressBar() {
        if (this.progressBar) {
          this.removeChild(this.progressBar);
          this.progressBar = null;
        }
      }
    }

    customElements.define("custom-div", CustomDiv, { extends: "div" });

   export function createDispositions(buttons) {
        const parentButtons = buttons.filter(button => button.main);
        const parentMap = new Map(parentButtons.map(({ label }, index) => [label, index]));
        const dispoContainer = document.createElement('div');
        dispoContainer.id = 'dispoContainer';
        buttons.forEach(button => {
          const clazz = button.main ? "dispo_main_button" : "dispo_sub_button";
          const parent = button.parentButton ? parentButtons[parentMap.get(button.parentButton)]?.element : dispoContainer;
          if (parent) {
            const newButton = createSVGButton(button, clazz, parent);
            button.element = newButton;
            button.keyword && addButtonEventListener(newButton, button.keyword);
            button.main && dispoContainer.appendChild(newButton);
          }
        });
        return dispoContainer;
      }
      
        
      export function initDispositions(buttons, parentElement = null) {
          const dispositionsContainer = createDispositions(buttons);
          const oldDispoContainer = document.getElementById("dispoContainer");
          if (oldDispoContainer) {
              oldDispoContainer.replaceWith(dispositionsContainer);
          } else if (parentElement) {
              parentElement.insertBefore(dispositionsContainer, parentElement.firstChild);
          } else {
              document.body.insertBefore(dispositionsContainer, document.body.firstChild);
          }
      }

      
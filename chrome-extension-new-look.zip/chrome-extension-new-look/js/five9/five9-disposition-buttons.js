"use strict";

function callMain(
  extObserver,
  section,
  modal,
  urlState)
{
  const isCall = createIsInSection(urlState);
  const call = createInSection(section, modal, extObserver);
  const callLeft = createLeftSection(extObserver);
  flashcardsMain();
  stateSection(isCall, call, callLeft);
}

function urlCallState() {
  let url = window.location.href;
  return url.endsWith("role=Agent#agent/voice");
}

function createCallObservation() {
  return new function() {
    const self = this;

    self.callObservation = function(mutations, observer) {
      let interactionHeader = mutations
        .map(r => r.target)
        .find(t => t.className==="interaction-header");

      if (interactionHeader) {
        let dispo = interactionHeader.querySelector("#dispoContainer");
        if (!dispo)
          interactionHeader.appendChild(dispositions());
      }
  
      flashcardsMain(mutations);
    };

    self.callModalObservation = function(mutations, observer) {
      let callNotificationDialogOkButton = querySingle(mutations,
        "#CallNotificationDialog-ok-button");
      if (callNotificationDialogOkButton) {
        callNotificationDialogOkButton.click();
      }
    };
  };
}

function dispositions() {
  function createImg(src, clazz, parent) {
    let button = document.createElement("img");
    button.src = chrome.runtime.getURL(src);

    let wrapper = document.createElement("div");
    wrapper.appendChild(button);
    wrapper.className = clazz;
    if (parent !== null) {
      parent.appendChild(wrapper);
    }
    return wrapper;
  }

  function getDispositionItem(keyword) {
    let item = [... document.querySelectorAll(".disposition-item > .tt")]
      .find(i => i.innerText===keyword);
    return item;
  }

  function performClickOnDispositionItem(keyword) {
    let items = getDispositionItem(keyword);
    items.click();
  }

  let dispoContainer = document.createElement('div');
  dispoContainer.id = 'dispoContainer';

  let button_1 = createImg("img/five9-buttons/1.LEAD.png", "dispo_main_button_1", dispoContainer);
  let button_1_1 = createImg("img/five9-buttons/1.1.LIVE.png", "dispo_sub_button_1 dispo_LIVE", button_1);
  button_1_1.addEventListener('click', function() {
    performClickOnDispositionItem("IN RANGE Live Transfer");
  });
  let button_1_2 = createImg("img/five9-buttons/1.2.WEBFORM.png", "dispo_sub_button_1 dispo_WEBFORM", button_1);
  button_1_2.addEventListener('click', function() {
    performClickOnDispositionItem("IN RANGE Web Form");
  });
  let button_1_3 = createImg("img/five9-buttons/1.3.ABOVE.png", "dispo_sub_button_1 dispo_ABOVE", button_1);
  button_1_3.addEventListener('click', function() {
    performClickOnDispositionItem("Above Range Web Form");
  });
  let button_1_4 = createImg("img/five9-buttons/1.4.FULL.png", "dispo_sub_button_1 dispo_FULL", button_1);
  button_1_4.addEventListener('click', function() {
    performClickOnDispositionItem("Full Retail Web Form");
  });
  let button_1_5 = createImg("img/five9-buttons/1.5.FR-CREATIVE.png", "dispo_sub_button_1 dispo_FULL_CREATIVE", button_1);
  button_1_5.addEventListener('click', function() {
    performClickOnDispositionItem("Full Retail Creative");
  });
  let button_1_6 = createImg("img/five9-buttons/1.6.FR-REALTOR.png", "dispo_sub_button_1 dispo_FULL_REALTOR", button_1);
  button_1_6.addEventListener('click', function() {
    performClickOnDispositionItem("Full Retail Realtor");
  });
  let button_1_7 = createImg("img/five9-buttons/1.7.SENT.png", "dispo_sub_button_1 dispo_FULL", button_1);
  button_1_7.addEventListener('click', function() {
    performClickOnDispositionItem("Already SENT");
  });

  

  // let button_2 = createImg("img/five9-buttons/2.NOT-AVAILABLE.png", "dispo_main_button_2", dispoContainer);


  let button_2_1 = createImg("img/five9-buttons/2.1.HUMAN.png", "dispo_main_button_2_1", dispoContainer);
  button_2_1.addEventListener('click', function() {
    performClickOnDispositionItem("Not Available Human");
  });

  let button_2_2 = createImg("img/five9-buttons/2.2.MACHINE.png", "dispo_main_button_2_2", dispoContainer);
  button_2_2.addEventListener('click', function() {
    performClickOnDispositionItem("Not Available Machine");
  });

  let button_6 = createImg("img/five9-buttons/6.VOICEMAIL.png", "dispo_main_button_6", dispoContainer);
  button_6.addEventListener("click", function() {
    performClickOnDispositionItem("Voicemail");
  });

  let button_5 = createImg("img/five9-buttons/5.WRONG-NUMBER.png", "dispo_main_button_5", dispoContainer);
  button_5.addEventListener("click", function() {
    performClickOnDispositionItem("Wrong Number");
  });


  let button_3 = createImg("img/five9-buttons/3.NOT-INTERESTED.png", "dispo_main_button_3", dispoContainer);
  button_3.addEventListener('click', function() {
    performClickOnDispositionItem("Not Interested");
  });

  let button_8 = createImg("img/five9-buttons/8.CALL-BACK.png", "dispo_main_button_8", dispoContainer);
  button_8.addEventListener("click", function() {
    performClickOnDispositionItem("Callback");
  });
  
  let button_4 = createImg("img/five9-buttons/4.MLS-LISTED.png", "dispo_main_button_4", dispoContainer);
  button_4.addEventListener('click', function() {
    performClickOnDispositionItem("Listed on MLS");
  });



  let button_7 = createImg("img/five9-buttons/7.SOLD-HOME.png", "dispo_main_button_7", dispoContainer);
  button_7.addEventListener("click", function() {
    performClickOnDispositionItem("Already Sold Home");
  });



  let button_9 = createImg("img/five9-buttons/9.DNC.png", "dispo_main_button_9", dispoContainer);
  let button_9_1 = createImg("img/five9-buttons/9.1.DNC-NOT-INTERESTED.png", "dispo_sub_button_9", button_9);
  button_9_1.addEventListener('click', function() {
    performClickOnDispositionItem("DNC Not Interested");
  });
  let button_9_2 = createImg("img/five9-buttons/9.2.DNC-WRONG-NUMBER.png", "dispo_sub_button_9", button_9);
  button_9_2.addEventListener('click', function() {
    performClickOnDispositionItem("DNC Wrong Number");
  });
  let button_9_3 = createImg("img/five9-buttons/9.3.DNC-DEAD-PERSON.png", "dispo_sub_button_9", button_9);
  button_9_3.addEventListener('click', function() {
    performClickOnDispositionItem("Dead Person");
  });

  let button_2_3 = createImg("img/five9-buttons/2.3.VOICE-BREAKING-UP.png", "dispo_main_button_2_3", dispoContainer);
  button_2_3.addEventListener('click', function() {
    performClickOnDispositionItem("Voice Breaking Up");
  });

  //Keyboard Shortcuts
  function buttonClick(e) {
    if (e.altKey && (e.key === "h" || e.key === "H")) {
      performClickOnDispositionItem("Not Available Human");
    }
    if (e.altKey && (e.key === "m" || e.key === "M")) {
      performClickOnDispositionItem("Not Available Machine");
    }
    if (e.altKey && (e.key === "n" || e.key === "N")) {
      performClickOnDispositionItem("Not Interested");
    }
    if (e.altKey && (e.key === "l" || e.key === "L")) {
      performClickOnDispositionItem("Listed on MLS");
    }
    if (e.altKey && (e.key === "w" || e.key === "W")) {
      performClickOnDispositionItem("Wrong Number");
    }
     if (e.altKey && (e.key === "v" || e.key === "V")) {
      performClickOnDispositionItem("Voicemail");
    }
     if (e.altKey && (e.key === "s" || e.key === "S")) {
      performClickOnDispositionItem("Already Sold Home");
    }
    if (e.altKey && (e.key === "c" || e.key === "C")) {
      performClickOnDispositionItem("Callback");
    }
  }
  window.addEventListener("keydown", buttonClick);

  return dispoContainer;

   
  return dispoContainer;
}




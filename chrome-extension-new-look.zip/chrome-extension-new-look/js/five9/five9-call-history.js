let draggableWindow;
function draggableWindowCallHistory() {
// Add the box to the DOM
draggableWindow = document.createElement('div');
draggableWindow.style.width = '350px';
draggableWindow.style.height = '500px';
draggableWindow.style.background = 'white';
draggableWindow.style.position = 'fixed';
draggableWindow.style.top = '50%';
draggableWindow.style.left = '90%';
draggableWindow.style.transform = 'translate(-50%, -50%)';
draggableWindow.style.borderRadius = '10px';
draggableWindow.style.boxShadow = '0 0 10px rgba(0, 0, 0, 0.5)';
draggableWindow.style.zIndex = '9999';
draggableWindow.style.cursor = 'move';
draggableWindow.style.overflowY = 'auto'; // Scroll only appears when necessary
draggableWindow.style.boxSizing = 'border-box';
document.body.appendChild(draggableWindow);

let isDoubleSize = false; // Added this line to keep track of whether or not we've double clicked

// Initialize interact.js
interact(draggableWindow)
.draggable({
    listeners: {
        start(event) {
            console.log(event.type, event.target);
        },
        move(event) {
            const target = event.target;
            const x = (parseFloat(target.getAttribute('data-x')) || 0) + event.dx;
            const y = (parseFloat(target.getAttribute('data-y')) || 0) + event.dy;

            target.style.transform = 'translate(' + x + 'px, ' + y + 'px)';
            target.setAttribute('data-x', x);
            target.setAttribute('data-y', y);
        }
    },
    modifiers: [
        interact.modifiers.restrict({
            restriction: 'parent',
            elementRect: {top: 0, left: 0, bottom: 1, right: 1}
        })
    ],
    inertia: true
})
.resizable({
    edges: {left: true, right: true, bottom: true, top: true},
    listeners: {
        move(event) {
            const target = event.target;
            const x = (parseFloat(target.getAttribute('data-x')) || 0);
            const y = (parseFloat(target.getAttribute('data-y')) || 0);

            target.style.width = event.rect.width + 'px';
            target.style.height = event.rect.height + 'px';

            target.style.transform = 'translate(' + (x + event.deltaRect.left) + 'px,' + (y + event.deltaRect.top) + 'px)';

            target.setAttribute('data-x', x + event.deltaRect.left);
            target.setAttribute('data-y', y + event.deltaRect.top);
        }
    },
    modifiers: [
        interact.modifiers.restrictEdges({
            outer: 'parent',
            endOnly: true,
        }),
        interact.modifiers.restrictSize({
            min: {width: 100, height: 50},
        }),
    ],
    inertia: true
});

// Double click event listener
draggableWindow.addEventListener('dblclick', function() {
    isDoubleSize = !isDoubleSize; // Toggle the flag on double click
    if(isDoubleSize) {
        draggableWindow.style.width = '220px';
        draggableWindow.style.height = '200px';
    } else {
        draggableWindow.style.width = '350px';
        draggableWindow.style.height = '500px';
    }
});
}






//Observer code to attach results to the draggable window
function observeNode() {
    // Select the node that will be observed for mutations
    let targetNode = document.getElementById('AgentScreenVoice-details-node');

    // if targetNode is not available, try again in 1 second
    if (!targetNode) {
        console.log('Node not available, retrying in 1 second...');
        setTimeout(observeNode, 1000);
        return;
    }

    // Options for the observer (which mutations to observe)
    let config = { attributes: false, childList: true, subtree: true, characterData: true };
    
    // Callback function to execute when mutations are observed
    let callback = function(mutationsList, observer) {
        for(let mutation of mutationsList) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                for (let node of mutation.addedNodes) {
    
         // Handle Case 1
         if (node.getAttribute && node.getAttribute('data-f9-template') === 'ContactHistoryTimeline') {
            console.log('<div data-f9-template="ContactHistoryTimeline"> has been added');
        
            let logs = [];
            let items = node.querySelectorAll('.history-timeline-item');
            items.forEach(item => {
                let date = item.querySelector('.date').innerText;
                let time = item.querySelector('.time').innerText;
                let disposition = item.querySelector('.column-content .disposition').innerText;
                let agent = item.querySelector('.column-user .agent').innerText;
                let typeFull = item.querySelector('.campaign-anchor').innerText; 
                let typeParts = typeFull.split('_');
                let type = typeParts[typeParts.length - 1]; // Get the last part
                logs.push({ date, time, disposition, agent, type });
            });
        
            console.table(logs, ['date', 'time', 'disposition', 'agent', 'type']);
        
            let table = document.createElement('table');
            table.className = 'formatted-table'; 
            table.innerHTML = '<tr><th>DATE</th><th>TIME</th><th>DISPOSITION</th><th>AGENT</th><th>TYPE</th></tr>';
            logs.forEach(log => {
                let color;
                if (log.disposition.includes("Sold") || log.disposition.includes("Callback")) {
                    color = 'blue';
                } else if (
                    log.disposition.includes("Range") ||
                    log.disposition.includes("Retail") ||
                    log.disposition.includes("Creative") ||
                    log.disposition.includes("Already")
                ) {
                    color = 'red';
                }
        
                let row = document.createElement('tr');
                row.innerHTML = `<td>${log.date}</td><td>${log.time}</td><td style="color: ${color}">${log.disposition}</td><td style="color: ${color}">${log.agent}</td><td>${log.type}</td>`;
                table.appendChild(row);
            });
        
         // Adding the table to the draggable window
draggableWindow.innerHTML = ""; 
draggableWindow.appendChild(table);

// Getting the width of the table
let tableWidth = table.offsetWidth;

// Apply the width of the table as a minimum width for the draggable window
interact(draggableWindow).resizable({
    modifiers: [
        interact.modifiers.restrictEdges({
            outer: 'parent',
            endOnly: true,
        }),
        interact.modifiers.restrictSize({
            min: {width: tableWidth, height: 50}, // Replaced 100 with tableWidth
        }),
    ],
    inertia: true
});
        }
            
    
                        // Handle Case 2
                        else if (node.getAttribute && node.getAttribute('data-f9-template') === 'ContactHistoryNoInteractionView') {
                            console.log('<div data-f9-template="ContactHistoryNoInteractionView"> has been added');
                            draggableWindow.innerHTML = "0 previous history interactions"; // Set the content of the draggable window to the required message
                        }
                    }
                }
    
        // Handle Case 3
        let agentNode = targetNode.querySelector('#AgentVoiceDetailsHeader-contact-node');

        if (agentNode) {
            console.log('#AgentVoiceDetailsHeader-contact-node has been added or updated');
            let text = agentNode.textContent;
            console.log('Text content: ', text);

            let header = draggableWindow.querySelector('.agent-header');
            if (!header) {
                // The header doesn't exist yet, so create it
                header = document.createElement('h3');
                header.style.color = 'blue';
                header.className = 'agent-header'; // Add a specific class name
                draggableWindow.prepend(header); // Prepend the header to the existing content
            }

                // Update the text content of the header
                if (text.trim() !== '') {
                    header.textContent = text;
                }
            }
    
    
            }
        };
    
        let observer = new MutationObserver(callback);
        observer.observe(targetNode, config);


  // Create and append the CSS style
  let style = document.createElement('style');
  style.innerHTML = `
      .formatted-table, .formatted-table th, .formatted-table td {
          border: 1px solid gray;
          border-collapse: collapse;
          text-align: center;
          margin: 3px;
      }
      .formatted-table th, .formatted-table td {
          padding: 3px;
      }
  `;
  document.head.appendChild(style);

  console.log('Successfully created observer');
}

// Start observing the node after 15 seconds
//setTimeout(observeNode, 1000);
if (window.location.href.includes("five9.com/clients/agent/main.html")) {
draggableWindowCallHistory();
observeNode();
}
"use strict";

function crmMain(
    extObserver,
    section,
    modal,
    urlState)
{
  const isCrm = createIsInSection(urlState);
  const crm = createInSection(section, modal, extObserver);
  const crmLeft = createLeftSection(extObserver);
  stateSection(isCrm, crm, crmLeft);
}

function urlCrmState() {
  let url = window.location.href;
  return url.endsWith("role=Agent#agent/crm");
}

function createCrmObservation() {
  return new function() {
    const self = this;
    self.cachedNumbers = {};
    self.currentCampaign =undefined;

    self.crmObservation = function(mutations, observer) {
      const phoneField = querySingle(mutations,
        "#input-phone-container input[data-datatype='phone'].form-control.addon");
      if (phoneField && hasMessage(observer)) {
        const message = readMessage(observer);
        if (message.campaign) {
          self.cachedNumbers[phoneField.value] = message.campaign.value;
          clearMessage(observer);
        }
      }
    };

    self.crmModalObservation = function(mutations, observer) {
      const addressSparseButton = querySingle(mutations,
        "#AddressBookSparse-number-button .number");
      const addressBookSparseSelection =
        querySingle(mutations, "#AddressBookSparse-campaigns-select");

      if (addressBookSparseSelection&&addressSparseButton) {
        const phone = extractNumbers(addressSparseButton.innerText);
        const campaign = self.cachedNumbers[phone];
        let option = [... addressBookSparseSelection.children].find(n => n.text===campaign);
        if (option)
          option.setAttribute("selected", "selected");
      }


      const reminderSelection = querySingle(mutations,
        "#ReminderDialog-campaign-select");
      const reminderPhoneInput = querySingle(mutations, "#ReminderDialog-filter-input");

      if (reminderPhoneInput&&reminderSelection) {
        const phone = extractNumbers(reminderPhoneInput.value);
        const campaign = self.cachedNumbers[phone];
        let option = [... reminderSelection.children].find(n => n.text===campaign);
        if (option)
          option.setAttribute("selected", "selected");
      }
    };
  };
}
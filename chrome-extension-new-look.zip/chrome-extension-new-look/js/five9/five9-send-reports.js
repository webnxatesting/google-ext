let five9CallType = document.querySelector(".call-type").innerText;
// Inbound
;
let five9CampaignName = document.querySelector(".campaign-name").innerText.split(":")[1];
//202_OUTBOUND

let five9callerNumber = document.querySelector('.caller-other-party-number').innerText;
// (321) 804-2376


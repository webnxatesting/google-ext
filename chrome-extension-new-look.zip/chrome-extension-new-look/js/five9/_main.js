"use strict";

let observerContent = new MutationObserver(waitForLoadingPage);
let observerOptions = { childList: true, subtree: true, attributes: true };

function waitForLoadingPage(mutations, observer) {
  let targets = mutations.find(
    r => r.target.id==="audio-controls-mp3-player-container");
  if (targets) {
    const crmCallbacks = createCrmObservation();
    const crmObserver = createExtObserver(
      crmCallbacks.crmObservation,
      crmCallbacks.crmModalObservation);

    const callbacks = createActivityObservation(crmObserver);
    const activityObserver = createExtObserver(
      callbacks.observeAgentScreen,
      callbacks.observeModal);
    
    const callCallbacks = createCallObservation();
    const callObserver = createExtObserver(
      callCallbacks.callObservation,
      callCallbacks.callModalObservation);

    startCall(callObserver);
    startCrm(crmObserver);
    startActivity(activityObserver);
    observer.disconnect();
  }
}

function startCrm(observer) {
  const section = document.getElementById("agent-screen-crm");
  const modalSection = document.getElementById("modal");

  crmMain(
    observer,
    section,
    modalSection,
    urlCrmState);

  window.addEventListener("hashchange", createStateSection(
    observer,
    section,
    modalSection,
    urlCrmState));
}

function startActivity(observer) {
  const section = document.getElementById("agent-screen-activity");
  const modalSection = document.getElementById("modal");
  
  activityMain(
    observer,
    section,
    modalSection,
    urlActivityState);
  
  window.addEventListener("hashchange", createStateSection(
    observer,
    section,
    modalSection,
    urlActivityState));
}

function startCall(observer) {
  const section = document.getElementById("agent-screen-voice");
  const modalSection = document.getElementById("modal");

  callMain(
    observer,
    section,
    modalSection,
    urlCallState);

  window.addEventListener("hashchange", createStateSection(
    observer,
    section,
    modalSection,
    urlCallState));
}

observerContent.observe(document.body, observerOptions);
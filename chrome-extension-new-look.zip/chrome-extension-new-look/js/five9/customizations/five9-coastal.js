// five9-coastal.js
console.log("five9-coastal.js");


function coastalLiveTransferObserver() {
    // Function to find the element containing 'TEST_OUTBOUND'
    function findElement(root) {
        root.querySelectorAll('*').forEach(element => {
            if (element.textContent.includes('TEST_OUTBOUND')) {
                console.log('Element found containing TEST_OUTBOUND:', element);
                console.log('JavaScript path:', getDomPath(element));
            }
        });
    }

    // Function to generate the JavaScript path of an element
    function getDomPath(el) {
        var stack = [];
        while (el.parentNode != null) {
            var sibCount = 0;
            var sibIndex = 0;
            for (var i = 0; i < el.parentNode.childNodes.length; i++) {
                var sib = el.parentNode.childNodes[i];
                if (sib.nodeName === el.nodeName) {
                    if (sib === el) {
                        sibIndex = sibCount;
                    }
                    sibCount++;
                }
            }
            if (el.hasAttribute('id') && el.id !== '') {
                stack.unshift(el.nodeName.toLowerCase() + '#' + el.id);
            } else if (sibCount > 1) {
                stack.unshift(el.nodeName.toLowerCase() + ':eq(' + sibIndex + ')');
            } else {
                stack.unshift(el.nodeName.toLowerCase());
            }
            el = el.parentNode;
        }
        return stack.slice(1).join(' > '); // Skips the html element
    }

    // Observer callback
    const observerCallback = (mutationsList, observer) => {
        for (let mutation of mutationsList) {
            if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                mutation.addedNodes.forEach(node => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        findElement(node);
                    }
                });
            } else if (mutation.type === 'characterData') {
                const parentElement = mutation.target.parentElement;
                if (parentElement && parentElement.textContent.includes('TEST_OUTBOUND')) {
                    console.log('Text change detected containing TEST_OUTBOUND:', parentElement);
                    console.log('JavaScript path:', getDomPath(parentElement));
                }
            }
        }
    };

    // Create a new observer instance
    const observer = new MutationObserver(observerCallback);

    // Configuration of the observer
    const config = { childList: true, subtree: true, characterData: true };

    // Start observing the document
    observer.observe(document, config);

    // Initial search in case the element is already in the DOM
    findElement(document);
}

// Start the observer
setTimeout(() => {
    coastalLiveTransferObserver();
}, 15000);

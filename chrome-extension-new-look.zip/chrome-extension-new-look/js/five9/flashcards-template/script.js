const default_card_template = $("#flashcard-default-template"); // Get default template to create flashcards
let onlyFavorites = false; // Boolean variable to control favorites
let existFavorites = false; // Boolean variable to check the existence of favorites
let Favorites = []; // Array variable to temporarily store favorites

// Function to load all flashcards, receives as a parameter a boolean value to check if it is necessary to reload the flashcards
function load_flashcards(reload = false) {
    // Check if reload is necessary
    if ( reload === true ) {
        $(".flashcard-container > .flashcard").remove(); //Remove all flashcards
        $(".flashcard-container").append($("#flashcard-loading-template").clone().addClass("flashcard-loading").removeClass("d-none")); // Add loading card
    }

    // Check if there are no exists favorites and if favorites control is active
    if ( existFavorites === false && onlyFavorites === true ) {
        // If true
        $("#onlyFavorites").attr("checked", false); // turn off favorites control
        chrome.storage.local.set({"onlyFavorites" : false}); // Change control variable in chrome local storage
        onlyFavorites = false; // Change control variable
    } else if ( existFavorites === false && onlyFavorites === false ) {
        $("#onlyFavorites").prop("checked", false).change(); // turn off favorites control
    }

    // Send query command to background
    chrome.runtime.sendMessage({command: "rebuttals"}, function(response) {
        response.sort((firstItem, secondItem) => parseInt(firstItem[0]) - parseInt(secondItem[0])); // Sort results by ID
    
        $(".flashcard-loading").remove(); // Remove loading card

        // Loop through each result
        response.forEach(element => {
            let ID = parseInt(element[0]);
            let Question = element[1];
            let Answer = element[2];
            // We check if only favorites will be shown and if favorites exist
            if ( onlyFavorites === true && existFavorites === true ) {
                // If true, check if the item ID is in the favorites array
                if ( Favorites.includes(ID) ) {
                    // If true
                    let item = default_card_template.clone(); // Clone card template
    
                    item.removeAttr("id"); // Remove attribute id
                    item.find(".flashcard-favourite-button").attr("data-flashcardid", ID); // Add item ID to data attribute flashcardid
                    item.find(".front > h3").text(Question); // Add item question to the front of flash card
                    item.find(".back > p").text(Answer); // Add item answer to the back of flash card
                    item.find(".flashcard-favourite-button").addClass("text-warning"); // Activate the favorite button
    
                    $(".flashcard-container").append(item); // Add item to the flashcard container
                }
            } else {
                // If false
                let item = default_card_template.clone(); // Clone card template
    
                item.removeAttr("id"); // Remove attribute id
                item.find(".flashcard-favourite-button").attr("data-flashcardid", ID); // Add item ID to data attribute flashcardid
                item.find(".front > h3").text(Question); // Add item question to the front of flash card
                item.find(".back > p").text(Answer); // Add item answer to the back of flash card
    
                if ( Favorites.includes(ID) ) {
                    item.find(".flashcard-favourite-button").addClass("text-warning"); // Activate the favorite button
                }
    
                $(".flashcard-container").append(item); // Add item to the flashcard container
            }
        });
    
        $('.back').hide(); // Hide all back cards
    
        // Hover effect on flash cards
        $('.front', '.flashcard').hover(function() {
            $(this).hide();
            $(this).siblings('.back').addClass("animate__animated animate__flipInX fast").show();
            $("body").css("overflow", "hidden");
        });
    
        // Mouse leave effect on flash cards
        $('.back', '.flashcard').mouseleave(function() {
            $(this).hide();
            $(this).siblings('.front').addClass("animate__animated animate__flipInX fast").show();
            $("body").css("overflow", "hidden");
        });
    
        // Click event when checking a favorite card
        $(".flashcard-favourite-button").click(function (){
            let flashcardID = $(this).data("flashcardid");
            
            chrome.storage.local.get(["flashcardFavourites"], function(data){
                let favourites = [];
                if ( typeof data.flashcardFavourites != 'undefined' ) {
                    favourites = data.flashcardFavourites;
                    if ( favourites.includes(flashcardID) ) {
                        for( var i = 0; i < favourites.length; i++){
                            if ( favourites[i] === flashcardID) {
                                favourites.splice(i, 1); 
                            }
                        }
                    } else {
                        favourites.push(flashcardID);
                    }
                    chrome.storage.local.set({"flashcardFavourites" : favourites});
                } else {
                    favourites.push(flashcardID);
                    chrome.storage.local.set({"flashcardFavourites" : favourites});
                }
            });
        
            $(this).addClass("animate__animated animate__tada fast").toggleClass("text-warning");
            setTimeout(function(){
                $(".flashcard-favourite-button").removeClass("animate__animated animate__tada fast");
            }, 500);
        });
    
        // Click event when the front of flash card is clicked
        $('.front', '.flashcard').on('click', function() {
            $(this).hide();
            $(this).siblings('.back').show();
        });
        
        // Click event when the back of flash card is clicked
        $('.back', '.flashcard').on('click', function() {
            $(this).hide();
            $(this).siblings('.front').show();
        });        
    
        let active_random = 0; // Integer variable to store random active card
        // Check if the favorite control is active
        if ( onlyFavorites === true ) {
            // if true
            active_random = Math.floor(Math.random() * Favorites.length); // generate a random number with a maximum value equal to the length of the favorites
        } else {
            // if false
            active_random = Math.floor(Math.random() * response.length); // generate a random number with value equal to the length of flash cards
        }
    
        $(".flashcard-container > .flashcard:eq("+active_random+")").removeClass("d-none").addClass("flashcard-active"); // Activate de random flash card
        flashcard_footer(); // Generate footer
    });
    console.log("Carga de flashcards");
}

// Function to generate footer
function flashcard_footer() {
    let flashcard_count = $(".flashcard-container > .flashcard").length;
    let footer;
    let active = $(".flashcard-container > .flashcard.flashcard-active").index();
    footer = active + " - " + flashcard_count;

    $(".flashcard-footer").text(footer);
}

// Function to go to the next card
function next(element){
    element.addClass("animate__animated animate__flipInX");
    $(".flashcard-container > .flashcard.flashcard-active").removeClass("animate__animated animate__lightSpeedInRight animate__lightSpeedInLeft fast");
    setTimeout(function(){
        $(".flashcard-next-button").removeClass("animate__animated animate__flipInX");
    }, 1000);
    
    if( !$(".flashcard-container > .flashcard.flashcard-active").is(":last-child") ){
        $(".flashcard-container > .flashcard.flashcard-active").removeClass("flashcard-active").addClass("d-none").next().addClass("animate__animated animate__lightSpeedInLeft fast flashcard-active").removeClass("d-none");
    } else {
        $(".flashcard-container > .flashcard.flashcard-active").removeClass("flashcard-active").addClass("d-none");
        $(".flashcard-container > .flashcard:eq(0)").addClass("animate__animated animate__lightSpeedInLeft fast flashcard-active").removeClass("d-none");
    }

    $('.back').hide().siblings('.front').show();
    flashcard_footer();
    $('button').blur();
}

// Function to go to the next card
function back(element){
    element.addClass("animate__animated animate__flipInX");
    $(".flashcard-container > .flashcard.flashcard-active").removeClass("animate__animated animate__lightSpeedInRight animate__lightSpeedInLeft fast");
    setTimeout(function(){
        $(".flashcard-back-button").removeClass("animate__animated animate__flipInX");
    }, 1000);

    if( $(".flashcard-container > .flashcard.flashcard-active").index() > 1 ){
        $(".flashcard-container > .flashcard.flashcard-active").removeClass("flashcard-active").addClass("d-none").prev().addClass("animate__animated animate__lightSpeedInRight fast flashcard-active").removeClass("d-none");
    } else {
        $(".flashcard-container > .flashcard.flashcard-active").removeClass("flashcard-active").addClass("d-none");
        $(".flashcard-container > .flashcard:last-child").addClass("animate__animated animate__lightSpeedInRight fast flashcard-active").removeClass("d-none");
    }
    $('.back').hide().siblings('.front').show();
    flashcard_footer();
    $('button').blur();
}

// Click event when favorite control is triggered
$("#onlyFavorites").click(function (){
    chrome.storage.local.get(["flashcardFavourites"], function(data){
        if ( $("#onlyFavorites").is(":checked") ) {
            chrome.storage.local.set({"onlyFavorites" : true});
            onlyFavorites = true;
        } else {
            chrome.storage.local.set({"onlyFavorites" : false});
            onlyFavorites = false;
        }

        if (typeof data.flashcardFavourites === "undefined"){
            return false;
        } else {
            if ( data.flashcardFavourites.length > 0 ) {
                existFavorites = true;
                Favorites = data.flashcardFavourites;
                load_flashcards(true);
            } else {
                existFavorites = false;
                chrome.storage.local.set({"existFavorites" : false});
                onlyFavorites = false;
                chrome.storage.local.set({"onlyFavorites" : false});
                $("#onlyFavorites").prop("checked", false).change();
            }
        }
    });
    $("input").blur();
});

// Click event when next button is clicked
$(".flashcard-next-button").click( function(){
    next($(this));
});

// Click event when back button is clicked
$(".flashcard-back-button").click( function(){
    back($(this));
});

// Events when keys are pressed
$("html").keydown( function(key){
    switch (key.which){
        // Space key
        case 32:
            if($(".flashcard-active > .front").is(":visible")){
                $('.flashcard-active > .front').hide();
                $('.flashcard-active > .front').siblings('.back').addClass("animate__animated animate__flipInX fast").show();
            } else {
                $('.flashcard-active > .back').hide();
                $('.flashcard-active > .back').siblings('.front').addClass("animate__animated animate__flipInX fast").show();
            }
        break;
        // Next arrow key
        case 39:
            next($(".flashcard-next-button"));
        break;
        // Back arrow key
        case 37:
            back($(".flashcard-back-button"));
        break;
    }
});


chrome.storage.local.get(["onlyFavorites"], function(data){
    if (data.onlyFavorites === true) {
        $("#onlyFavorites").prop("checked", true).change();
        onlyFavorites = true;
    } else {
        $("#onlyFavorites").prop("checked", false).change();
    }
});

chrome.storage.local.get(["flashcardFavourites"], function(data){
    if (typeof data.flashcardFavourites === "undefined"){
        return false;
    } else {
        if ( data.flashcardFavourites.length > 0 ) {
            existFavorites = true;
            Favorites = data.flashcardFavourites;
        }
    }
});

chrome.storage.local.get(["flashcardRebuttalsDB"], function(data){
    if (typeof data.flashcardRebuttalsDB === "undefined"){
        console.log("Carga desde BD...");
    } else {
        if ( data.flashcardRebuttalsDB.length > 0 ) {
            console.log("Carga desde cache...");
        } else {
            console.log("Carga desde BD...");
        }
    }
});

chrome.storage.local.get(["flashcardPhrasesDB"], function(data){
    if (typeof data.flashcardPhrasesDB === "undefined"){
        console.log("Carga desde BD...");
    } else {
        if ( data.flashcardPhrasesDB.length > 0 ) {
            console.log("Carga desde cache...");
        } else {
            console.log("Carga desde BD...");
        }
    }
});

chrome.runtime.sendMessage({command: "phrases"}, function(response) {
    response.sort((firstItem, secondItem) => parseInt(firstItem[0]) - parseInt(secondItem[0]));
    let phrase_ramdom = 0;

    while ( phrase_ramdom <= 1 ) {
        phrase_ramdom = Math.floor(Math.random() * ((response.length - 1) + 1));
    }

    response.forEach(element => {
        let ID = parseInt(element[0]);
        let Phrase = element[1];

        if ( ID == 1 ) {
            $("#phrases > .blockquote").text(Phrase);
        } else if (ID == phrase_ramdom) {
            $("#phrases > .blockquote-footer").text(Phrase);
        }
    });
    console.log("Carga de frases");
});

load_flashcards(false);

setTimeout(() => {
    $("#phrases > .blockquote-footer").toggleClass("animate__animated animate__tada");
}, 3000);
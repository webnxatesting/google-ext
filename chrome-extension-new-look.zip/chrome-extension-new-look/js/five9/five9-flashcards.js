"use strict";

function flashcardsMain(mutations) {
  let phoneIcon = mutations ? querySingle(mutations,
    ".view-no-interaction > .cell > .empty-icon.empty-call") :
    document.querySelector(".view-no-interaction > .cell > .empty-icon.empty-call");
  if (phoneIcon) {
    let parent = phoneIcon.parentNode;
    let flashcard = flashcardIframe();
    parent.replaceChild(flashcard, phoneIcon);
  }
}

function flashcardIframe() {
  let urlFrame = chrome.runtime.getURL("js/five9/flashcards-template/index.html");
  let iframediv = document.createElement("div");
  iframediv.setAttribute("id", "iframediv");

  let ifrm = document.createElement("iframe");
  ifrm.setAttribute("src", urlFrame);
  ifrm.setAttribute("id", "ifrm");
  ifrm.style.width = "100%";
  ifrm.style.height = "400px";
  ifrm.style.overflow = "auto";

  iframediv.appendChild(ifrm);
  return iframediv;
}
"use strict";

function activityMain(
    extObserver,
    section,
    modal,
    urlState)
{
  const isActivity = createIsInSection(urlState);
  const activity = createInSection(section, modal, extObserver);
  const activityLeft = createLeftSection(extObserver);
  stateSection(isActivity, activity, activityLeft);
}

function urlActivityState() {
  let url = window.location.href;
  return url.endsWith("role=Agent#agent/activity");
}

function createActivityObservation(contactsObserver) {

  return new function() {
    const self = this;
    self.campaign = { value: undefined };

    self.observeAgentScreen = function(mutations, observer) {
      function queryTableItems(mutations) {
        return mutations
          .map(r => r.target)
          .flatMap(e => [... e.querySelectorAll(
            "div[data-f9-template='ContactHistoryTable'].table > .item")]);
      }

      queryTableItems(mutations).forEach(value => {
        let clickColumn = () => {
          self.campaign.value = toOutbound(
            value.querySelector("div.tt.column.column-campaign").innerText);
        };
        value.querySelector("div.tt.column.column-to")
          .addEventListener("click", clickColumn);
        value.querySelector("div.tt.column.column-empty")
          .addEventListener("click", clickColumn);
      });
    };

    self.observeModal = function(mutations, observer) {
      const selection = querySingle(mutations, "#AddressBookSparse-campaigns-select");
      if (selection) {
        let campaign = self.campaign.value;
        let option = [... selection.children].find(n => n.text===campaign);
        if (option)
          option.setAttribute("selected", "selected");
      }

      const openButton = querySingle(mutations, "#ContactDetailsDialog-open-button");
      if (openButton)
        openButton.addEventListener("click", 
          () => messageObserver({ campaign: self.campaign }, contactsObserver));
    }
  };
}

function toOutbound(campaign) {
  if (campaign===undefined) throw new Error("campaign was undefined");
  else if (campaign===null) throw new Error("campaign was null");
  else if (typeof campaign!=="string") throw new Error("campaign was not string");
  else if (campaign==="") return "";
  else return campaign.endsWith("_INBOUND") ?
    campaign.substring(0, campaign.indexOf("_INBOUND"))+"_OUTBOUND" :
    campaign.endsWith("_OUTBOUND") ? campaign : campaign+"_OUTBOUND";
}

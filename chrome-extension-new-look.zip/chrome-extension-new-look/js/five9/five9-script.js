"use strict";

function createStateSection(
    extObserver,
    section,
    modal,
    urlState)
{
  const isSection = createIsInSection(urlState);
  const sectionIn = createInSection(section, modal, extObserver);
  const sectionLeft = createLeftSection(extObserver);
  return () => stateSection(isSection, sectionIn, sectionLeft);
}

function stateSection(isInSection, inSection, leftSection) {
  if (isInSection()) {
    inSection();

  } else {
    leftSection();
  }
}

function createIsInSection(urlChecker) {
  return () => urlChecker();
}

function createInSection(section, modal, extObserver) {
  return () => observe(section, modal, extObserver);
}

function createLeftSection(extObserver) {
  return () => {
    clearMessage(extObserver);
    disconnect(extObserver);
  }
}

function clearMessage(extObserver) {
  extObserver.message = undefined;
}

function hasMessage(extObserver) {
  return extObserver.message!==undefined && extObserver.message!==null;
}

function readMessage(extObserver) {
  return extObserver.message;
}

function messageObserver(message, extObserver) {
  extObserver.message = message;
}

function createExtObserver(sectionOberservation, modalObservation) {
  let sectionObserver = new MutationObserver(sectionOberservation);
  let modalObserver = new MutationObserver(modalObservation);
  sectionObserver.modalObserver = modalObserver;
  sectionObserver.message = undefined;
  return sectionObserver;
}

function observe(section, modal, extObserver) {
  let obsOpts = { childList: true, subtree: true, attributes: false };
  extObserver.observe(section, obsOpts);
  extObserver.modalObserver.observe(modal, obsOpts);
}

function disconnect(extObserver) {
  extObserver.disconnect();
  extObserver.modalObserver.disconnect();   
}

function querySingle(mutations, selector) {
  return mutations
    .map(r => r.target)
    .map(e => e.querySelector(selector))
    .find(e => e!==null);
}

function extractNumbers(phone) {
  if (phone) {
    let numbers = phone.match(/\d+/g);
    return numbers ? numbers.join("") : "";
  } else {
    return "";
  }
} 
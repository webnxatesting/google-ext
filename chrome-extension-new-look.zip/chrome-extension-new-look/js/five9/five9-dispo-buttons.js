const defaultButtons = [
  {
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "LEADS",
    "main": true,
    "bgColor": "#9edf7f",
    "textColor": "#000000",
    "fontSize": "16",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "IN RANGE \n LIVE TFR 💰",
    "parentButton": "LEADS",
    "keyword": "IN RANGE Live Transfer - Agent",
    "bgColor": "#55f231",
    "textColor": "black",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "IN RANGE\n WEB FORM 🤑",
    "parentButton": "LEADS",
    "keyword": "IN RANGE Web Form - Agent",
    "bgColor": "#55f231",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "ABOVE RANGE \n👍🏼",
    "parentButton": "LEADS",
    "keyword": "Above Range Web Form - Agent",
    "bgColor": "#eee496",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "FULL RETAIL\n👌🏼",
    "parentButton": "LEADS",
    "keyword": "Full Retail Web Form - Agent",
    "bgColor": "#ec7f4d",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "CREATIVE\n IN RANGE 🤑",
    "parentButton": "LEADS",
    "keyword": "Creative InRange 20 Less - Agent",
    "bgColor": "#9edf7f",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "CREATIVE\n ABOVE 👍🏼",
    "parentButton": "LEADS",
    "keyword": "Creative AboveRange 21 Over - Agent",
    "bgColor": "#9edf7f",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "ALREADY\n✓SENT✓",
    "parentButton": "LEADS",
    "keyword": "Already SENT - Agent",
    "bgColor": "#999999",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "NOT AVAILABLE HUMAN [H]",
    "main": true,
    "keyword": "Not Available Human - Agent",
    "bgColor": "#0AB4E3",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "NOT AVAILABLE MACHINE [M]",
    "main": true,
    "keyword": "Not Available Machine - Agent",
    "bgColor": "#C5D0D3",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "VOICEMAIL [V]",
    "main": true,
    "keyword": "Voicemail - Agent",
    "bgColor": "#B4C307 ",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "WRONG NUMBER [W]",
    "main": true,
    "keyword": "Wrong Number - Agent",
    "bgColor": "#B4742A",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "RIGHT NAME \nWRONG HOME",
    "main": true,
    "keyword": "Right Name -  Wrong Home - Agent",
    "bgColor": "#c91d59",
    "textColor": "#ffffff",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "NOT INTERESTED [N]",
    "main": true,
    "keyword": "Not Interested - Agent",
    "bgColor": "#D73D33",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "CALLBACK [C]",
    "main": true,
    "keyword": "Callback - Agent",
    "bgColor": "#165F95",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "MLS\nLISTED [L]",
    "main": true,
    "keyword": "Listed on MLS - Agent",
    "bgColor": "#691DE5",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "SOLD\nHOME [S]",
    "main": true,
    "keyword": "Already Sold Home - Agent",
    "bgColor": "#4EA525",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "DNC",
    "main": true,
    "bgColor": "#D21844",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "NOT\nINTERESTED",
    "parentButton": "DNC",
    "keyword": "DNC Not Interested - Agent",
    "bgColor": "#D21844",
    "textColor": "white",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "WRONG NUMBER",
    "parentButton": "DNC",
    "keyword": "DNC Wrong Number - Agent",
    "bgColor": "#D21844",
    "textColor": "white",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "DNC ROBOKILLER🤖",
    "parentButton": "DNC",
    "keyword": "DNC Robokiller - Agent",
    "bgColor": "#d21844",
    "textColor": "#ffffff",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "DEAD PERSON",
    "parentButton": "DNC",
    "keyword": "Dead Person - Agent",
    "bgColor": "#D21844",
    "textColor": "white",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "FR OVER RANGE\n😵‍💫",
    "main": true,
    "keyword": "FR OVER RANGE - Agent",
    "bgColor": "#ec7f4d",
    "textColor": "black",
    "fontSize": "11",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  },
  {
    "label": "VOICE BREAKING-UP",
    "main": true,
    "keyword": "Voice Breaking Up - Agent",
    "bgColor": "#691DE5",
    "textColor": "white",
    "fontSize": "12",
    "fontWeight": "bold",
    "buttonsWidth": 112,
    "buttonsHeight": 50
  }
]

const buttons = [...defaultButtons];

function saveButtonsToStorage() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['Five9BtnsCode_003'], (result) => {
      if (!result.Five9BtnsCode_003) {
        chrome.storage.local.set({ Five9BtnsCode_003: JSON.stringify(defaultButtons) }, () => {
          resolve(defaultButtons);
        });
      } else {
        try {
          const storedButtons = JSON.parse(result.Five9BtnsCode_003);
          if (Array.isArray(storedButtons) && storedButtons.length > 0) {
            resolve(storedButtons);
          } else {
            console.warn('Invalid button data in storage. Falling back to default.');
            resolve(defaultButtons);
          }
        } catch (e) {
          console.error('Failed to parse button data from storage:', e);
          resolve(defaultButtons);
        }
      }
    });
  });
}

function updateButtonsFromStorage() {
  chrome.storage.local.get(['Five9BtnsCode_003'], (result) => {
    if (result.Five9BtnsCode_003) {
      try {
        const newButtons = JSON.parse(result.Five9BtnsCode_003);
        if (Array.isArray(newButtons) && newButtons.length > 0) {
          buttons.splice(0, buttons.length, ...newButtons);
        }
      } catch (e) {
        console.error('Failed to parse button data from storage:', e);
      }
    }
  });
}

chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.Five9BtnsCode_003) {
    updateButtonsFromStorage(buttons);
  }
});


function addStyles() {
  const css = `
    #dispoContainer {
      display: flex;
      align-items: initial;
      justify-content: center;
      flex-wrap: wrap;
      background-color: #f2f2f2;
    }

    .dispo_main_button {
      margin-top: 1em;
      margin-bottom: 1em;
      padding: 0 10px;
      cursor: pointer;
    }

    .dispo_sub_button {
      display: none;
    }

    .dispo_main_button:hover .dispo_sub_button,
    .dispo_main_button:focus .dispo_sub_button {
      display: block;
      padding-top: 3px;
    }

    .button-label {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      width: 100%;
      white-space: pre-wrap;
      text-align: center;
      font-family: Arial, sans-serif;
    }
  `;

  const style = document.createElement('style');
  style.appendChild(document.createTextNode(css));
  document.head.appendChild(style);
}

function createSVGButton(options, clazz, parent) {
  const [{buttonsWidth: width = 93, buttonsHeight: height = 32}] = buttons;
  console.log(width, height);
  const button = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  button.setAttribute("width", width.toString());
  button.setAttribute("height", height.toString());
  if (options.label) {
    button.innerHTML = `
      <rect width="${width}" height="${height}" fill="${options.bgColor}"></rect>
      <foreignObject x="0" y="0" width="${width}" height="${height}">
        <div class="button-label" style="font-size: ${options.fontSize}px; font-weight: ${options.fontWeight}; color: ${options.textColor};">${options.label.toUpperCase()}</div>
      </foreignObject>
    `;
  }
  const wrapper = document.createElement("div");
  wrapper.appendChild(button);
  wrapper.className = clazz;
  parent && parent.appendChild(wrapper);
  return wrapper;
}



function performClickOnDispositionItem(keyword) {
  let item = [...document.querySelectorAll(".disposition-item > .tt")]
    .find(i => i.innerText === keyword);
  if (item) {
    item.click();
  } else {
    console.error(`Disposition item with keyword "${keyword}" not found`);
  }
}

function addButtonEventListener(element, keyword) {
  element.addEventListener("click", function () {
    performClickOnDispositionItem(keyword);
  });
}

function getDispositionItem(keyword) {
  let item = [...document.querySelectorAll(".disposition-item > .tt")].find(
    (i) =>    i.innerText === keyword
    );
    return item;
  }
  "use strict";

function callMain(
  extObserver,
  section,
  modal,
  urlState)
{
  const isCall = createIsInSection(urlState);
  const call = createInSection(section, modal, extObserver);
  const callLeft = createLeftSection(extObserver);
  flashcardsMain();
  stateSection(isCall, call, callLeft);
}

function urlCallState() {
  let url = window.location.href;
  return url.endsWith("role=Agent#agent/voice");
}

function createCallObservation() {
  return new function() {
    const self = this;

    self.callObservation = function(mutations, observer) {
      let interactionHeader = mutations
        .map(r => r.target)
        .find(t => t.className==="interaction-header");

      if (interactionHeader) {
        let dispo = interactionHeader.querySelector("#dispoContainer");
        if (!dispo)
          interactionHeader.appendChild(createDispositions());
      }

      flashcardsMain(mutations);
    };

    self.callModalObservation = function(mutations, observer) {
      let callNotificationDialogOkButton = querySingle(mutations,
        "#CallNotificationDialog-ok-button");
      if (callNotificationDialogOkButton) {
        callNotificationDialogOkButton.click();
      }
    };
  };
}

async function init() {
  const buttons = await saveButtonsToStorage();
  updateButtonsFromStorage(buttons);
  addStyles();

}

// Replace the old dispositions function with the new createDispositions function
function createDispositions() {
  addStyles();

  const parentButtons = buttons.filter(button => button.main);
  const parentMap = new Map(parentButtons.map(({ label }, index) => [label, index]));

  const dispoContainer = document.createElement('div');
  dispoContainer.id = 'dispoContainer';

  buttons.forEach(button => {
    const clazz = button.main ? "dispo_main_button" : "dispo_sub_button";
    const parent = button.parentButton ? parentButtons[parentMap.get(button.parentButton)].element : dispoContainer;
    const newButton = createSVGButton(button, clazz, parent);
    button.element = newButton;
    button.keyword && addButtonEventListener(newButton, button.keyword);
    button.main && dispoContainer.appendChild(newButton);
  });

  return dispoContainer;
}

init()



//////////

function buttonClick(e) {
  if (e.altKey) {
      switch (e.key.toLowerCase()) {
          case 'h':
              performClickOnDispositionItem("Not Available Human - Agent");
              break;
          case 'm':
              performClickOnDispositionItem("Not Available Machine - Agent");
              break;
          case 'n':
              performClickOnDispositionItem("Not Interested - Agent");
              break;
          case 'l':
              performClickOnDispositionItem("Listed on MLS - Agent");
              break;
          case 'w':
              performClickOnDispositionItem("Wrong Number - Agent");
              break;
          case 'v':
              performClickOnDispositionItem("Voicemail - Agent");
              break;
          case 's':
              performClickOnDispositionItem("Already Sold Home - Agent");
              break;
          case 'c':
              performClickOnDispositionItem("Callback - Agent");
              break;
      }
  }
}
window.addEventListener("keydown", buttonClick);


window.addEventListener('blur', function() {
  window.setTimeout(function() {
      window.focus();
  }, 100);
});

//Extract contact info fields
function contactField(dataid) {
  const labelNodes = document.querySelectorAll('#ContactFormInput-input-label');
  
  for (let i = 0; i < labelNodes.length; i++) {
    const labelNode = labelNodes[i];
    if (labelNode.innerText === dataid) {
      const valueNode = labelNode.nextElementSibling.querySelector('input');
      if (valueNode) {
        const value = valueNode.value;
        console.log(value);
        return value;
      }
    }
  }
  
  return null;
}

setTimeout(() => {
  contactField('City');
  contactField('Street');
  contactField('State');
  contactField('Zip');
  contactField('sd_webform');
}, 25000);


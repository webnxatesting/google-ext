// Fetch the json
	function fetchAgents() {
    fetch('https://webtools.lamassucrm.com:3000/rs/agents/list')
    .then(response => response.json())
    .then(data => {
      let agents = {};
      data.forEach(agent => {
        agents[agent.agent_code] = {name: agent.agent_name, photo_url: agent.photo_url, agent_team:agent.agent_team}
      });
      window.agents = agents;
      console.log(window.agents);
    })
    .catch(err => {
      console.log(err);
    });
  }

    
  setInterval(() => {
	fetchAgents()
}, 1800000);

//Modified Code

function parseText(textArea) {
  let lastAgent = textArea.innerHTML.match(/sd_last_agent : (.*)/);
  let lastCampaign = textArea.innerHTML.match(/sd_last_campaign : (.*)/);
  let lastDisposition = textArea.innerHTML.match(/Disposition "([^"]+)"/);

  let agent_code = lastAgent[1];
  let agent_name = window.agents[agent_code] ? window.agents[agent_code].name : lastAgent[1];
  let photo_url = window.agents[agent_code] ? window.agents[agent_code].photo_url : "https://i.postimg.cc/7LCgXp0B/image.png";
  let agent_team = window.agents[agent_code] ? window.agents[agent_code].agent_team : "Contact admin";
  
  
  let message = {
    type: "create_notification",
    data: {
      name: agent_name,
      campaign: lastCampaign[1].replace('_OUTBOUND', '').replace('_', ' '),
      sd_last_disposition: lastDisposition[1].replace(' Web Form', '').replace(' Live Transfer', ''),
      photo_url: photo_url.replace(/-512$/, '-72'),
      agentName: agent_name,
      agentTeam: agent_team
    }
  }
  chrome.runtime.sendMessage(message);
}

    setTimeout(() => {
      fetchAgents()
// Create the mutation observer
let observerModal = new MutationObserver(mutations => {
  mutations.forEach(mutation => {
    // Make sure the mutation was a childList
    if (mutation.type === 'childList') {
      // Get the div with the random ID
      let div = mutation.target.querySelector('div[id]');
      // Make sure the div was found
      if (div) {
        // Get the textarea
        let textArea = div.querySelector('textarea');
        // Make sure the textarea was found
        if (textArea) {
          parseText(textArea);
        }
      }
      
      // Auto click the broadcast button to avoid popup message window
      let broadcastButton = document.querySelector("#broadcast-dialog > div > div > div.f9-modal-footer.text-center > button > span");
      if (broadcastButton) {
       broadcastButton.click();
      }
    }
  });
});

// Start listening for changes to the modal
observerModal.observe(document.querySelector('#modal'), {
  childList: true
});

// Parse the text
let textArea = document.querySelector('#modal textarea');
if (textArea) {
  parseText(textArea);
}
      }, 15000);

"use strict";

//You need to rename this file to five9-call.js for it to work
function callMain(
  extObserver,
  section,
  modal,
  urlState)
{
  const isCall = createIsInSection(urlState);
  const call = createInSection(section, modal, extObserver);
  const callLeft = createLeftSection(extObserver);
  flashcardsMain();
  stateSection(isCall, call, callLeft);
}

function urlCallState() {
  let url = window.location.href;
  return url.endsWith("role=Agent#agent/voice");
}

function createCallObservation() {
  return new function() {
    const self = this;

    self.callObservation = function(mutations, observer) {
      let interactionHeader = mutations
        .map(r => r.target)
        .find(t => t.className==="interaction-header");

      if (interactionHeader) {
        let dispo = interactionHeader.querySelector("#dispoContainer");
        if (!dispo)
          interactionHeader.appendChild(dispositions());
      }
  
      flashcardsMain(mutations);
    };

    self.callModalObservation = function(mutations, observer) {
      let callNotificationDialogOkButton = querySingle(mutations,
        "#CallNotificationDialog-ok-button");
      if (callNotificationDialogOkButton) {
        callNotificationDialogOkButton.click();
      }
    };
  };
}

function dispositions() {
  function createImg(src, clazz, parent) {
    let button = document.createElement("img");
    button.src = chrome.runtime.getURL(src);

    let wrapper = document.createElement("div");
    wrapper.appendChild(button);
    wrapper.className = clazz;
    if (parent !== null) {
      parent.appendChild(wrapper);
    }
    return wrapper;
  }

  function getDispositionItem(keyword) {
    let item = [... document.querySelectorAll(".disposition-item > .tt")]
      .find(i => i.innerText===keyword);
    return item;
  }

  function performClickOnDispositionItem(keyword) {
    let items = getDispositionItem(keyword);
    items.click();
  }

  let dispoContainer = document.createElement('div');
  dispoContainer.id = 'dispoContainer';

  let button_1 = createImg("img/five9-buttons-data/1.DATA-REQUEST.png", "dispo_main_button_1", dispoContainer);
  button_1.addEventListener('click', function() {
    performClickOnDispositionItem("Data Request");
  });

  ////////////////////////////////////////////////////////////////////
  let button_2 = createImg("img/five9-buttons-data/2.NOT-AVAILABLE.png", "dispo_main_button_2", dispoContainer);

  let button_2_1 = createImg("img/five9-buttons-data/2.1.NOT-AVAILABLE-HUMAN.png", "dispo_sub_button_2", button_2);
  button_2_1.addEventListener('click', function() {
    performClickOnDispositionItem("Not Available Human");
  });

  let button_2_2 = createImg("img/five9-buttons-data/2.2.NOT-AVAILABLE-MACHINE.png", "dispo_sub_button_2", button_2);
  button_2_2.addEventListener('click', function() {
    performClickOnDispositionItem("Not Available Machine");
  });
////////////////////////////////////////////////////////////////////
  let button_3 = createImg("img/five9-buttons-data/3.ACTIVE-AFFILIATE.png", "dispo_main_button_3", dispoContainer);
  button_3.addEventListener('click', function() {
    performClickOnDispositionItem("Active Affiliate");
  });

  let button_4 = createImg("img/five9-buttons-data/4.WRONG-NUMBER.png", "dispo_main_button_4", dispoContainer);
  button_4.addEventListener('click', function() {
    performClickOnDispositionItem("Wrong Number");
  });

  let button_5 = createImg("img/five9-buttons-data/5.VOICEMAIL.png", "dispo_main_button_5", dispoContainer);
  button_5.addEventListener('click', function() {
    performClickOnDispositionItem("Voicemail");
  });

  let button_6 = createImg("img/five9-buttons-data/6.CALLBACK.png", "dispo_main_button_6", dispoContainer);
  button_6.addEventListener('click', function() {
    performClickOnDispositionItem("Callback");
  });
////////////////////////////////////////////////////////////////////
  let button_7 = createImg("img/five9-buttons-data/7.NOT-INTERESTED.png", "dispo_main_button_7", dispoContainer);

  let button_7_1 = createImg("img/five9-buttons-data/7.1.NOT-INTERESTED-DT.png", "dispo_sub_button_7", button_7);
  button_7_1.addEventListener('click', function() {
    performClickOnDispositionItem("Not Interested DT");
  });

  let button_7_2 = createImg("img/five9-buttons-data/7.2.NOT-INTERESTED-RE.png", "dispo_sub_button_7", button_7);
  button_7_2.addEventListener('click', function() {
    performClickOnDispositionItem("Not Interested No Real Estate");
  });
////////////////////////////////////////////////////////////////////
  let button_8 = createImg("img/five9-buttons-data/8.DNC.png", "dispo_main_button_8", dispoContainer);

  let button_8_1 = createImg("img/five9-buttons-data/8.1.DNC-NOT-INTERESTED.png", "dispo_sub_button_8", button_8);
  button_8_1.addEventListener('click', function() {
    performClickOnDispositionItem("DNC Not Interested");
  });

  let button_8_2 = createImg("img/five9-buttons-data/8.2.DNC-WRONG-NUMBER.png", "dispo_sub_button_8", button_8);
  button_8_2.addEventListener('click', function() {
    performClickOnDispositionItem("DNC Wrong Number");
  });
////////////////////////////////////////////////////////////////////
  //Keyboard Shortcuts
  // function buttonClick(e) {
  //   if (e.altKey && (e.key === "h" || e.key === "H")) {
  //     performClickOnDispositionItem("Not Available Human");
  //   }
  //   if (e.altKey && (e.key === "m" || e.key === "M")) {
  //     performClickOnDispositionItem("Not Available Machine");
  //   }
  //   if (e.altKey && (e.key === "n" || e.key === "N")) {
  //     performClickOnDispositionItem("Not Interested");
  //   }
  //   if (e.altKey && (e.key === "l" || e.key === "L")) {
  //     performClickOnDispositionItem("Listed on MLS");
  //   }
  //   if (e.altKey && (e.key === "w" || e.key === "W")) {
  //     performClickOnDispositionItem("Wrong Number");
  //   }
  //    if (e.altKey && (e.key === "v" || e.key === "V")) {
  //     performClickOnDispositionItem("Voicemail");
  //   }
  //    if (e.altKey && (e.key === "s" || e.key === "S")) {
  //     performClickOnDispositionItem("Already Sold Home");
  //   }
  //   if (e.altKey && (e.key === "c" || e.key === "C")) {
  //     performClickOnDispositionItem("Callback");
  //   }
  // }
  // window.addEventListener("keydown", buttonClick);

  // return dispoContainer;

  //Keyboard Shortcuts with setTimeout
  function buttonClick(e) {
    if (e.altKey && (e.key === "h" || e.key === "H")) {
      setTimeout(function() { performClickOnDispositionItem("Not Available Human")  }, 100);
        }
    if (e.altKey && (e.key === "m" || e.key === "M")) {
      setTimeout(function() { performClickOnDispositionItem("Not Available Machine")  }, 100);
    }
    if (e.altKey && (e.key === "n" || e.key === "N")) {
      setTimeout(function() { performClickOnDispositionItem("Not Interested")  }, 100);
    }
    if (e.altKey && (e.key === "l" || e.key === "L")) {
      setTimeout(function() { performClickOnDispositionItem("Listed on MLS")  }, 100);
    }
    if (e.altKey && (e.key === "w" || e.key === "W")) {
      setTimeout(function() { performClickOnDispositionItem("Wrong Number")  }, 100);
    }
     if (e.altKey && (e.key === "v" || e.key === "V")) {
      setTimeout(function() { performClickOnDispositionItem("Voicemail")  }, 100);
    }
     if (e.altKey && (e.key === "s" || e.key === "S")) {
      setTimeout(function() { performClickOnDispositionItem("Already Sold Home")  }, 100);
    }
    if (e.altKey && (e.key === "c" || e.key === "C")) {
      setTimeout(function() { performClickOnDispositionItem("Callback")  }, 100);
    }
  }
  window.addEventListener("keydown", buttonClick);
  
  return dispoContainer;
}




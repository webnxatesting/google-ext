// This function injects the required HTML to display agent nicknames.
let isAgentNicksAdded = false;

function startObservingTable_6() {
    const targetNode = document.body;
    const config = {
        childList: true,
        subtree: true
    };

    const callback = function (mutationsList) {
        for (let mutation of mutationsList) {
            if (mutation.type === 'childList') {
                let table = document.getElementById("Table_6");
                if (!isAgentNicksAdded && table && table.querySelector("tbody") && table.querySelectorAll("tbody tr").length >= 4) { // <-- Check for the safeguard
                    agentNicks();
                    isAgentNicksAdded = true;  // <-- Set the safeguard
                    observer.disconnect(); // Disconnect after we've found our table
                }
            }
        }
    };

    const observer = new MutationObserver(callback);
    observer.observe(targetNode, config);
}

function agentNicks() {
    const htmlString = `
      <tr>
          <td>AGENTS NICKNAMES:</td>
          <td align="left" id="agentNicksContainer">
              Select nicknames for the current call <br>
              <button class="nicknameButton" tabindex="-1">Add Nickname</button>
              <button class="deleteNicknamesButton" tabindex="-1">Delete All</button>
              <select name="agentNicks" id="agentNicks">
                  <option value="">Your Agent Nickname on this call</option>
              </select>
          </td>
      </tr>
    `;

    const table = document.getElementById("Table_6");
    if (!table) {
        console.error("Table with ID 'Table_6' not found!");
        return;
    }

    const tbody = table.querySelector("tbody");
    if (!tbody) {
        console.error("No tbody found in table!");
        return;
    }

    const rows = tbody.querySelectorAll("tr");
    if (rows.length < 4) {
        console.error("There are fewer than 4 rows in the table.");
        return;
    }

    rows[4].insertAdjacentHTML("afterend", htmlString);

    getAgentNicknamesFromLocalStorage()
        .then((savedNicknames) => {
            if (savedNicknames && savedNicknames.length > 0) {
                updateNicknameDropdown(savedNicknames);
            }
        })
        .catch((error) => console.error("Error fetching nicknames:", error));

    document.addEventListener('click', function (event) {
        if (event.target.matches('.nicknameButton')) {
            event.preventDefault();
            const newNickname = prompt('Enter a new agent nickname. \n -> Include name and lastname:');
            if (newNickname && newNickname.trim() !== '') {
                addNewAgentNickname(newNickname);
            }
        } else if (event.target.matches('.deleteNicknamesButton')) {
            event.preventDefault();
            if (confirm('Are you sure you want to delete all nicknames?')) {
                deleteAllNicknames();
            }
        }
    });
}

// This function fetches the agent nicknames from the Chrome local storage.
function getAgentNicknamesFromLocalStorage() {
    return new Promise((resolve, reject) => {
        chrome.storage.sync.get('agentNicknames', function (result) {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError));
            } else {
                resolve(result.agentNicknames || []);
            }
        });
    });
}

// This function saves the agent nicknames to the Chrome local storage.
function saveAgentNicknamesToLocalStorage(nicknames) {
    chrome.storage.sync.set({ 'agentNicknames': nicknames }, function () {
        if (chrome.runtime.lastError) {
            console.error("Error saving nicknames:", chrome.runtime.lastError);
            return;
        }
        console.log("Nicknames saved:", nicknames);
    });
}

// This function adds a new agent nickname.
async function addNewAgentNickname(nickname) {
    try {
        // Convert the nickname to uppercase and put it inside brackets
        const formattedNickname = `[${nickname.toUpperCase()}]`;

        const agentNicknames = await getAgentNicknamesFromLocalStorage();
        const nextId = agentNicknames.length > 0 ? Math.max(...agentNicknames.map(nick => nick.id)) + 1 : 1;
        const newAgent = { id: nextId, nickname: formattedNickname };
        agentNicknames.push(newAgent);
        saveAgentNicknamesToLocalStorage(agentNicknames);
        updateNicknameDropdown(agentNicknames);
    } catch (error) {
        console.error("Error adding new agent nickname:", error);
    }
}


// This function deletes all agent nicknames.
function deleteAllNicknames() {
    chrome.storage.sync.remove('agentNicknames', function () {
        if (chrome.runtime.lastError) {
            console.error("Error deleting nicknames:", chrome.runtime.lastError);
            return;
        }
        console.log("All nicknames deleted.");
        const dropdown = document.getElementById('agentNicks');
        while (dropdown.options.length > 1) {
            dropdown.remove(1);
        }
    });
}

// Execute the function to append the new row.
startObservingTable_6();

// This function updates the dropdown list with the provided nicknames.
function updateNicknameDropdown(agentNicknames) {
    const dropdown = document.getElementById('agentNicks');
    if (!dropdown) {
        console.error("Dropdown with ID 'agentNicks' not found!");
        return;
    }

    // Clear existing options.
    while (dropdown.firstChild) {
        dropdown.removeChild(dropdown.firstChild);
    }

    const defaultOption = document.createElement('option');
    defaultOption.textContent = 'Your Agent Nickname on this call';
    defaultOption.value = '';
    dropdown.appendChild(defaultOption);

    agentNicknames.forEach(agent => {
        const option = document.createElement('option');
        option.value = agent.id;
        option.textContent = agent.nickname;
        dropdown.appendChild(option);
    });

    // If there's only one nickname, set it as default.
    if (agentNicknames.length === 1) {
        dropdown.selectedIndex = 1;
    }
}





/////////////////////

async function validateNickname() {
    // Get the select dropdown field with id 'agentNicks'
    var dropdown = document.getElementById('agentNicks');

    // Fetch nicknames from local storage
    const agentNicknames = await getAgentNicknamesFromLocalStorage();

    // If there are no nicknames in local storage and dropdown index is 0, show the alert
    if (agentNicknames.length === 0 && dropdown.selectedIndex === 0) {
        alert("Please add your Agent's Nickname. Include name and lastname.");

        // After the user clicks "OK" on the alert, scroll to the element
        // with the class "agentNicksTR".
        var elementToScrollTo = document.querySelector('.agentNicksTR');
        if (elementToScrollTo) {
            elementToScrollTo.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
        }

        // Prevent form submission
        return false;
    }

    // Otherwise, allow form submission
    return true;
}

function observeDOMForValidationAndSubmission() {
    const targetNode = document.body;
    const config = {
        childList: true,
        subtree: true
    };

    const observerCallback = function (mutationsList, observer) {
        let dropdown = document.getElementById('agentNicks');
        let submitInput = document.querySelector('input[name="QUALIFIED"]');

        if (dropdown && submitInput) {
            validateNickname();
            
            observer.disconnect(); // Disconnect after we've set up everything
        }
    };

    const combinedObserver = new MutationObserver(observerCallback);
    combinedObserver.observe(targetNode, config);
}

observeDOMForValidationAndSubmission();
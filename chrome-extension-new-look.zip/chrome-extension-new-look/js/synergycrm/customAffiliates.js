function assetsforacres() {
  const url = new URL(window.location.href);

  if (url.hostname.startsWith("demo.")) {
    document.querySelector("#Table_3 > tbody > tr.conditions").style.display =
      "none";
    document.querySelector("#Table_3 > tbody > tr.occupied").style.display =
      "none";
    document.querySelector(
      "#Table_3 > tbody > tr.tenant_details"
    ).style.display = "none";
    document.querySelector("#Table_3 > tbody > tr:nth-child(6)").style.display =
      "none";
    document.querySelector(
      "#Table_3 > tbody > tr:nth-child(2) > td:nth-child(1)"
    ).style.display = "none";
    document.querySelector(
      "#Table_3 > tbody > tr:nth-child(2) > td:nth-child(2)"
    ).style.display = "none";
    document.querySelector(
      "#Table_3 > tbody > tr:nth-child(2) > td:nth-child(3)"
    ).style.display = "none";
    document.querySelector("#Table_3 > tbody > tr.repairs").style.display =
      "none";

    // Get all td elements in the page
    const tds = document.getElementsByTagName("td");

    for (let td of tds) {
      // Check if the td element contains 'Pool'
      if (td.innerHTML.includes("Pool:&nbsp;&nbsp;")) {
        // Replace 'Pool' with 'County'
        td.innerHTML = td.innerHTML.replace(
          "Pool:&nbsp;&nbsp;",
          "County:&nbsp;&nbsp;"
        );
        break;
      }
    }

    const Land_sqft = url.searchParams.get("Land_sqft");
    const Land_sqftformattedNumber = parseInt(Land_sqft).toLocaleString();
    const Land_sqft_result = `${Land_sqftformattedNumber} sqft`;
    var acres = (Land_sqft / 43560).toFixed(2);

    const Market_Value = url.searchParams.get("marketValue");
    const Market_ValueformattedNumber = parseInt(Market_Value).toLocaleString();
    const Market_Value_result = `$${Market_ValueformattedNumber}`;

    // Get the 'County' parameter from the URL's query string
    const county = url.searchParams.get("County");

    // If 'County' parameter exists
    if (county !== null) {
      // Find the 'pool' input element
      const poolInput = document.getElementById("pool");

      // If 'pool' input element exists
      if (poolInput !== null) {
        // Set its value to the 'County' parameter's value
        poolInput.value = county;
      }
    }

    let addressTR = document.querySelector("#Table_2 > tbody > tr.note"); //document.querySelector("body > form > table:nth-child(4) > tbody > tr:nth-child(8)");
    var blankLandsqrftTR = [
      '<tr align="left" id="blankLandsqrftTR"><td colspan="2" bgcolor="#F7F7F7"></td></tr>',
    ].join("");
    addressTR.insertAdjacentHTML("beforebegin", blankLandsqrftTR);

    let AssetsFunctionToDOM = [
      '<td align="left">Land Square Feet (Reference):</td>',
      '<td align="left" id="landSqft" style="color: #006AFF; font-weight: 900; font-size: 20px;">' +
        Land_sqft_result +
        " - " +
        acres +
        " (Acres)<br></td>",

      '<td align="left">MARKET LAND VALUE:</td>',
      '<td align="left" id="marketValue" style="color: #006AFF; font-weight: 900; font-size: 20px;">' +
        Market_Value_result +
        " <br></td>",
    ].join("");

    document
      .getElementById("blankLandsqrftTR")
      .insertAdjacentHTML("beforebegin", AssetsFunctionToDOM);
    // add the market value to the zestimate input
    const zestimateInput = document.getElementById("zestimateInput");
    if (zestimateInput) {
      zestimateInput.value = Market_Value;
      document
        .getElementById("zestimateInput")
        .dispatchEvent(new KeyboardEvent("keyup", { keyCode: 32 }));
    }

    const targetElement = document.getElementById("AssetsFunctionToDOM");
    if (targetElement) {
      targetElement.style.color = "#006AFF";
      targetElement.style.fontWeight = "900";
      targetElement.style.fontSize = "20px";
    }

    // Add text "IF NO CITY NOR ZIPCODE, PLEASE ASK" to the content
    targetElement.innerHTML = targetElement.innerHTML.replace(
      '<br><button class="addressButton">',
      '<br><span style="color: rgba(226, 79, 69, 0.8); font-weight: 500; font-size: 16px;">IF THERE\'S NO CITY OR ZIPCODE, PLEASE ASK</span><br><button class="addressButton">'
    );
  }
}

//////////////////////////////////////////

function capitalizedTimeStamp() {
  if (window.location.hostname.startsWith("capitalized.")) {
    let abandonButton = document.querySelector('input[name="QUALIFIED"]');

    if (abandonButton) {
      abandonButton.addEventListener("click", function () {
        let textarea = document.getElementById("note");
        if (textarea) {
          let now = new Date();
          let date =
            String(now.getMonth() + 1).padStart(2, "0") +
            "-" +
            String(now.getDate()).padStart(2, "0") +
            "-" +
            now.getFullYear();
          let hours = String(now.getHours()).padStart(2, "0");
          let minutes = String(now.getMinutes()).padStart(2, "0");
          let time = hours + "." + minutes;
          let timestamp = '"TIMESTAMP DATE: ' + date + " - HOUR: " + time + '"';
          textarea.value = timestamp + "\n" + "||" + textarea.value;
        } else {
          console.log("Error: Could not find textarea with id 'note'");
        }
      });
    } else {
      console.log("Error: Could not find input with name 'ABANDON'");
    }
  }
}

////////////////////
function hideLiveTransferBtnIPS() {
  if (window.location.hostname.startsWith("ips.")) {
    const buttons = document.querySelectorAll(
      ".LAMASSUCOLDCALL\\(LIVETRANSTER\\)"
    );

    buttons.forEach((button) => {
      button.style.display = "none";
    });
  }
}

// function createEmailValueforSkylux() {
//   if (window.location.hostname.startsWith("skylux.")) {
//     const submitButton = document.querySelector('input[name="QUALIFIED"]');

//     const originalOnClick = submitButton.onclick;

//     submitButton.onclick = function () {
//       let emailAddressInput = document.getElementById("EmailAddress");
//       let emailAddress = emailAddressInput.value.trim();

//       if (!emailAddress) {
//         emailAddressInput.value = "none@none.com";
//       }

//       console.log(emailAddressInput.value);

//       if (typeof originalOnClick === "function") {
//         return originalOnClick();
//       }
//     };
//   }
// }
const customTrustedHideTables = () => {
  if (window.location.hostname.startsWith("trusted.") || window.location.hostname.startsWith("trustedsfl.")) {
  const tables = document.querySelectorAll("#Table_3, #Table_4");
  tables.forEach((table) => {
    table.style.display = "none";
  });
  
  document.querySelector("#other-costs-table > thead > tr > td:nth-child(1) > button").click();

  const alertTrustedFields = () => {
    const alertMessage = "REMEMBER: \n\nFields for 'Propery Details' and 'Mortgage have been eliminated for TRUSTED. \n\n ----------------------\nYou don't need to ask those questions...\n ----------------------";
    alert(alertMessage);
  };
  
  alertTrustedFields();
}
};


//////////////////////UNIFIED
// Function to check if the current domain is either "unified" or "truehomes"
function isValidDomain() {
  return window.location.hostname.startsWith("unified.") || window.location.hostname.startsWith("truehomes.");
}
function getInitialValue() {
  let initialValue;
  const hostname = window.location.hostname;
  
  switch (true) {
    case hostname.startsWith("unified."):
      initialValue = 120;
      break;
    case hostname.startsWith("truehomes."):
      initialValue = 125;
      break;
    default:
      initialValue = 150; // default value
  }
  
  return initialValue;
}

function unifiedZestimate() {
  if (isValidDomain()) {
    // Get the initial value based on the domain
    const initialValue = getInitialValue();

    // The initial value is injected using ${initialValue}
    var innerHTML = `
      <th class="zestimate" colspan="6">
        <span id="zestimateTitle" class="zestimateTitle">ZESTIMATE</span> &nbsp;
        <span class="currency">$</span>
        <input class="zestimateInputUnified" type="text" style="width: 120px; color: rgb(22, 70, 143); font-weight: bold; text-align: center; font-size: 18px; border-radius: 15px;" size="25" value=""> x 
        <input class="inrangeRuleUnified" type="number" style="width: 60px;" value="${initialValue}"> % 
        <span class="unifiedAskingPrice" style="color:white">ASKING PRICE:</span> &nbsp;
        $ <span id="zestimateInputUnifiedMirror" tabindex="-1" style="color:white; background-color:black;"></span>
      </th>
    `;

// Get the unifiedZestimatePosition element
var unifiedZestimatePosition = document.querySelector("#Table_5_1 > tbody ");

// Insert the innerHTML at the specified position (beforeend)
unifiedZestimatePosition.insertAdjacentHTML("afterend", innerHTML);

// Function to calculate and update the span based on input and percentage values
function calculateAndUpdate() {
  var percentageValue = parseFloat(document.querySelector('.inrangeRuleUnified').value) / 100 || 1.5; 
  var inputValue = document.querySelector('.zestimateInputUnified').value || '0'; 
  inputValue = parseFloat(inputValue.replace(/,/g, '')); 

  var result = inputValue * percentageValue;

  // Add thousand separators to the result
  var formattedResult = result.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
  document.getElementById('zestimateInputUnifiedMirror').textContent = formattedResult;
}

// Add event listener to format zestimateInputUnified with thousand separators and only accept numbers
document.querySelector('.zestimateInputUnified').addEventListener('input', function (e) {
  var value = e.target.value.replace(/,/g, ''); // Remove any existing commas
  var numValue = parseFloat(value.replace(/\D/g, '')); // Remove non-numeric characters
  e.target.value = isNaN(numValue) ? '' : numValue.toLocaleString('en-US'); // Format with thousand separators or clear if not a number
  calculateAndUpdate();
});

// Add event listener to percentage input to update the span content
document.querySelector('.inrangeRuleUnified').addEventListener('input', calculateAndUpdate);

// Call the calculateAndUpdate function initially to set the initial value
calculateAndUpdate();
}
}

// Utility function to create input elements (No changes here, so keeping it as is)
function createInputElement(className, width, size, type = 'number', value = '') {
  return `<input class="${className}" type="${type}" style="width: ${width}px;" size="${size}" value="${value}"> `;
}

function hideMatrixInUnified() {
  if (isValidDomain()) {
    // List of selectors for elements to be hidden
    var selectors = [
      "#matrix-responsive-XL > thead > tr:nth-child(3) > th",
      "#matrixTbody > tr:nth-child(2)",
      "#matrixTbody > tr:nth-child(3)",
      "#matrixTbody > tr:nth-child(4)",
      "#matrixTbody > tr:nth-child(5)",
      "#matrixTbody > tr:nth-child(6)",
      "#otherCostsTR"
    ];
    
    // Iterate through the list of selectors
    for (var i = 0; i < selectors.length; i++) {
      // Get the element using the current selector
      var element = document.querySelector(selectors[i]);
      
      // Check if the element exists to avoid errors
      if (element) {
        // Set the display property to none to hide the element
        element.style.display = "none";
      } else {
        console.warn(`Element with selector '${selectors[i]}' not found.`);
      }
    }
  }
}


function nurtureIBUYSD() {
  if (window.location.hostname.startsWith("nurtureibuysd.")) {
      let observer = new MutationObserver((mutations) => {
          let element1 = document.querySelector("#matrix-responsive-XL");
          if (element1) {
              element1.style.display = "none";
          }

          let element2 = document.querySelector("#Table_3 > tbody > tr.repairs");
          if (element2) {
              element2.style.display = "none";
          }

          let element3 = document.querySelector("#Table_3 > tbody > tr:nth-child(2)");
          if (element3) {
              element3.style.display = "none";
          }

      
          if (element1 && element2 && element3) {
              observer.disconnect();
          }
      });

   
      observer.observe(document.body, { childList: true, subtree: true });
  }
}


nurtureIBUYSD();
/////////////////

function customBaileyreal() {
  // Check if the hostname starts with "baileyreal."
  if (window.location.hostname.startsWith("baileyreal.")) {
    const url = new URL(window.location.href);
    // Select the propertyDetails table using the provided selector
    var propertyDetailsTable = document.querySelector("body > form > table:nth-child(5)");
    
    // Check if the table exists in the DOM
    if (propertyDetailsTable) {
      // Set the display property to none to hide it
      propertyDetailsTable.style.display = 'none';
      
      document.querySelector("#otherCostsTR").style.display = 'none';
      

    } else {
      console.warn('Property details table could not be found.');
    }

    const Market_Value = url.searchParams.get("Areacode");
    // Remove non-numeric characters except for the decimal point, then convert to a number
    const Market_ValueNumber = Market_Value && typeof Market_Value === 'string' ? Number(Market_Value.replace(/[^0-9.]+/g, "")) : 'NOT FOUND';

    // Format the number as a currency
    const Market_Value_result = Market_ValueNumber.toLocaleString('en-US', { style: 'currency', currency: 'USD' });

  console.log("zipcode yeah!")
      // Get the 'Company' parameter from the URL's query string
      const company = url.searchParams.get("company");
      // Find the 'ZipCode' input element
      const zipCodeInput = document.getElementById("ZipCode");
      // If 'ZipCode' input element exists and 'Company' parameter exists
setInterval(() => {
        if (zipCodeInput !== null && company !== null) {
          // Set its value to the 'Company' parameter's value and make it read-only
          zipCodeInput.value = company;
          zipCodeInput.readOnly = true; // Make the input not editable
        }
  
}, 2000);

    let addressTR = document.querySelector("#Table_2 > tbody > tr:nth-child(10)");
    var blankLandsqrftTR = [
      '<tr align="left" id="blankLandsqrftTR"><td colspan="2" bgcolor="#F7F7F7"></td></tr>',
    ].join("");
    addressTR.insertAdjacentHTML("beforebegin", blankLandsqrftTR);

    let BaileyrealFunctionToDOM = [
      '<td align="left">MARKET LAND VALUE:</td>',
      '<td align="left" id="marketValue" style="color: #006AFF; font-weight: 900; font-size: 20px;">' +
        Market_Value_result +
        " <br></td>",
    ].join("");

    document
      .getElementById("blankLandsqrftTR")
      .insertAdjacentHTML("beforebegin", BaileyrealFunctionToDOM);
    
    // Add the market value to the zestimate input
    const zestimateInput = document.getElementById("zestimateInput");
    if (zestimateInput) {
      zestimateInput.value = Market_ValueNumber; // Assuming you want the number without currency formatting here
      zestimateInput.dispatchEvent(new KeyboardEvent("keyup", { keyCode: 32 }));
    }

    const targetElement = document.getElementById("BaileyrealFunctionToDOM");
    if (targetElement) {
      targetElement.style.color = "#006AFF";
      targetElement.style.fontWeight = "900";
      targetElement.style.fontSize = "20px";
    }
  }
}


// Run the function to hide the table if the condition is met
function customLANDBackground() {
  // Check if the hostname starts with 'baileyreal.' or contains '.vacantland'
  if (window.location.hostname.startsWith("baileyreal.") || window.location.hostname.includes("vacantland.")) {

    
    // Change <h2> content for baileyreal and vacantland subdomains
    var h2Element = document.querySelector("#Table_1 > tbody > tr:nth-child(1) > td:nth-child(2) > h2");
    if (h2Element && h2Element.textContent === "New Lead Form") {
      h2Element.textContent = "New Lead Form for LAND";
    }

    // Hide the buttons with classes 'home-details' and 'realtor'
    var homeDetailsButton = document.querySelector("button.home-details.miniTemplatesBtn");
    console.log(homeDetailsButton);

    var realtorButton = document.querySelector("button.realtor.miniTemplatesBtn");
    console.log(realtorButton);

    if (homeDetailsButton) {
      homeDetailsButton.style.display = "none";
    }
    
    if (realtorButton) {
      realtorButton.style.display = "none";
    }
    
  } else if (window.location.hostname.endsWith("lamassucrm.com")) {
    // Set the body background image to a linear gradient for all other subdomains of lamassucrm.com
    // document.body.style.backgroundImage = "linear-gradient(to bottom, #7FB3D5, #0e4467)";
    // document.body.style.transition = "background-color 0.1s";
    document.body.style.backfaceVisibility = "hidden";
  }
}




function getUrlParam(param) {
  const params = new URLSearchParams(window.location.search);
  return params.get(param);
}

function formatPrice(price) {
  return parseFloat(price).toLocaleString('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  });
}

function isHotCounty(county) {
  const hotCounties = ['Beaufort', 'Berkeley', 'Jasper', 'Dorchester', 'Spartanburg'];
  return hotCounties.includes(county);
}

function getLotAcreageRange(lotAcreage, county) {
  if (isHotCounty(county) && lotAcreage >= 30 && lotAcreage <= 100) {
    return `
      <span style="color: green; font-weight: bold; animation: blink 1s ease-in-out infinite;">
        HOT LEAD IN HOT COUNTY, YOU WANT TO TO TALK WITH THIS SELLER!! AND COME TALK TO THE CSM!
      </span><br>
      <style>
        @keyframes blink {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0;
          }
        }
      </style>
    `;
  } else {
    return '';
  }
}

function getStaticInfo() {
  const lotAcreage = parseFloat(getUrlParam('Lot_Acreage')) || 0;
  const offerPrice = parseFloat((getUrlParam('Offer_Price') || '').replace('$', '')) || 0;
  const county = getUrlParam('County');
  const APN = getUrlParam('address');

  let staticMessage = `- Lot Acreage: ${lotAcreage} acres<br>- Offer Price: ${formatPrice(offerPrice)}<br>`;
  if (county) staticMessage += `- County: ${county}<br>`;

  // Call getLotAcreageRange and append its result to staticMessage
  staticMessage += getLotAcreageRange(lotAcreage, county);

  if (APN) staticMessage += `<br>APN for this property: ${APN}<br>`;
  if (county === 'Laurens') {
    staticMessage += "<br><span style='color: green;'>SEARCH INFO ON LAURENS COUNTY WEBSITE USING THE APN: <a href='https://www.laurenscountygis.org/parcel/' target='_blank'>https://www.laurenscountygis.org/parcel/</a></span><br>";
  }
  return staticMessage;
}

function getHeplerRules(heplerAskingPrice, lotAcreage, offerPrice) {
  const formattedHeplerAskingPrice = formatPrice(heplerAskingPrice);
  let message = `<br>Hepler Rules based on the asking Price of ${formattedHeplerAskingPrice}:\n`;
  let range = '';

  const heplerToOfferRatio = (heplerAskingPrice / offerPrice) * 100;

  if (heplerToOfferRatio >= 0 && heplerToOfferRatio <= 100) {
    range = 'inRange';
  } else if (heplerToOfferRatio > 100 && heplerToOfferRatio <= 130) {
    range = 'aboveRange';
  } else if (heplerToOfferRatio > 130 && heplerToOfferRatio <= 200) {
    range = 'fullRetail';
  } else if (heplerToOfferRatio > 200) {
    range = 'outOfRange';
  }

  const attemptLiveTransfer = lotAcreage <= 50 && (range === 'inRange' || range === 'aboveRange');

  if (range === 'fullRetail') {
    message += "\n\n- <span style='color: blue; font-weight: bold;'>Full Retail</span>\n";
  } else if (range === 'outOfRange') {
    message += "\n\n- <span style='color: red; font-weight: bold;'>OUT OF ANY RANGE</span>\n";
  } else if (attemptLiveTransfer) {
    message += `\n\n- <span style='color: green; font-weight: bold;'>${range} - Attempt Live Transfer</span>\n`;
  } else {
    message += `\n\n- <span style='color: red; font-weight: bold;'>${range} - Don't Attempt Live Transfer</span>\n`;
  }

  return message;
}

function hideCalculatorOnHepler() {
  if (!window.location.hostname.startsWith('heplerland.')) return;

  [...document.querySelectorAll('#matrixTR, #otherCostsTR, #zestimateAverage, #totalAverageTR, #sendAveragesButton, #priceAverageTitle')].forEach(el => el.style.display = 'none');

  const table = document.getElementById('Table_5_1').querySelector('tbody');
  const newRow = document.createElement('tr');
  newRow.innerHTML = `
    <td></td>
    <td>
      <p style="text-align: justify; color: black; line-height: 1.2;">
        <div><b><span style="color:green">Enter an Asking Price to see HeplerLand Rules</span></b></div><br>
        <input type="text" id="heplerAskingPrice" placeholder="Enter Asking Price" style="margin-bottom: 10px; width: 120px;" size="20">
        <div id="staticInfo">${getStaticInfo()}</div>
        <div id="dynamicInfo"></div>
      </p>
    </td>
  `;
  table.insertBefore(newRow, table.querySelectorAll('tr')[5].nextSibling);

  let typingTimer;
  const typingDelay = 800;

document.getElementById('heplerAskingPrice').addEventListener('input', function(event) {
  const inputValue = event.target.value.replace(/,/g, '');

  if (inputValue === '') {
    document.getElementById('dynamicInfo').innerHTML = '';
    event.target.value = '';
  } else {
    const formattedValue = parseFloat(inputValue).toLocaleString('en-US', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    });
    event.target.value = formattedValue;

    clearTimeout(typingTimer);
    typingTimer = setTimeout(function() {
      const heplerAskingPrice = parseFloat(inputValue) || 0;
      const lotAcreage = parseFloat(getUrlParam('Lot_Acreage')) || 0;
      const offerPrice = parseFloat((getUrlParam('Offer_Price') || '').replace('$', '')) || 0;
      const dynamicResponse = getHeplerRules(heplerAskingPrice, lotAcreage, offerPrice);
      document.getElementById('dynamicInfo').innerHTML = dynamicResponse;
    }, typingDelay);
  }
});
}
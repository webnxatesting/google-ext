function firsthandpropertiesCopyBedsAndBathsToNote() {
    if (window.location.hostname.startsWith("firsthandproperties.")) {
      const submitButton = document.querySelector('input[name="QUALIFIED"]');
  
      const originalOnClick = submitButton.onclick;
  
      submitButton.onclick = function () {
        let bedroomSelect = document.getElementById("bedroom");
        let bathSelect = document.getElementById("bath");
        let noteTextarea = document.getElementById("note");
  
        let bedroomValue = bedroomSelect.value;
        let bathValue = bathSelect.value;
  
        // Appending bedroom and bath information to the note
        noteTextarea.value += `\n --- Property Bedrooms: ${bedroomValue} -- Property Baths: ${bathValue}`;
  
        if (typeof originalOnClick === "function") {
          return originalOnClick();
        }
      };
    }
  }
  
  firsthandpropertiesCopyBedsAndBathsToNote();
if (window.location.hostname.startsWith("sellers.")) {
    ///////////Custom request for Sellers Affiliate 2023-11-17 by Angy CSM
    const allowedSellersZipcodes = [
      90004, 90005, 90010, 90020, 90026, 90027, 90028, 90029, 90031, 90032,
      90038, 90039, 90041, 90042, 90057, 90065, 91001, 91006, 91007, 91011,
      91020, 91023, 91024, 91030, 91040, 91042, 91101, 91103, 91104, 91105,
      91106, 91107, 91108, 91125, 91201, 91202, 91203, 91204, 91205, 91206,
      91207, 91208, 91210, 91214, 91340, 91350, 91351, 91352, 91354, 91355,
      91383, 91384, 91387, 91390, 91501, 91502, 91504, 91505, 91506, 91605,
      91608, 91775, 91776, 91780, 91801, 91803, 93001, 93003, 93004, 93022,
      93060, 93510, 93532, 93534, 93535, 93536, 93543, 93544, 93550, 93551,
      93552, 93553, 93563, 93591, 90012, 90024, 90036, 90046, 90048, 90049,
      90067, 90068, 90069, 90077, 90095, 90210, 90211, 90212, 90263, 90265,
      90272, 90290, 90402, 90403, 91008, 91010, 91016, 91301, 91302, 91303,
      91304, 91306, 91307, 91311, 91316, 91320, 91321, 91324, 91325, 91326,
      91330, 91331, 91335, 91342, 91343, 91344, 91345, 91356, 91360, 91361,
      91362, 91364, 91367, 91377, 91381, 91401, 91402, 91403, 91405, 91406,
      91411, 91423, 91436, 91601, 91602, 91604, 91606, 91607, 91702, 91706,
      91722, 91723, 91724, 91731, 91732, 91740, 91741, 91790, 91791, 93010,
      93012, 93015, 93021, 93023, 93030, 93033, 93035, 93036, 93040, 93041,
      93042, 93043, 93063, 93065, 93066, 93222, 93225, 93243, 93252, 93560,
      90001, 90002, 90003, 90006, 90007, 90008, 90011, 90013, 90014, 90015,
      90016, 90017, 90018, 90019, 90021, 90023, 90025, 90033, 90034, 90035,
      90037, 90043, 90044, 90045, 90047, 90056, 90058, 90059, 90061, 90062,
      90063, 90064, 90066, 90071, 90089, 90094, 90220, 90221, 90222, 90230,
      90232, 90245, 90247, 90248, 90249, 90250, 90254, 90255, 90260, 90262,
      90266, 90270, 90274, 90275, 90277, 90278, 90280, 90291, 90292, 90293,
      90301, 90302, 90303, 90304, 90305, 90401, 90404, 90405, 90501, 90502,
      90503, 90504, 90505, 90506, 90710, 90717, 90731, 90732, 90744, 90745,
      90746, 90747, 90810
    ];
  
    // This variable will hold the match status
    let allowedSellersZipcodesMATCH = false;
  
    // Function to check the zip code and update the match status
    function checkZipCode() {
      const zipCodeInput = document.getElementById('ZipCode');
      const zipCodeValue = parseInt(zipCodeInput.value, 10);
      allowedSellersZipcodesMATCH = allowedSellersZipcodes.includes(zipCodeValue);
      console.log('Zip Code Match:', allowedSellersZipcodesMATCH);
    }
  
    // Check for changes every 500 milliseconds
    setInterval(checkZipCode, 500);
  
    function sellersSpanishAlert() {
      const alertMessage = "REMEMBER: \n\For the Sellers campaign in specific zip codes, if the client is a Spanish speaker, you can continue with the PROCESS. \n\n ----------------------\n Fill Address to know";
      alert(alertMessage);
    }
  
    sellersSpanishAlert();
  
    /////////////////// Function to add or remove the custom message based on the allowedSellersZipcodesMATCH status
    function customSellersSpanishMessage() {
      const targets = [
        { selector: "#Table_2 > tbody > tr:nth-child(3)", messageId: "sellersSpanishMessage1" },
        { selector: "#Table_7 > tbody > tr:nth-child(12)", messageId: "sellersSpanishMessage2" }
      ];
  
      // Helper function to add or remove the message
      function updateMessage(target, messageId) {
        const targetElement = document.querySelector(target);
        const existingMessage = document.getElementById(messageId);
  
        // HTML for positive message
        const positiveHtmlContent = `<tr align="center"><td class="sellersSpanishNotes" colspan="6"><p class="m-p" id="${messageId}"><span style="color: green;">IMPORTANT NOTICE:</span><br><span style="color: blue;">For Spanish-Speakers, <b>you can CONTINUE WITH THE PROCESS ON THIS ZIPCODE</b>.</span></p></td></tr>`;
  
        // HTML for negative message
        const negativeHtmlContent = `<tr align="center"><td class="sellersSpanishNotes" colspan="6"><p class="m-p" id="${messageId}"><span style="color: red;">IMPORTANT NOTICE:</span><br><span style="color: red;">For Spanish-Speakers, <b>this zip code is not allowed. The lead CANNOT be sent.</b></span></p></td></tr>`;
  
        // Function to handle the zip code validation and message display
        function handleZipCodeValidation() {
          const zipCodeInput = document.getElementById('ZipCode');
          const zipCodeValue = zipCodeInput.value.trim();
  
          if (zipCodeValue.length === 5 && /^\d+$/.test(zipCodeValue)) {
            if (allowedSellersZipcodesMATCH && targetElement && !existingMessage) {
              targetElement.insertAdjacentHTML('beforebegin', positiveHtmlContent);
            } else if (!allowedSellersZipcodesMATCH && targetElement && !existingMessage) {
              targetElement.insertAdjacentHTML('beforebegin', negativeHtmlContent);
            } else if ((!allowedSellersZipcodesMATCH && existingMessage && existingMessage.textContent.includes("CONTINUE WITH THE PROCESS")) ||
                       (allowedSellersZipcodesMATCH && existingMessage && existingMessage.textContent.includes("CANNOT be sent"))) {
              existingMessage.parentElement.parentElement.remove();
            }
          } else {
            if (existingMessage) {
              existingMessage.parentElement.parentElement.remove();
            }
          }
        }
  
        // Delay the zip code validation and message display by 100ms
        setTimeout(handleZipCodeValidation, 100);
      }
  
      // Update messages for each target
      targets.forEach(({ selector, messageId }) => updateMessage(selector, messageId));
    }
  
    // Interval to check the status every 500ms
    setInterval(customSellersSpanishMessage, 500);
  
    // MutationObserver to detect when the specific row is added to the DOM
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          customSellersSpanishMessage();
        }
      });
    });
  
    // Start observing the tbody element for child additions
    const tableBody = document.querySelector("#Table_2 > tbody");
    if (tableBody) {
      observer.observe(tableBody, { childList: true });
    } else {
      console.error('Table body not found for MutationObserver.');
    }
  }
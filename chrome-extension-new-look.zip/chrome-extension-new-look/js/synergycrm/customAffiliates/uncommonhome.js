function uncommonhomeCustomScript() {

    if (window.location.hostname.startsWith("uncommonhome.")) {
    // Find the table by its ID and get its <tbody> element
    var table = document.getElementById('Table_5_1').querySelector('tbody');
    
    // Create a new row
    var newRow = document.createElement('tr');
    
    // Create the first cell (empty) and append it to the new row
    var firstCell = document.createElement('td');
    newRow.appendChild(firstCell); // This cell remains empty

    // Create the second cell for content
    var secondCell = document.createElement('td');

    // Use a template literal to include all lines within a single <p> and separate them with <br>
    // This maintains efficient code while controlling line-height and text alignment
    secondCell.innerHTML = `<p style="text-align: justify; color: black; line-height: 1.2;">
    <b>MUST USE THE SCRIPT FOR  UNCOMMON</b>

    <br>Based off our conversation. It sounds like if you could  
    <br> sell the house in (timeline) to relieve the stress from (motivation) it would 
    be a no brainer.
    <br>
    <br> I am sure you have a number in mind and I just want to make sure if our local cash buyers can get you that number in (timeline)
    that you'd be ready to move forward?
    <br><br>
    {Pause}
    <br>
    <br> If YES: High Actionability Confirmed - Perfect then I'll transfer you right over!
    <br><br>
    <br> If NO: Low Actionability Confirmed (Pull Away)-
    <br> Oh well unfortunately might not work then. 
    <br>
    <br> These guys are some of the biggest buyers in town and we'd hate to waste their time since their intention will be to purchase your property. What do you suggest we should do?
    
   
                            </p>`;

    // Append the second cell (with content) to the new row
    newRow.appendChild(secondCell);

    // Locate the second <tr> within the <tbody>
    var secondRow = table.querySelectorAll('tr')[2];

    // Insert the new row after the second row
    if (secondRow.nextSibling) {
        table.insertBefore(newRow, secondRow.nextSibling);
    } else {
        // If the second row is the last child, append the new row to the table
        table.appendChild(newRow);
 
       }   }
}

uncommonhomeCustomScript()
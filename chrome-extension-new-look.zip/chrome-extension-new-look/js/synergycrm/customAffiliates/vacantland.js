

function hideCalculatorOnVacantland() {
    // Check if the hostname starts with "vacantland."
    if (window.location.hostname.startsWith("vacantland.")) {
  
  
      document.querySelector("#matrixTR").style.display = "none";
      document.querySelector("#otherCostsTR").style.display = "none";
      const url = new URL(window.location.href);
  
      const APN = url.searchParams.get("reason_for_selling");
      const county = url.searchParams.get("County") || 'Unknown';;
     
      let vacantLandAPNFunctionToDOM = [
        '<td align="left">VACANTLAND APN:</td>',
        '<td align="left" id="marketValue" style="color: #006AFF; font-weight: 900; font-size: 20px;">' + ' County: ' + county + '<br>' +
        APN +
        " <br></td>",
      ].join("");
  
      document.querySelector("#Table_2 > tbody > tr:nth-child(7)").insertAdjacentHTML("beforebegin", vacantLandAPNFunctionToDOM);
  
  
  
      // Function to execute when the button is added to the DOM
      function onButtonAdded(mutationsList, observer) {
        for (let mutation of mutationsList) {
          if (mutation.type === 'childList') {
            let button = document.querySelector("#Table_2 > tbody > tr.note > td.note > button.land-details.miniTemplatesBtn");
            if (button) {
              // Set the transition CSS property for smooth color change
              button.style.transition = 'background-color 1s ease';
  
              // Start the color change effect
              let intervalId = setInterval(() => {
                button.style.backgroundColor = button.style.backgroundColor === 'red' ? 'inherit' : 'red';
              }, 1000);
  
              button.addEventListener('click', function (e) {
                e.preventDefault();
                clearInterval(intervalId); // Stop the color changing when button is clicked
                button.style.backgroundColor = 'inherit'; // Reset to the original color
              });
  
              // Once the button is found and the code is set up, we don't need the observer anymore
              observer.disconnect();
            }
          }
        }
      }
  
      // Options for the observer (which mutations to observe)
      let config = { attributes: false, childList: true, subtree: true };
  
      // Create an observer instance linked to the callback function
      let observer = new MutationObserver(onButtonAdded);
  
      // Start observing the target node for configured mutations
      observer.observe(document.body, config);
  
    }
  }

  
  function acresCalculatorForVacantLand() {
    if (window.location.hostname.startsWith("vacantland.")) {
        const observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                if (!document.getElementById('acresCalculator')) {
                    const targetElement = document.querySelector("#Table_5 > tbody");
                    if (targetElement) {
                        const newElement = document.createElement("tr");
                        newElement.id = 'acresCalculator';
                        let selectHTML = `<select id="countySelect"><option value="">Select County</option>`;
                        for (const [county, price] of Object.entries(countyPricesPerAcre)) {
                            selectHTML += `<option value="${county}">${county}</option>`;
                        }
                        selectHTML += `</select>`;

                        newElement.innerHTML = `
                            <td><strong style="color:#006AFF">ACRES PRICE CALCULATOR: </strong></td>
                            <tr align="left">
                                <td width="100%">
                                    <strong>Select County: </strong>${selectHTML}
                                    <strong># OF ACRES: </strong>
                                    <input type="number" id="acresInput" value="1" min="0" style="width: 80px !important; margin-right: 10px;">
                                    <span id="calculatedEstimate" style="color:#006AFF"></span>
                                </td>
                            </tr>
                        `;
                        targetElement.parentNode.insertBefore(newElement, targetElement.nextSibling);
                        document.getElementById('acresInput').addEventListener('input', calculateEstimate);
                        document.getElementById('countySelect').addEventListener('change', calculateEstimate);
                        calculateEstimate();
                        observer.disconnect();
                    }
                }
            });
        });
        const config = { childList: true, subtree: true };
        observer.observe(document.body, config);
    }
}

const countyPricesPerAcre = {
  Clay: 3915,
  Owen: 3330,
  Dekalb: 7534,
  Allen: 8511,
  Harrison: 6336,
  Clark: 5852,
  Daviess: 6336,
  Kosciusko: 4487,
  Noble: 4868,
  Hancock: 13881,
  Hendricks: 6010,
  Morgan: 7296,
  Boone: 14108,
  Brown: 5594,
  Madison: 6010,
  Greene: 3096,
  Henry: 4174,
  Monroe: 9380,
  Montgomery: 4783,
  Putnam: 6416,
  Warrick: 8676,
  Huntington: 7517,
  Shelby: 7985,
  Floyd: 12278
};


function calculateEstimate() {
  const acresInput = document.getElementById('acresInput');
  const countySelect = document.getElementById('countySelect');
  const calculatedEstimateDisplay = document.getElementById('calculatedEstimate');
  if (acresInput && countySelect && calculatedEstimateDisplay) {
      const acres = parseFloat(acresInput.value) || 0;
      const county = countySelect.value;
      const pricePerAcre = countyPricesPerAcre[county] || 0; // Default to 0 if no county is selected

      const calculatedEstimateEstimate = pricePerAcre * acres;

      calculatedEstimateDisplay.textContent = `TOTAL ESTIMATE: $${calculatedEstimateEstimate.toLocaleString()}`;
  }
}


// Call the function
acresCalculatorForVacantLand();

function customFieldsHepler() {
    // Check if hostname starts with "helperland"
    if (window.location.hostname.startsWith("heplerland")) {
        // Hide elements with the ID "addressFunctionToDOM"
        document.querySelectorAll("#addressFunctionToDOM").forEach(el => el.style.display = "none");

        // Create a URL object based on the current location
        const url = new URL(window.location.href);

        // Extract parameters from the URL
        const address = url.searchParams.get("address");
        const county = url.searchParams.get("County");
        console.log(county);

        const lotAcreage = parseFloat(url.searchParams.get('Lot_Acreage')) || 0;
        let offerPrice = url.searchParams.get('Offer_Price') || '0';

        // Replace values in input fields based on URL parameters
        const cityCodeInput = document.getElementById('City');
        if (cityCodeInput) {
            cityCodeInput.value = `Lot Acreage: ${lotAcreage} -- Offer Price: $${offerPrice}`;
        }

        const streetAddressInput = document.querySelector("#StreetAddress");
        if (streetAddressInput) {
            streetAddressInput.value = address;
        }

        const zipCodeInput = document.querySelector("#ZipCode");
        console.log(zipCodeInput);
        if (zipCodeInput) {
            zipCodeInput.value = county;
        }
    }
}

// Call the function after the DOM has fully loaded
customFieldsHepler();

function customFieldsLANDExceptHostnameHepler() {
    // Create a URL object based on the current location
    const url = new URL(window.location.href);

    // Extract parameters from the URL
    const typeOfLead = url.searchParams.get("type_of_lead");
    const address = url.searchParams.get("address");
    const county = url.searchParams.get("County");
    const city = url.searchParams.get("city"); // Get the city parameter from the URL

    // Check if the hostname does not start with "heplerland" and type_of_lead is "LAND"
    if (!window.location.hostname.startsWith("heplerland.") && typeOfLead === "LAND") {
        // Hide elements with the ID "addressFunctionToDOM"
        document.querySelectorAll("#addressFunctionToDOM").forEach(el => el.style.display = "none");

        // Find and set the value of the "StreetAddress" input field
        const streetAddressInput = document.querySelector("#StreetAddress");
        if (streetAddressInput) {
            streetAddressInput.value = address;
            streetAddressInput.readOnly = true; // Optional: Make it read-only
        }

        // Find and set the value of the "ZipCode" input field
        const zipCodeInput = document.querySelector("#ZipCode");
        if (zipCodeInput) {
            zipCodeInput.value = county;
            zipCodeInput.readOnly = true; // Optional: Make it read-only
        }

        // Find and set the value of the "City" input field
        const cityAddressInput = document.querySelector("#City");
        if (cityAddressInput) {
            cityAddressInput.value = city ? city : 'n/a'; // Set 'n/a' if city is empty
            cityAddressInput.readOnly = true; // Optional: Make it read-only
        }
    }
}

// Ensure the function is called after the DOM is fully loaded
customFieldsLANDExceptHostnameHepler();
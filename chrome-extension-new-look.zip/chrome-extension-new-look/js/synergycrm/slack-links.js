// "use strict";

// function campaign(subdomainFunction) {
//   const getSubDomain = subdomainFunction===undefined ?
//     subDomainFromWindowLocation : subdomainFunction;

//   let subdomainFromHost = checkSubdomain(getSubDomain());
//   return isGeneric(subdomainFromHost) ?
//     subdomainFromHost : nonGenericCampaignNames(subdomainFromHost);
// }

// function slackRoom(subdomainFunction) {
//   const getSubDomain = subdomainFunction===undefined ?
//     subDomainFromWindowLocation : subdomainFunction;

//   let subdomainFromHost = checkSubdomain(getSubDomain());
//   return isGeneric(subdomainFromHost) ?
//     subdomainFromHost+"-closer-needed" : nonGenericSlackRoom(subdomainFromHost);
// }

// function checkSubdomain(subdomainFromHost) {
//   if (subdomainFromHost===null) throw new Error("subdomain was null");
//   else if (subdomainFromHost===undefined) throw new Error("subdomain was undefined");
//   else if (typeof subdomainFromHost!=="string") throw new Error("subdomain was not string");
//   else if (subdomainFromHost==="") throw new Error("subdomain was empty");
//   else return subdomainFromHost;
// }

// function isGeneric(subdomain) {
//   return nonGenericSlackRoom(subdomain) === undefined;
// }

// function slackChatRoomUrl(subdomainFunction) {
//   let baseUrl = "https://lamassumedia.slack.com/channels/";
//   return baseUrl + slackRoom(subdomainFunction);
// }

// function closerClicked() {
//   let slackLink = document.getElementById("slackLink");
//   slackLink.addEventListener("click", () => {
//     let element = document.getElementById("slackSellersLink");
//     if (element === null) {
//       appendInfoHtml();
//     }
//     copyClipboard("slackSellersLink", sellersInfo, true);
//   });
// }

// function appendInfoHtml() {
//   let targetCRM = document.querySelector(
//     "body > form > table:nth-child(7) > tbody > tr:nth-child(10)");
//   let appendHtml = [
//     '<tr align="center">',
//       '<td colspan="2" id="slackSellersLink">',
//         '<p id="slackA" class="animate">'+ sellersInfo() +'</p>',
//       '</td>', 
//     '</tr>'].join("");
//   targetCRM.insertAdjacentHTML("afterend", appendHtml);
// }

// function sellersInfo() {
//   let firstName = document.getElementById("fname").value;
//   let lastName = document.getElementById("lname").value;
//   let phone = document.getElementById("HomePhone").value;
//   let spanish = document.getElementById("spanish").selectedIndex;
//   return firstName+" "+
//     lastName+", "+
//     phone+", "+
//     (spanish===1 ? "Spanish Speaker, " : "")+
//     "WF Sent!";
// }

// function copyClipboard(elementId, copy, animation) {
//   function copyAlert(element) {
//     let oldText = element.innerText;
//     element.innerText = "Copied!";
//     element.classList.add("animate");
//     element.addEventListener('animationend', () => {
//       element.classList.remove("animate");
//       element.innerText = oldText;
//     });
//   }

//   let slackLink = document.getElementById(elementId);
//   slackLink.addEventListener("click", () => {
//     if (animation) {
//       copyAlert(slackLink);
//     }
//     let textToCopy = copy();
//     navigator
//       .clipboard
//       .writeText(textToCopy)
//       .then(() => window.open(slackChatRoomUrl(), "_blank"));
//   });
// }

// function closerNeeded() {
//   let spanish = document.getElementById("spanish").selectedIndex;
//   return [
//     "@here Closer needed",
//     spanish===1 ? "\nSpanish Speaker" : ""
//   ].join("");
// }

// function appendCloserHtml() {
//   let targetCRM = document.querySelector(
//     "body > form > table:nth-child(7) > tbody > tr:nth-child(9)");
//   let appendHtml = [
//     '<tr align="center">',
//       '<td colspan="2" id="slackLink">',
//         '<p id="slackA" class="animate">CLOSER NEEDED: ',
//         campaign().toUpperCase()+'</p>',
//       '</td>',
//     '</tr>'].join("");
//   targetCRM.insertAdjacentHTML("afterend", appendHtml);
// }

// let nonGenericCampaignNames = (subdomain) => "";
// let nonGenericSlackRoom = (subdomain) => "";
// Function to check if the current hostname should exclude certain button titles. This is done for affiliates focused on LANDS only.
const excludedTitles = ["HOME DETAILS", "REALTOR", "COMMERCIAL PROPERTY", "NOT INTERESTED?", "NOT LIVABLE", "DISCOVERY QUESTIONS CONDITIONS", "MATRIX",
"KITCHEN", "BATHROOM", "PAINTING", "ROOF ", "FLOORING", "ELECTRICITY", "PLUMBING"];


function shouldExcludeTitle(hostname, title) {
  return (
    (hostname.startsWith("baileyreal.") || hostname.includes("vacantland.")) &&
    excludedTitles.includes(title)
  );
}

// Function to replace the text snippet for "LAND DETAILS"
function replaceLandDetailsSnippet(hostname, value) {
    if (hostname.startsWith("baileyreal.") || hostname.includes("vacantland.")) {
      if (value.button_title === "LAND DETAILS") {
        value.text_snippet = `WOODED LAND:
  
  PENDING MORTGAGE OR TAXES:
  
  NAMES ON DEEDS:
  
  ROAD OR LEGAL ACCESS:
  
  Has the Land ever been Developed:
  
  Has there EVER been a Dwelling on the Property:
  
  Access to Water:
  
  Access to Electricity:
  
  Property have a Septic Tank:
  
  Liens or Loans on the Property:
  
  Water Rights:
  
  Mineral Rights:`;
      }
    }
  }
  
///////////Custom Mini Templates for VacantLand
function vacantLandMustFill_1() {
    // Function to insert button
    const insertButton = () => {
        const noteTextarea = document.querySelector('textarea[id="note"]');
        if (noteTextarea) {
            const button = document.createElement('button');
            button.id = 'vacant_land_must_fill';
            button.className = 'mustFillVacantland1 miniTemplatesBtn';
            button.innerText = 'MUST ASK THIS INFO';
            button.style.transition = 'background-color 1s ease';

            let must_fill_clicked = false;

            const changeColor = () => {
                button.style.backgroundColor = button.style.backgroundColor === 'red' ? 'inherit' : 'red';
            };

            let intervalId = setInterval(changeColor, 1000);

            button.addEventListener('click', function(e) {
                e.preventDefault();
                must_fill_clicked = true;
                clearInterval(intervalId);
                button.style.backgroundColor = 'inherit';

                const textSnippet = `
Property County:
Property Acreage:
Property Address/ APN:
What do they want for the property?:`;

                if (noteTextarea.value) {
                    noteTextarea.value += '\n' + textSnippet;
                } else {
                    noteTextarea.value = textSnippet;
                }
                noteTextarea.style.height = noteTextarea.scrollHeight + 'px';
            });

            // Insert button in the previous `td` to the one that contains the textarea
            const parentTd = noteTextarea.closest('td');
            if (parentTd) {
                parentTd.appendChild(button);
            }
        }
    };

    // Use MutationObserver to observe when the `.note` td is added
    const observer = new MutationObserver((mutationsList, observer) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                const noteTextarea = document.querySelector('textarea[id="note"]');
                if (noteTextarea && !document.getElementById('vacant_land_must_fill')) {
                    insertButton();
                    break; // Button added, no need to keep observing for this mutation
                }
            }
        }
    });

    const config = { childList: true, subtree: true };
    observer.observe(document.body, config);
}


//Add buttons
const miniTemplatesJson = "https://webtools.lamassucrm.com:3000/rs/webform_templates/list";

fetch(miniTemplatesJson)
.then(response => response.json())
.then(data => {
    let values = data;
    if (values) {
      document.querySelectorAll('textarea[id="reason"], textarea[id="note"], textarea[id="conditions"], textarea[id="repairs"], textarea[id="closing_time"], textarea[id="tenant_details"], textarea[id="occupied"], input[type="text"][id="EmailAddress"]').forEach(textarea => {
        const td = document.createElement('td');
        td.className = textarea.id;
        td.rows = 2;
        td.colSpan = 2;
        td.style.verticalAlign = 'top';
        textarea.closest('tr').appendChild(td);
    
        values.forEach(value => {
                       // Check if we should exclude the title for the current hostname
                       if (shouldExcludeTitle(window.location.hostname, value.button_title)) {
                        return; // Skip the creation of the button or dropdown
                      }

                       // Replace the text snippet for "LAND DETAILS" if necessary
            replaceLandDetailsSnippet(window.location.hostname, value);

            if (value.text_area === textarea.id) {
                const button = document.createElement('button');
                button.className = value.button_title.toLowerCase().replace(/ /g, '-');
                button.className += ' miniTemplatesBtn';
                button.innerText = value.button_title;
                if (value.text_snippet && value.text_snippet.split('\n').length > 1 && value.text_snippet.split('\n')[0].charAt(0) === '*') {
                    let dropdown = document.createElement('div');
                    dropdown.classList.add('dropdown');
                    let dropbtn = document.createElement('button');
                    dropbtn.addEventListener('click', (e) => {
                        e.preventDefault();
                    });
                    dropbtn.classList.add('dropbtn');
                    dropbtn.innerText = value.button_title;
                    dropdown.appendChild(dropbtn);
                    let dropdownContent = document.createElement('div');
                    dropdownContent.classList.add('dropdown-content');
                    value.text_snippet.split('\n').forEach(snippet => {
                        let snippetButton = document.createElement('button');
                        snippetButton.classList.add('miniTemplatesDropDwnbtn');
                        snippetButton.innerText = snippet.slice(1);
                        snippetButton.addEventListener('click', (e) => {
                            e.preventDefault();
                            if (textarea.value.includes(value.button_title + ': ' + snippet.slice(1))) {
                                textarea.value = textarea.value.replace(`\n${value.button_title}: ${snippet.slice(1)}`, "");
                                if (textarea.value.charAt(0) == '\n') {
                                    textarea.value = textarea.value.substr(1);
                                }
                            } else {
                                if (textarea.value) {
                                    textarea.value += '\n' + snippet.slice(1);
                                } else {
                                    textarea.value =  snippet.slice(1);
                                }
                            }
                            textarea.style.height = textarea.scrollHeight + 'px';
                        });
                        dropdownContent.appendChild(snippetButton);
                    });
                    dropdown.appendChild(dropdownContent);
                    td.appendChild(dropdown);
                } else {
                    button.addEventListener('click', (e) => {
                        e.preventDefault();
                        if (textarea.value.includes(value.text_snippet)) {
                            textarea.value = textarea.value.replace(value.text_snippet, "");
                        } else {
                            if (textarea.value) {
                                textarea.value += '\n' + value.text_snippet;
                            } else {
                                textarea.value = value.text_snippet;
                            }
                        }
                        textarea.style.height = textarea.scrollHeight + 'px';
                    });
                    td.appendChild(button);
                }
            }

            if (textarea.tagName.toLowerCase() === 'textarea') {
                textarea.style.height = textarea.scrollHeight + 'px';
            }
        });
        if (td.className == 'tenant_details') {
            td.style.verticalAlign = 'middle';
        } else {
            td.style.verticalAlign = 'top';
        }
        textarea.closest('tr').appendChild(td);
    });
    }
    if (window.location.hostname.startsWith("vacantland.")) {
    vacantLandMustFill_1();
    }
});

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Code to set style.width and change the colspans 

document.querySelectorAll('textarea[id="reason"], textarea[id="note"], textarea[id="conditions"], textarea[id="repairs"], textarea[id="closing_time"], textarea[id="tenant_details"], textarea[id="occupied"]').forEach(textarea => {
  textarea.closest('tr').classList.add(textarea.id);
  const colSpan = textarea.closest('td').getAttribute('colspan');
  if ( (colSpan === '3') || (colSpan === '2')) textarea.closest('td').setAttribute('colspan', '1');
  if (textarea.closest('tr').classList.contains('reason') || textarea.closest('tr').classList.contains('closing_time')) {
      textarea.closest('td').style.width = '33%';
  }
  textarea.setAttribute('cols', '39');
});


document.getElementById("tenant_details").cols = 25;
document.getElementById("tenant_details").rows = 15;


//Add an empty row after tbodys to create blank space.
// document.querySelectorAll('tbody').forEach((tbody, index) => {
//   if (tbody !== document.querySelector("#Table_2 > tbody") && index !== 0 && index !== document.querySelectorAll('tbody').length - 1) {
//       let row = tbody.insertRow();
//       row.style.height = "50px";
//       let cell = row.insertCell();
//       row.align = "left";
//       cell.colSpan = "4";
//       cell.innerHTML = "&nbsp;";
//   }
// });
// setTimeout(() => {
//   document.querySelector("#Table_2 > tbody > tr:nth-child(1)").style.display = 'none';
// }, 300);

//fix the colspan of some TDs
// let tdTitleSelector = document.querySelectorAll('td[bgcolor="#EAEAEA"]');
// for (let i = 0; i < tdTitleSelector .length; i++) {
//   tdTitleSelector [i].setAttribute('colspan', '4');
// }



//////////////////////////


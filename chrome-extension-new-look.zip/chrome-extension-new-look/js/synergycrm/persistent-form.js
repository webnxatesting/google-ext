/*Persistent Form*/
"use strict";

function queryTextAreas() {
  return document.getElementsByTagName("textarea");
}

function queryInputs() {
  return document.querySelectorAll("input[type='text']");
}

function querySelects() {
  return document.getElementsByTagName("select");
}

function keyCandidate(element) {
  return element.id !== null && element.id.length > 0 ? 
    element.id : 
      element.name !== null && element.name.length > 0 ? 
        element.name : "unknown";
}

function readValues(elements) {
  let keyValues = {};
  elements.forEach(element => {
    let key = keyCandidate(element);
    if (element.tagName === "INPUT") {
      keyValues[key] = element.value;
    }

    if (element.tagName === "TEXTAREA") {
      keyValues[key] = element.value;
    }

    if (element.tagName === "SELECT") {
      keyValues[key] = element.selectedIndex;
    }
  });
  return keyValues;
}

function formDataFromStorage(data) {
  let elements = [... queryInputs(), ... queryTextAreas(), ... querySelects()];
  elements.forEach(element => {
    let key = keyCandidate(element);
    if (element.tagName === "INPUT") {
      element.value = data[key];
    }

    if (element.tagName === "TEXTAREA") {
      element.value = data[key];
    }

    if (element.tagName === "SELECT") {
      element.selectedIndex = data[key];
    }
  });
}

function deleteFormDataInStorage(url) {
  chrome.storage.local.remove(url, function() {});
}

function restore(fromStorage, clearStorage, fromUrl) {
  let url = window.location["href"];
  chrome.storage.local.get(url, function(data) {
    let isEmpty = data
      && Object.keys(data).length === 0
      && Object.getPrototypeOf(data) === Object.prototype;

    if (!isEmpty) {
      fromStorage(data[url]);
      clearStorage(url);
    } else {
      fromUrl(url);
    }
  });
}

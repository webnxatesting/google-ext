var Streetsuffix = {
  alley: { common: ["allee", "aly", "alley", "ally", "aly"] },
  avenue: { common: ["aven", "avenu", "avenue", "avn", "avnue"] },
  bayou: { common: ["bayoo", "byu", "bayou"] },
  beach: { common: ["bch", "beach", "bch"] },
  bend: { common: ["bend", "bnd", "bnd"] },
  bluff: {
    common: ["blf", "bluff", "bluf", "bluff", "bluffs", "bluffs", "blfs"],
  },
  bottom: { common: ["bot", "btm", "btm", "bottm", "bottom"] },
  boulevard: { common: ["blvd", "blvd", "boul", "boulevard", "boulv"] },
  branch: { common: ["br", "br", "brnch", "branch", "br"] },
  brook: { common: ["brk", "brk", "brook", "brooks", "brooks", "brks"] },
  burg: { common: ["burg", "bg", "burgs", "burgs", "bgs"] },
  bypass: { common: ["byp", "byp", "bypa", "bypas", "bypass", "byps"] },
  camp: { common: ["camp", "cp", "cp", "cmp"] },
  canyon: { common: ["canyn", "cyn", "canyon", "cnyn"] },
  cape: { common: ["cape", "cpe", "cpe"] },
  causeway: { common: ["causeway", "cswy", "causwa", "cswy"] },
  center: {
    common: [
      "cen",
      "ctr",
      "cent",
      "center",
      "centr",
      "centre",
      "cnter",
      "cntr",
      "ctr",
    ],
  },
  circle: {
    common: [
      "cir",
      "cir",
      "circ",
      "circl",
      "circle",
      "crcl",
      "crcle",
      "circles",
      "circles",
      "cirs",
    ],
  },
  cliff: { common: ["clf", "clf", "cliff", "cliffs", "cliffs", "clfs"] },
  club: { common: ["clb", "clb", "club"] },
  common: { common: ["common", "cmn", "commons", "commons", "cmns"] },
  corner: {
    common: ["cor", "cor", "corner", "corners", "corners", "cors", "cors"],
  },
  course: { common: ["course", "crse", "crse"] },
  court: {
    common: ["court", "court", "ct", "ct", "courts", "courts", "cts", "cts"],
  },
  cove: { common: ["cove", "cv", "cv", "coves", "coves", "cvs"] },
  creek: { common: ["creek", "crk", "crk"] },
  crescent: {
    common: ["crescent", "cres", "cres", "crsent", "crsnt", "crest"],
  },
  crossing: { common: ["crossing", "xing", "crssng", "xing"] },
  crossroad: {
    common: ["crossroad", "xrd", "crossroads", "crossroads", "xrds"],
  },
  curve: { common: ["curve", "curve", "curv"] },
  dale: { common: ["dale", "dale", "dl", "dl"] },
  dam: { common: ["dam", "dam", "dm", "dm"] },
  divide: { common: ["div", "dv", "divide", "dv", "dvd"] },
  drive: { common: ["dr", "dr", "driv", "drive", "drv"] },
  estate: {
    common: ["est", "est", "estate", "estates", "estates", "ests", "ests"],
  },
  expressway: {
    common: ["exp", "expy", "expr", "express", "expressway", "expw", "expy"],
  },
  extension: {
    common: [
      "ext",
      "ext",
      "extension",
      "extn",
      "extnsn",
      "extensions",
      "exts",
      "exts",
    ],
  },
  fall: { common: ["fall", "fall", "fall", "falls", "falls", "fls", "fls"] },
  ferry: { common: ["ferry", "fry", "frry", "ferry", "fry"] },
  field: {
    common: ["field", "fld", "fld", "fields", "fields", "flds", "flds"],
  },
  flat: { common: ["flat", "flt", "flt", "flats", "flats", "flts", "flts"] },
  ford: { common: ["ford", "frd", "frd", "fords", "fords", "frds"] },
  forest: { common: ["forest", "frst", "forest", "frst"] },
  forge: {
    common: ["forge", "frg", "forge", "frg", "forges", "forges", "frgs"],
  },
  fork: { common: ["fork", "frk", "frk", "forks", "forks", "frks", "frks"] },
  fort: { common: ["fort", "ft", "frt", "fort", "ft"] },
  freeway: { common: ["freeway", "fwy", "freewy", "frway", "frwy", "fwy"] },
  garden: {
    common: [
      "garden",
      "gdn",
      "gardn",
      "grden",
      "grdn",
      "gardens",
      "gardens",
      "gdns",
      "gdns",
      "grdns",
    ],
  },
  gateway: { common: ["gateway", "gtwy", "gatewy", "gatway", "gtway", "gtwy"] },
  glen: { common: ["glen", "gln", "gln", "glens", "glens", "glns"] },
  green: { common: ["green", "grn", "grn", "greens", "greens", "grns"] },
  grove: {
    common: ["grove", "grv", "grove", "grv", "groves", "groves", "grvs"],
  },
  harbor: {
    common: [
      "harbor",
      "harb",
      "harbor",
      "harbr",
      "hbr",
      "harbors",
      "harbors",
      "harbs",
    ],
  },
  haven: { common: ["haven", "havn", "haven", "havn"] },
  heights: { common: ["height", "hgts", "height", "hgts", "hts", "hts"] },
  highway: { common: ["highway", "hway", "highwy", "hiway", "hiwy", "hway"] },
  hill: { common: ["hill", "hl", "hl", "hills", "hills", "hls"] },
  hollow: {
    common: [
      "hollows",
      "hollows",
      "holws",
      "hollow",
      "hollo",
      "hollow",
      "hollows",
      "holw",
    ],
  },
  inlet: { common: ["inlet", "inlt", "inlt"] },
  island: {
    common: ["island", "islnd", "island", "islands", "islands", "islnds"],
  },
  isle: { common: ["isle", "isle", "isle"] },
  junction: {
    common: [
      "junction",
      "jctn",
      "junction",
      "junctn",
      "juncton",
      "junctions",
      "jctns",
    ],
  },
  key: { common: ["key", "ky", "key", "keys", "keys", "kys"] },
  knoll: { common: ["knolls", "knolls", "knls", "knoll", "knol"] },
  lake: { common: ["lake", "lk", "lake", "lakes", "lks"] },
  land: { common: ["land", "land", "land"] },
  landing: { common: ["landing", "lndg", "landing", "lndg", "lndng"] },
  lane: { common: ["lane", "ln", "lane", "ln"] },
  light: { common: ["light", "lght", "light", "lght", "lgts"] },
  loaf: { common: ["loaf", "loaf"] },
  lock: { common: ["locks", "locks", "lcks", "lock", "lck"] },
  lodge: { common: ["lodge", "ldg", "lodge", "ldg"] },
  loop: { common: ["loop", "loop", "loop"] },
  mall: { common: ["mall", "mall", "mall"] },
  manor: { common: ["manor", "mnr", "manor", "manors", "manors", "mnrs"] },
  meadow: { common: ["meadow", "mdw", "meadows", "mdw", "meadows", "mdws"] },
  mews: { common: ["mews", "mews", "mews"] },
  mill: { common: ["mill", "ml", "mills", "mills", "mls"] },
  mission: { common: ["mission", "missn", "mission", "msn", "mssn"] },
  motorway: { common: ["motorway", "motorway", "mtwy"] },
  mount: {
    common: [
      "mount",
      "mnt",
      "mt",
      "mount",
      "mountain",
      "mntn",
      "mount",
      "mntn",
    ],
  },
  neck: { common: ["neck", "nck", "neck", "nck"] },
  orchard: { common: ["orchard", "orch", "orchard", "orchrd"] },
  oval: { common: ["oval", "oval", "oval"] },
  overpass: { common: ["overpass", "overpass", "opas"] },
  park: { common: ["park", "prk", "park", "parks", "parks", "prk"] },
  parkway: {
    common: ["parkway", "pkwy", "parkway", "parkwy", "pkway", "pkwy"],
  },
  pass: { common: ["pass", "pass", "pass"] },
  passage: { common: ["passage", "psge", "passage", "psge"] },
  path: { common: ["path", "path", "path"] },
  pike: { common: ["pike", "pike", "pike", "pikes"] },
  pine: { common: ["pine", "pine", "pine", "pines", "pines", "pnes"] },
  place: { common: ["place", "pl", "place", "pl"] },
  plain: { common: ["plain", "plain", "pln", "pln"] },
  plains: { common: ["plains", "plains", "plns", "plns"] },
  plaza: { common: ["plaza", "plaza", "plz", "plz", "plza"] },
  point: { common: ["point", "pt", "point", "points", "points", "pts"] },
  port: { common: ["port", "prt", "port", "ports", "ports", "prts"] },
  prairie: { common: ["prairie", "pr", "prairie", "prr"] },
  radial: { common: ["radial", "radl", "radial", "radiel", "radl"] },
  ramp: { common: ["ramp", "ramp", "ramp"] },
  ranch: { common: ["ranch", "rnch", "ranch", "ranches", "ranches", "rnchs"] },
  rapid: { common: ["rapids", "rpd", "rapids", "rpds"] },
  rest: { common: ["rest", "rst", "rest", "rst"] },
  ridge: { common: ["ridge", "rdg", "ridge", "rdg", "rdge", "ridges", "rdgs"] },
  river: { common: ["river", "riv", "river", "rvr", "rivr"] },
  road: { common: ["road", "rd", "road", "roads", "roads", "rds"] },
  route: { common: ["route", "rte", "route"] },
  row: { common: ["row", "row", "row"] },
  rue: { common: ["rue", "rue", "rue"] },
  run: { common: ["run", "run", "run"] },
  shoal: { common: ["shoal", "shl", "shoal", "shoals", "shls", "shoals"] },
  shore: {
    common: [
      "shore",
      "shr",
      "shore",
      "shr",
      "shores",
      "shoars",
      "shrs",
      "shores",
    ],
  },
  skyway: { common: ["skyway", "skwy", "skyway"] },
  spring: {
    common: [
      "spring",
      "spg",
      "spng",
      "spring",
      "sprng",
      "springs",
      "spgs",
      "spngs",
      "springs",
      "sprngs",
    ],
  },
  spur: { common: ["spur", "spur", "spur", "spurs", "spurs", "spur"] },
  square: {
    common: [
      "square",
      "sq",
      "square",
      "sqr",
      "sqre",
      "squ",
      "square",
      "squares",
      "sqrs",
      "sqs",
      "squares",
    ],
  },
  station: { common: ["station", "sta", "station", "statn", "stn"] },
  stravenue: {
    common: [
      "stravenue",
      "stra",
      "strav",
      "straven",
      "stravenue",
      "stravn",
      "strvn",
      "strvnue",
    ],
  },
  stream: { common: ["stream", "strm", "streme", "strm"] },
  street: {
    common: ["street", "st", "strt", "str", "street", "streets", "sts"],
  },
  summit: { common: ["sumit", "sumitt", "summit"] },
  terrace: { common: ["terrace", "ter", "terr", "terrace"] },
  throughway: { common: ["throughway", "trwy", "throughway"] },
  trace: { common: ["trace", "trce", "traces", "trce"] },
  track: {
    common: ["track", "trak", "track", "tracks", "trak", "trk", "trks"],
  },
  trafficway: { common: ["trafficway", "trfy", "trafficway"] },
  trail: { common: ["trail", "trl", "trails", "trl", "trls"] },
  trailer: { common: ["trailer", "trlr", "trlr", "trlrs"] },
  tunnel: {
    common: ["tunel", "tunl", "tunl", "tunls", "tunnel", "tunnels", "tunnl"],
  },
  turnpike: { common: ["trnpk", "tpke", "turnpike"] },
  underpass: { common: ["underpass", "upas", "underpass"] },
  union: { common: ["un", "union", "unions", "unions", "uns"] },
  valley: {
    common: [
      "valley",
      "vly",
      "vally",
      "vlly",
      "vly",
      "valleys",
      "vlys",
      "vlys",
    ],
  },
  viaduct: { common: ["vdct", "via", "viadct", "viaduct"] },
  view: { common: ["view", "vw", "view", "views", "vws", "vws"] },
  ville: {
    common: [
      "ville",
      "vl",
      "vl",
      "ville",
      "village",
      "villg",
      "villiage",
      "vlg",
      "villages",
      "villages",
      "vlgs",
      "vlgs",
    ],
  },
  vista: { common: ["vis", "vista", "vist", "vista", "vst", "vsta"] },
  walk: { common: ["walk", "walk", "walk", "walks", "walks", "walk"] },
  wall: { common: ["wall", "wall", "wall"] },
  way: { common: ["wy", "way", "way", "ways", "ways", "ways"] },
  well: { common: ["well", "wl", "well", "wells", "wls", "wls"] },
};
function say(word) {
  let s = new SpeechSynthesisUtterance(word);
  s.voice = window.speechSynthesis.getVoices().find((e) => "en-US" === e.lang);
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(s);
}

function textToSpeechCRM() {
  // Check if the current URL contains the desired pattern
  const currentURL = window.location.href;
  if (!window.location.href.startsWith('https://qco.lamassucrm.com/crm_agent_interface.php')) {

    addressZillow = document.querySelector("#StreetAddress").value;
    cityZillow = document.querySelector("#City").value;
    stateZillow = document.querySelector("#State").value;
    zipZillow = document.querySelector("#Zip").value;
    var urlZillow = "https://www.zillow.com/homes/";
  
    urlZillow += addressZillow + "-" + cityZillow + "-" + stateZillow + "-" + zipZillow + "_rb/";
    console.log(urlZillow)
    
    return;
  }

  // Get the target element
  const targetElement = document.querySelector(
    "body > div:nth-child(4) > table > tbody > tr:nth-child(4) > td:nth-child(1) > table > tbody > tr:nth-child(2) > td > div > span.a22black"
  );

  if (!targetElement) {
    console.warn("Target element not found.");
    return;
  }

  // Split the text content by spaces to get an array of words
  const words = targetElement.textContent.split(" ");

  // Empty the target element
  targetElement.textContent = "";

  // Iterate through the words and wrap each word in a span
  words.forEach((word, index) => {
    if (word.trim()) {
      const wordSpan = document.createElement("span");
      wordSpan.textContent = word;
      wordSpan.style.cursor = "pointer";
      wordSpan.addEventListener("click", () => {
        say(word.trim());
      });

      targetElement.appendChild(wordSpan);

      // Add a space after each word, except for the last one
      if (index !== words.length - 1) {
        targetElement.appendChild(document.createTextNode(" "));
      }
    }
  });
}

// Run the textToSpeechCRM function
textToSpeechCRM();

function textToSpeechStreetSuffix() {
  const currentURL = window.location.href;
  if (currentURL.includes("lamassucrm.com/crm_agent_interface.php")) {
    const targetElementSelector =
      "body > div:nth-child(4) > table > tbody > tr:nth-child(4) > td:nth-child(1) > table > tbody > tr:nth-child(2) > td > div > span:nth-child(5)";
    const targetElement = document.querySelector(targetElementSelector);
    targetElement.addEventListener("click", () => {
      const textContent = targetElement.textContent.trim();
      const addressParts = textContent.split(",");

      let streetAddress = addressParts[0];
      const city = addressParts[1].trim();

      // Remove the first set of numbers in the street address
      streetAddress = streetAddress.replace(/^\d+\s/, "");

      const expandedSuffix = expandStreetSuffix(streetAddress);

      // Exclude the state and zip code
      const cityParts = city.split(" ");
      const cityWithoutStateAndZip = cityParts.slice(0, -2).join(" ");

      const speechText = `${expandedSuffix} ${cityWithoutStateAndZip}`;

      say(speechText);
    });

    // Add cursor pointer on mouseover
    targetElement.style.cursor = "pointer";
  }
}

function expandStreetSuffix(text) {
  return text.replace(/\b(.+?)\b/g, (_, word) => {
    let expandedWord;
    Object.entries(Streetsuffix).some(([_, { common: suffixes }]) => {
      if (suffixes.includes(word)) {
        expandedWord = _;
        return true;
      }
    });
    return expandedWord || word;
  });
}

textToSpeechStreetSuffix();

/////////v2.9 Function to add Zillow Link for Closers LamassuCRM Pipelines
function launchZillow() {
    const address = document.querySelector("#StreetAddress").value;
    const city = document.querySelector("#City").value;
    const state = document.querySelector("#State").value;
    const zip = document.querySelector("#ZipCode").value;
    const url = `https://www.zillow.com/homes/${address}-${city}-${state}-${zip}_rb/`;
    return url;
  }
  
  window.onload = function() {
    if (window.location.href.includes("/crm_agent_interface.php")) {
      const targetNode = document.querySelector("body > div:nth-child(4) > table > tbody > tr:nth-child(4) > td:nth-child(1) > table > tbody > tr:nth-child(2) > td > div > span:nth-child(5)");
      if (targetNode) {
        const newSpan = document.createElement('span');
        const link = document.createElement('a');
        link.textContent = "  Zillow Link";
        link.href = launchZillow();
        link.target = "_blank";
        newSpan.appendChild(link);
        targetNode.appendChild(newSpan);
      } else {
        console.error("Target node not found.");
      }
    }
  }
  

setTimeout(launchZillow,5000); 



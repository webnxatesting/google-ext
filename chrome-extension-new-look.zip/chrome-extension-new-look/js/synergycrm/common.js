"use strict";

function subDomainFromWindowLocation() {
  let host = window.location.host;
  return host.split('.')[0];
}

function storeLocal (key, data, callback) {
  let callbackFunc = callback;
  if (!callback) {
    callbackFunc = function () {};
  }
  chrome.storage.local.set({[key]: data}, callbackFunc);
}

function readLocal (key, callback) {
  chrome.storage.local.get(matrixSavedKey, callback);
}
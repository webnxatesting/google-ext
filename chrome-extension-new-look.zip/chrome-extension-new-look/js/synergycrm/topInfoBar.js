// Store the original title
const originalTitle = document.title;

// Create a utility function to create and style a div
function createStyledDiv(id, styles) {
  const div = document.createElement('div');
  div.id = id;
  Object.assign(div.style, styles);
  return div;
}

// Create the topDiv with styles
const topDivStyles = {
  height: "19px",
  width: "100vw",
  backgroundColor: "#363636",
  color: "white",
  position: "fixed",
  top: "0px",
  fontSize: "13px",
  display: "flex",
  textAlign: "center",
  justifyContent: "center",
  alignItems: "center",
  zIndex: "1000",
  marginBottom: "100px"
};
const topDiv = createStyledDiv("topBarInfo", topDivStyles);
document.body.appendChild(topDiv);
document.body.style.marginTop = "110px";

// Utility function to get input value by ID
function getInputValue(id) {
  const element = document.getElementById(id);
  return element ? element.value : '';
}

// Utility function to get selected option text by ID
function getSelectedOptionText(id) {
  const select = document.getElementById(id);
  return select && select.options[select.selectedIndex] ? select.options[select.selectedIndex].text : '';
}

// Function to update the window title and topSellerInfo div
function checkAndModifyTitleAndDiv() {
  const titleSegments = ['LMSU| ', originalTitle];

  const fname = getInputValue('fname');
  const lname = getInputValue('lname');
  const StreetAddress = getInputValue('StreetAddress');
  const city = getInputValue('City');
  const state = getSelectedOptionText('State');
  const abandon_phone = getInputValue('abandon_phone');
  const agent = getSelectedOptionText('from_userid');

  // Update title
  if (fname && lname) {
    titleSegments.push(` | ${fname} ${lname}`);
  }
  if (StreetAddress && city && state) {
    titleSegments.push(` |${StreetAddress}, ${city}, ${state}`);
  }
  if (abandon_phone) {
    titleSegments.push(` | ${abandon_phone}`);
  }
  document.title = titleSegments.join('');

  // Update topSellerInfo div
  topDiv.textContent = `${fname} ${lname} - ${StreetAddress} ${city} ${state} - ${abandon_phone} | ${agent}`;
}

// Add event listener to multiple elements
function addInputListeners(ids, event, handler) {
  ids.forEach(id => {
    const element = document.getElementById(id);
    if (element) element.addEventListener(event, handler);
  });
}

// IDs of elements to add event listeners to
const inputIds = ['fname', 'lname', 'StreetAddress', 'City', 'State', 'abandon_phone', 'from_userid'];

// Initialize and set up event listeners
setTimeout(() => {
  addInputListeners(inputIds, 'input', checkAndModifyTitleAndDiv);
  document.getElementById('from_userid').addEventListener('change', checkAndModifyTitleAndDiv);

  // Initial call and set up polling
  checkAndModifyTitleAndDiv();
  setInterval(checkAndModifyTitleAndDiv, 2000);
}, 3000);



///////////////////////////////////////////////////
// New utility function to get URL query parameter
function getUrlQueryParam(param) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(param);0
}

// Function to create and insert a new div below an existing div
function createAndInsertDivBelow(existingDivId, newDivId, styles, content) {
  const existingDiv = document.getElementById(existingDivId);
  if (!existingDiv) return;

  const newDiv = createStyledDiv(newDivId, styles);
  newDiv.textContent = content;
  existingDiv.insertAdjacentElement('afterend', newDiv);
}

// Check for 'state' query parameter and create new top bar if it exists
const typeOfLeadQueryParameter = getUrlQueryParam('type_of_lead');
if (typeOfLeadQueryParameter) {
  const baseWidth = 100; // Base width for padding and other elements
  const pixelsPerCharacter = 10; // Width per character, adjust as needed
  const dynamicWidth = baseWidth + (typeOfLeadQueryParameter.length * pixelsPerCharacter);

  let backgroundColor, textColor;
  switch (typeOfLeadQueryParameter.toUpperCase()) {
    case 'LAND':
      backgroundColor = '#39FF14';
      textColor = 'black';
      break;
    case 'FACE-TO-FACE':
      backgroundColor = '#F9E900';
      textColor = 'black';
      break;
    case 'VIRTUAL':
      backgroundColor = '#FDFFFC';
      textColor = 'black';
      break;
    // Add default case if needed
    default:
      backgroundColor = 'orange'; // Default background color
      textColor = 'white'; // Default text color
  }

  const newTopBarStyles = {
    height: "21px",
    width: `${dynamicWidth}px`,
    backgroundColor: backgroundColor,
    color: textColor,
    position: "fixed",
    top: "19px",
    left: "50%",
    transform: "translateX(-50%)",
    fontSize: "14px",
    fontWeight: "bold",
    textAlign: "center",
    lineHeight: "19px",
    zIndex: "999",
    borderRadius: "0 0 5px 5px"
  };

  // Create and insert the new top bar
  createAndInsertDivBelow("topBarInfo", "newTopBar", newTopBarStyles, `Type of Lead: ${typeOfLeadQueryParameter}`);
}


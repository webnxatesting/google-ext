  //Snapshot: https://user-images.githubusercontent.com/104270019/247943502-ad0c3adf-8070-4f2e-b3f5-0bf603c071ff.png
  /////////////////////////////////////////////////////////
  
// Fetches the seller's information
function getSellersInfo() {
  const fname = document.querySelector("#fname").value;
  const lname = document.querySelector("#lname").value;
  const homePhone = document.querySelector("#HomePhone").value;
  const spanishSelect = document.querySelector("#spanish");
  const spanishOption = spanishSelect.options[spanishSelect.selectedIndex].value;

  if (spanishOption === "Yes") {
    return `Spanish Speaker // ${fname} ${lname} // ${homePhone} // WF Sent!`;
  }

  return `${fname} ${lname} // ${homePhone} // WF Sent!`;
}

// Updates the link's text content
function updateSlackLinkContent() {
  const sellersInfo = getSellersInfo();
  const slackLink = document.querySelector("#slackALink");

  if (slackLink) {
    slackLink.textContent = sellersInfo;
  }
}

// Monitors the inputs for any changes
function monitorInputs() {
  const inputs = ['#fname', '#lname', '#HomePhone'];

  inputs.forEach(id => {
    
    const element = document.querySelector(id);

    setInterval(() => {
      updateSlackLinkContent();
    }, 1000); // Check every 1 second
  });
}

// Fetches the subdomain for the Slack chat room
async function fetchSubdomain() {
  try {
    const response = await fetch('https://metrics.lamassucrm.com:3005/api/meta_db/slack_links_campaigns/bdBQaBVHq4VVzWGFemOCVD0leufHK4FD86lKW8I&nB');
    
    if (response.ok) {
      const data = await response.json();
      const currentSubdomain = window.location.host.split('.')[0];

      for (const campaign of data) {
        if (campaign.campaign_subdomain === currentSubdomain) {
          return campaign.campaign_slackroom;
        }
      }
    }
  } catch (error) {
    console.log('Failed to fetch subdomain:', error);
  }

  const currentSubdomain = window.location.host.split('.')[0];
  return `${currentSubdomain}-closer-needed`;
}



// Builds the URL for the Slack chat room
async function buildSlackChatRoomUrl() {
  const baseUrl = "https://lamassumedia.slack.com/channels/";
  const subdomain = await fetchSubdomain();

  return `${baseUrl}${subdomain}`;
}

// Sets the URL for the slack chat room
async function setSlackChatRoomUrl() {
  const url = await buildSlackChatRoomUrl();
  const slackLink = document.querySelector("#slackALink");

  if (slackLink) {
    slackLink.href = url;
    slackLink.target = "_blank";
  }
}

// Sets up the slack link in the DOM
function setupSlackLink() {
  const targetCRM = document.querySelector("#Table_6 > tbody > tr:nth-child(12)");
  const slackLinkHTML = `
    <tr align="center">
      <td colspan="2" id="slackSellersLink" style="color: blue">
        <p id="slackLinksLabel">CLICK TO OPEN AFFILIATE'S SLACK ROOM (SELLER'S INFO WILL BE COPIED TO THE CLIPBOARD)</p>
        <p id="slackA" class="animate"><div id="slackALink">${getSellersInfo()}</div></p>
      </td>
    </tr>
  `;

  targetCRM.insertAdjacentHTML("beforebegin", slackLinkHTML);
  setSlackChatRoomUrl();
}

function copyClipboard(elementId, copy, animation) {
  function copyAlert(element) {
    let oldText = element.innerText;
    element.innerText = "Copied!";
    element.classList.add("animate");
    element.addEventListener('animationend', () => {
      element.classList.remove("animate");
      element.innerText = oldText;
    });
  }

  let slackLink = document.getElementById(elementId);
  slackLink.addEventListener("click", () => {
    let textElement = slackLink.querySelector("#slackALink"); //Get the child text element
    let textToCopy = textElement.textContent; // save the current text content to a variable
    if (animation) {
      copyAlert(textElement); //Animate the child text element
    }
    textToCopy = copy(textToCopy); // use the saved text content in your copy() function
    navigator
      .clipboard
      .writeText(textToCopy)
      .then(async () => window.open(await buildSlackChatRoomUrl(), "_blank"));
  });

  //Add event listener to #slackALink
  let slackALink = document.querySelector("#slackALink");
  if(slackALink) {
    slackALink.addEventListener("click", (event) => {
      event.stopPropagation(); // Stop event bubbling to #slackSellersLink
      let textToCopy = copy(slackALink.textContent);
      navigator
        .clipboard
        .writeText(textToCopy)
        .then(async () => window.open(await buildSlackChatRoomUrl(), "_blank"));
    });
  }
}






// Initiates the functions
function initSlackLinks() {
  setupSlackLink();
  monitorInputs();
  copyClipboard("slackSellersLink", (textToCopy) => textToCopy, true);
}



"use strict";



convertTelLinksToCallto();
emailValidation();
copyPhoneToNotesStride();

//START OF FUNCTION to add attributes to the table for CSS purposes.
function changeSynergyHtml() {
  //remove original widths
  document.querySelector("body > table").removeAttribute("width")
  //document.querySelector("body > form > table:nth-child(3)").removeAttribute("width")
  document.querySelector("body > form > table:nth-child(4)").removeAttribute("width")
  document.querySelector("body > form > table:nth-child(5)").removeAttribute("width")
  document.querySelector("body > form > table:nth-child(6)").removeAttribute("width")
  document.querySelector("body > form > table:nth-child(7)").removeAttribute("width")
  //insert id to elements
  document.querySelector("body > table").setAttribute("id", "Table_1")
  document.querySelector("body > form > table:nth-child(4)").setAttribute("id", "Table_2")
  document.querySelector("body > form > table:nth-child(5)").setAttribute("id", "Table_3")
  document.querySelector("body > form > table:nth-child(6)").setAttribute("id", "Table_4")
  document.querySelector("body > form > table:nth-child(7)").setAttribute("id", "Table_5")
  document.querySelector("body > form > table:nth-child(8)").setAttribute("id", "Table_5_1")
  document.querySelector("body > form > table:nth-child(9)").setAttribute("id", "Table_6")
 
}
//END OF FUNCTION to add attributes to the table for CSS purposes.


//NEW v2.5.2: spacekey event to trigger the calculation after windows is loaded
function keyupTimer(){
    setTimeout(() => {
      if(document.getElementById("zestimateInput").value != "") {
        document.getElementById("zestimateInput").dispatchEvent(new KeyboardEvent('keyup', { 'keyCode': 32 }));
      }
      if(document.getElementById("askingPriceInput").value != "") {
        document.getElementById("askingPriceInput").dispatchEvent(new KeyboardEvent('keyup', { 'keyCode': 32 }));
      }
  }, 500);
}
//END OF FUNCTION

window.addEventListener('beforeunload', event => {
  let url = window.location["href"];
  let formData = readValues(
    [... queryInputs(), ... queryTextAreas(), ... querySelects()]);
  chrome.storage.local.set({[url]: formData}, function() {});
});

// const url = "https://jsonlmsu1.herokuapp.com/api?id=1zRCKcxhjme7W-eTvPtiAjB6-5SWKrW4p-fBM0_CtRuo&columns=false&&sheet=NonGenericCampaigns#";
// fetch(url)
//   .then(response => response.json())
//   .then(data => {
//     nonGenericCampaignNames = (subdomain) => {
//       let queried = data.rows.find(d => d.CNAME===subdomain);
//       return !queried ? undefined : queried.CampaignName;
//     };
//     nonGenericSlackRoom = (subdomain) => {
//       let queried = data.rows.find(d => d.CNAME===subdomain);
//       return !queried ? undefined : queried.SlackRoom;
//     };
//     appendCloserHtml();
//     closerClicked();
//     copyClipboard("slackLink", closerNeeded);
//   });
changeSynergyHtml();
insertMatrix();
insertOtherCosts();

function insertMatrix() {
  const matrixPosition = document.querySelector("#Table_5_1 > tbody");
  const tr = document.createElement("tr");
  tr.id="matrixTR";
  const td = document.createElement("td");
  td.setAttribute("colspan", "4");
  tr.appendChild(td);
  matrixPosition.insertAdjacentElement("beforeend",tr);

  registerHtmlTemplate(matrixHtml(), td);
  restore(formDataFromStorage, deleteFormDataInStorage, formDataFromUrl);
}

function insertOtherCosts() {
  const matrixPosition = document.querySelector("#Table_5_1 > tbody");
  const tr = document.createElement("tr");
  tr.id="otherCostsTR";
  const td = document.createElement("td");
  td.setAttribute("colspan", "6");
  tr.appendChild(td);
  matrixPosition.insertAdjacentElement("afterend",tr);
  registerHtmlTemplate(otherCosts(), td);
}


////////////////////////

document.getElementById('zestimateInput').addEventListener('paste', function(e) {
  e.preventDefault();
  const clipboardData = e.clipboardData || window.clipboardData;
  const pastedText = clipboardData.getData('text/plain');
  const strippedText = pastedText.replace(/[^0-9]/g, '');
  this.value = strippedText;
});

/////////////////////////

keyupTimer();

getZillowFromTabs();
toolTips();
limitInputOnIntegrity();
selectPoolOptions(); //Replace the input for Yes/No buttons


setTimeout(() => {
  assetsforacres();
}, 500); //customAffiliates.js


capitalizedTimeStamp(); //customAffiliates.js

setTimeout(() => {
  highlightActiveTR();
}, 2500); //synergycrm.js

hideLiveTransferBtnIPS(); //customAffiliates.js

setTimeout(initSlackLinks,1000); //slack-links-new.js

setTimeout(updateTenantsQuestions,500); //synergycrm.js

setTimeout(attachMortageCalculatorLink,1500); //synergycrm.js

setTimeout(customTrustedHideTables,1500); //customAffiliates.js
setTimeout(hideMatrixInUnified,500); //customAffiliates.js
setTimeout(unifiedZestimate,500); //customAffiliates.js
setTimeout(takeOverNotes,1500); //customAffiliates.js
setTimeout(cloneNotesOnTop,1500); //customAffiliates.js
customBaileyreal(); //customAffiliates.js
customLANDBackground(); //customAffiliates.js


hideCalculatorOnVacantland();
hideCalculatorOnHepler()


setTimeout(addMarketingLeadSourceToTables, 2000);
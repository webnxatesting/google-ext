"use strict";

//////////////////
function replaceHedgeFundMatrixText() {
  // Find all <td> elements in the document
  var tdElements = document.querySelectorAll('td');

  // Iterate over each <td> to find the one that contains the specific text
  tdElements.forEach(function(td) {
    if (td.textContent.trim() === 'HEDGE FUND MATRIX:') {
      // Replace the text content with the new text
      td.textContent = 'APPROVAL MATRIX:';
    }
  });
}

// Call the function to perform the replacement
replaceHedgeFundMatrixText();

////////////////////

/////////////////////////////////
function encloseRepairsNeededIntoOwnTableWithTitle() {
  // Select the specific <tr> containing "REPAIRS NEEDED"
  var repairsNeededTr = document.querySelector("body > form > table:nth-child(5) tr[style='display:;']").nextElementSibling;

  // Check if the <tr> is found to ensure it exists before proceeding
  if (!repairsNeededTr) {
    console.log("Repairs Needed <tr> not found.");
    return;
  }

  // Create a new <table> and <tbody> elements
  var newTable = document.createElement("table");
  var newTbody = document.createElement("tbody");

  // Optional: Apply any styles or attributes to the new table as needed
  newTable.setAttribute("width", "900px");
  newTable.setAttribute("bgcolor", "#F7F7F7");
  newTable.setAttribute("border", "0");
  newTable.setAttribute("cellpadding", "5");
  newTable.setAttribute("cellspacing", "3");
  newTable.setAttribute("align", "center");

  // Create and insert the title <tr> into the new <tbody>
  var titleTr = document.createElement("tr");
  titleTr.setAttribute("align", "left");
  var titleTd = document.createElement("td");
  titleTd.setAttribute("bgcolor", "#EAEAEA");
  titleTd.setAttribute("colspan", "4");
  var titleSpan = document.createElement("span");
  titleSpan.setAttribute("style", "font-size:16px;font-weight:bold;");
  titleSpan.textContent = "Repairs";

  // Assemble the title elements
  titleTd.appendChild(titleSpan);
  titleTr.appendChild(titleTd);

  // Append the title <tr> to the <tbody>
  newTbody.appendChild(titleTr);

  // Move the selected <tr> into the new <tbody>
  newTbody.appendChild(repairsNeededTr);

  // Append the <tbody> to the new <table>
  newTable.appendChild(newTbody);

  // Place the new <table> right after the original table in the DOM
  var originalTable = document.querySelector("body > form > table:nth-child(5)");
  if (originalTable) {
    originalTable.parentNode.insertBefore(newTable, originalTable.nextSibling);
  } else {
    console.log("Original table not found.");
  }
}

// Call the function to perform the operation
encloseRepairsNeededIntoOwnTableWithTitle();

/////////////////////////////////



///////////////
function moveCallDateTimeRow() {
  var callBackDateTimeTr = document.querySelector('#call_back_date_time')?.closest('tr');

  if (callBackDateTimeTr) {
    var leadDataTr = document.querySelector("body > form > table:nth-child(9) > tbody > tr:nth-child(1)");

    if (leadDataTr) {
      leadDataTr.insertAdjacentElement('afterend', callBackDateTimeTr);
    } else {
      console.error('The target element for moving the row was not found.');
    }
  } else {
    console.error('The element to move does not exist.');
  }
}
moveCallDateTimeRow();

///////////////



//const { ConsoleReporter } = require("jasmine");

function formDataFromUrl(url) {
  const acceptable = {
    "first_name": "fname",
    "last_name": "lname",
    "number1_0": "HomePhone",
    "abandon_phone_0": "abandon_phone",
    "sd_marketing_source": "mleadsource",
    "lead_source": "utm_source",
    "agent_name": "from_userid"
  };
  const updatable = ["number1"];
  let url_params = new URLSearchParams(url);
  let config_params = {
    "lead_source": ""
  };
  let verified = {};

  for (const [parameter, value] of url_params.entries()) {
    if (parameter in acceptable) {
      if (updatable.includes(parameter)) {
        let formatted = value.slice(0, 3) + "-" + value.slice(3, 6) + "-" + value.slice(6);
        verified[parameter] = formatted;
        document.getElementById("abandon_phone_0").value = verified[parameter];
      } else {
        verified[parameter] = value;
      }
    }
  }

  Object.assign(verified, verified, config_params);

  for (const parameter of Object.keys(verified)) {
    document.getElementById(acceptable[parameter]).value = verified[parameter];
  }
}


//insert Address new TR
var fullURL = window.location.href;
var fullURLAddress = "";
var currentURL = new URL(fullURL);
var address = currentURL.searchParams.get("address");
var city = currentURL.searchParams.get("city");
var state = currentURL.searchParams.get("state");
var zip = currentURL.searchParams.get("zip");
if (state === "CT" && zip.length === 4) {
  zip = "0" + zip;
}
var email = currentURL.searchParams.get("email");
fullURLAddress = address + ", " + city + ", " + state + " " + zip;







//Address Buttons
let buttonFillAddress = document.createElement("button");
let buttonClearAddress = document.createElement("button");

buttonFillAddress.innerHTML = "Fill Address";
buttonClearAddress.innerHTML = "Clear Address";
buttonFillAddress.className = "addressButton";
buttonClearAddress.className = "addressButton";

buttonFillAddress.onclick = function (e) {
  e.preventDefault();
  document.getElementById("StreetAddress").value = address;
  document.getElementById("City").value = city;
  document.getElementById("State").value = state;
  // Skip setting ZipCode if hostname starts with "baileyreal."
  if (!window.location.hostname.startsWith("baileyreal.")) {
    document.getElementById("ZipCode").value = zip;
  }
}

buttonClearAddress.onclick = function (e) {
  e.preventDefault();
  document.getElementById("StreetAddress").value = "";
  document.getElementById("City").value = "";
  document.getElementById("State").value = "";
  // Skip clearing ZipCode if hostname starts with "baileyreal."
  if (!window.location.hostname.startsWith("baileyreal.")) {
    document.getElementById("ZipCode").value = "";
  }
}

let addressTR = document.querySelector("body > form > table:nth-child(4) > tbody > tr:nth-child(7)");
var blankAddressTR = ['<tr align="left" id="blankAddressTR"><td colspan="2" bgcolor="#F7F7F7"></td></tr>'].join("")
addressTR.insertAdjacentHTML("beforebegin", blankAddressTR);

let addressFunctionToDOM = [
  '<td align="left">For reference only, please verify:</td>',
  `<td align="left"><div id="addressFunctionToDOM">${fullURLAddress}</div><br></td>`,
].join("");



document.getElementById("blankAddressTR").insertAdjacentHTML("beforebegin", addressFunctionToDOM);
document.getElementById("addressFunctionToDOM").appendChild(buttonFillAddress);
document.getElementById("addressFunctionToDOM").appendChild(buttonClearAddress);


//Set Custom Address Field, toggle button
document.querySelector("#addressFunctionToDOM").colSpan = "3";
var customAddressToggle = document.createElement("button");
customAddressToggle.innerHTML = "New Address from Zillow";
customAddressToggle.className = "customAddressToggle addressButton";

var customAddressText = document.createElement("input");
customAddressText.setAttribute("type", "text");
customAddressText.className = "customAddressText textbox";
customAddressText.size = 35;
customAddressText.placeholder = "Paste the new Zillow address here..."

var setCustomAddressBtn = document.createElement("button");
setCustomAddressBtn.innerHTML = "Set Address";
setCustomAddressBtn.className = "setCustomAddressBtn textbox addressButton";
//init with display none
setCustomAddressBtn.style.display = "none"
customAddressText.style.display = "none";

document.getElementById("addressFunctionToDOM").appendChild(customAddressToggle)
document.getElementById("addressFunctionToDOM").appendChild(customAddressText)
document.getElementById("addressFunctionToDOM").appendChild(setCustomAddressBtn)

customAddressToggle.addEventListener("click", function (e) {
  e.preventDefault();
  if (customAddressText.style.display === "none") {
    customAddressText.style.display = "";
    customAddressText.focus();
  } else {
    customAddressText.style.display = "none";
  }
  if (setCustomAddressBtn.style.display === "none") {
    setCustomAddressBtn.style.display = "";
    customAddressText.focus();
  } else {
    setCustomAddressBtn.style.display = "none";
  }
});


//validate email
function emailValidation() {
  let emailInput = document.getElementById("EmailAddress");
  let email_regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  emailInput.addEventListener("input", function () {
    if ((email_regex.test(emailInput.value)) || emailInput.value == "") {
      emailInput.setCustomValidity("");
    } else {
      emailInput.setCustomValidity("Verify email address format. No spaces at the end.");
    }
  }
    , false);
}
//Insert Email in DOM for Agent's reference


/////////////////////////////////////////

//insert Address new TR
var url_string = window.location.href;
var urlEmail = new URL(url_string);
if (urlEmail.searchParams.has("email")) {
  var email = (urlEmail.searchParams.get("email")).toLowerCase();
}

//Address Buttons
let buttonFillEmail = document.createElement("button");
let buttonClearEmail = document.createElement("button");

buttonFillEmail.innerHTML = "Fill Email";
buttonClearEmail.innerHTML = "Clear Email";


buttonFillEmail.className = "emailButton";
buttonClearEmail.className = "emailButton";


buttonFillEmail.onclick = function (e) {
  e.preventDefault();
  document.getElementById("EmailAddress").value = email;
}

buttonClearEmail.onclick = function (e) {
  e.preventDefault();
  document.getElementById("EmailAddress").value = "";
}

let otherCostsHouse = document.createElement('div');
otherCostsHouse.id = 'otherCostsHouse';

var otherCostsHouseImg = document.createElement('img');
otherCostsHouseImg.src = chrome.runtime.getURL('img/lamassucrm/otherCosts.png')
/* Create and append phonic alphabet */

let alphabetDiv = document.createElement('div');
alphabetDiv.id = 'alphabetDiv';
/*Search icon */

var phoneticAlphabet = document.createElement("img");
phoneticAlphabet.src = chrome.runtime.getURL("img/lamassucrm/phonetic-alphabet.png");
phoneticAlphabet.id = "phonetic-alphabet";
phoneticAlphabet.className = "phonetic-alphabet";
alphabetDiv.appendChild(phoneticAlphabet);


let emailTR = document.querySelector("body > form > table:nth-child(8) > tbody > tr:nth-child(4)");
var blankEmailTR = ['<tr align="left" id="blankTREmail"><td colspan="3" bgcolor="#F7F7F7"></td></tr>'].join("")
emailTR.insertAdjacentHTML("beforebegin", blankEmailTR);


let alphabetTR = document.querySelector("body > form > table:nth-child(7) > tbody > tr:nth-child(4)");
var blankAlphabetTR = ['<tr align="left" id="blankAlphabetTR"><td colspan="3" bgcolor="#F7F7F7">' + phoneticAlphabet.outerHTML + '</td></tr>'].join("")
alphabetTR.insertAdjacentHTML("afterend", blankAlphabetTR);

let emailToDOM = [
  '<td align="left">For reference only, please verify:</td>',
  '<td align="left" id="emailIntDOM">' + email + ' <br></td>'
].join("")

let emailToDOMEmptyEmail = [
  '<td align="left">For reference only, please verify:</td>',
  '<td align="left" id="emailIntDOM">NO EMAIL ON RECORDS, ASK FOR ONE</td>'
].join("")




//Toggle the Alphabet
// Create the Phonetic Alphabet button
let buttonPhoneticAlphabet = document.createElement("button");
buttonPhoneticAlphabet.innerHTML = "Phonetic Alphabet";
buttonPhoneticAlphabet.className = "phoneticAlphabetButton";

// Event listener for the Phonetic Alphabet button
buttonPhoneticAlphabet.addEventListener("click", function (e) {
  e.preventDefault();

  // Get the element with id #phonetic-alphabet
  var phoneticAlphabet = document.getElementById("phonetic-alphabet");

  // Toggle the display property
  if (phoneticAlphabet.style.display === "none") {
    phoneticAlphabet.style.display = "block";
  } else {
    phoneticAlphabet.style.display = "none";
  }
});

// Insert emailToDOM
if (email !== "") {
  document.getElementById("blankTREmail").insertAdjacentHTML("beforebegin", emailToDOM);
  document.getElementById("emailIntDOM").appendChild(buttonFillEmail);
  document.getElementById("emailIntDOM").appendChild(buttonClearEmail);
  document.getElementById("emailIntDOM").appendChild(buttonPhoneticAlphabet);

  // Trigger the button click event immediately after appending
  document.querySelector("#emailIntDOM > button.phoneticAlphabetButton").click();
} else {
  document.getElementById("blankTREmail").insertAdjacentHTML("beforebegin", emailToDOMEmptyEmail);
  document.getElementById("emailIntDOM").appendChild(buttonPhoneticAlphabet);

  // Trigger the button click event immediately after appending
  document.querySelector("#emailIntDOM > button.phoneticAlphabetButton").click();
}



//Phone Format function

document.querySelector("body > form > table:nth-child(4) > tbody > tr:nth-child(6) > td:nth-child(2)").id = "homePhoneTR"

let formatPhoneNumber = document.createElement("button");
formatPhoneNumber.className = "formatPhoneButton";
formatPhoneNumber.innerHTML = "Format Phone";
document.getElementById("homePhoneTR").appendChild(formatPhoneNumber);


document.querySelector("#homePhoneTR > button").onclick = function (e) {
  e.preventDefault();
  var phone = document.getElementById("HomePhone").value;
  var newphone = phone.replace(/(\d{3})(\d{3})(\d{4})/, '$1-$2-$3');
  var newphone = newphone.replace(/[()]/g, '');
  var newphone = newphone.replace(/\s/g, '-');
  if (newphone.charAt(0) === '-') {
    newphone = newphone.substring(1);
  }
  if (newphone.charAt(newphone.length - 1) === '-') {
    newphone = newphone.substring(0, newphone.length - 1);
  }
  document.getElementById("HomePhone").value = newphone;
  console.log(newphone)
}

//Fix some td colspan
document.querySelector("body > form > table:nth-child(5) > tbody > tr:nth-child(3) > td:nth-child(1)").colSpan = "0";
document.querySelector("body > form > table:nth-child(5) > tbody > tr:nth-child(4) > td:nth-child(1)").colSpan = "0";
document.querySelector("body > form > table:nth-child(5) > tbody > tr:nth-child(5) > td:nth-child(1)").colSpan = "0";





//parse the text value into different variables

let streetCustomAddress;
let cityCustomAddress;
let stateCustomAddress;
let zipcodeCustomAddress;

document.querySelector('.setCustomAddressBtn').addEventListener('click', function (event) {
  event.preventDefault();
  var customAddressText = document.querySelector('.customAddressText').value;
  streetCustomAddress = customAddressText.substring(0, customAddressText.indexOf(","));
  cityCustomAddress = customAddressText.substring(customAddressText.indexOf(",") + 2, customAddressText.indexOf(",", customAddressText.indexOf(",") + 1));
  var state_zipcode = customAddressText.substring(customAddressText.lastIndexOf(',') + 1);
  stateCustomAddress = state_zipcode.match(/[A-Z]{2}/)[0];
  zipcodeCustomAddress = state_zipcode.match(/[0-9]{4,5}/)[0];

  document.getElementById("StreetAddress").value = streetCustomAddress;
  document.getElementById("City").value = cityCustomAddress;
  document.getElementById("State").value = stateCustomAddress;
  document.getElementById("ZipCode").value = zipcodeCustomAddress;

  console.log(streetCustomAddress)
  console.log(cityCustomAddress)
  console.log(state_zipcode)
  console.log(stateCustomAddress);
  console.log(zipcodeCustomAddress);

});




//CREATE BUTTONS FOR ASKING PRICE


const selectElement = document.querySelector('#disc_price');
const selectOptions = selectElement.querySelectorAll('option');

selectOptions.forEach(option => {
  const disc_priceBtn = document.createElement('button');
  disc_priceBtn.className = `disc_price ${option.value.replace(/\s/g, '')}`;
  disc_priceBtn.innerHTML = option.innerHTML.replace(/[\d.]/g, '');
  disc_priceBtn.value = option.value;
  disc_priceBtn.style.marginLeft = '5px';
  disc_priceBtn.style.marginRight = '5px';
  disc_priceBtn.addEventListener('click', (e) => {
    e.preventDefault();
    let color;
    if (option.value === 'Above Range') {
      color = '#ffa500';
    } else if (option.value === 'Full Retail') {
      color = '#F24B27';
    } else {
      color = '#4CAF50';
    }
    selectElement.value = option.value;
    disc_priceBtn.style.backgroundColor = color;
    document.querySelectorAll('.disc_price').forEach(btn => {
      if (btn !== disc_priceBtn) {
        btn.style.backgroundColor = 'white';
      }
    });
    selectElement.addEventListener('change', (e) => {
      if (e.target.value === '') {
        document.querySelectorAll('.disc_price').forEach(btn => {
          btn.style.backgroundColor = 'white';
        });
      }
    });
  });
  if (option.value === '') {
    disc_priceBtn.style.display = 'none';
  }
  selectElement.parentNode.appendChild(disc_priceBtn);
});







//CREATE BUTTONS LEAD SOURCE
function createLeadSourceButtons() {
  const selectLeadSource = document.querySelector('#utm_source');
  const utmSourceDiv = document.createElement('div');
  selectLeadSource.parentNode.insertBefore(utmSourceDiv, selectLeadSource.nextSibling);

  // Subdomain-specific configurations
  const domainConfigs = {
    "uncommonhome.": {
      buttonValues: [
        "LAMASSU COLD CALL",
        "LAMASSU COLD CALL (LIVE TRANSFER)",
        "LAMASSU LEAD (LIVE TRANSFER NO ANSWER)"
      ],
      highlightColor: '#ffd700'
    }
    // Add more subdomain configurations as needed
  };

  // Determine current configuration based on hostname or default behavior
  const currentConfig = Object.keys(domainConfigs).find(domain => window.location.hostname.startsWith(domain));
  let buttonValues = currentConfig ? domainConfigs[currentConfig].buttonValues : [];
  let highlightColor = currentConfig ? domainConfigs[currentConfig].highlightColor : 'white';

  // For default behavior, add button values based on select options
  if (!currentConfig) {
    selectLeadSource.querySelectorAll('option').forEach(option => {
      if (option.value.includes('COLD') || option.value.includes('SPANISH')) {
        buttonValues.push(option.value);
      }
    });
  }

  // Create buttons based on determined values
  buttonValues.forEach(val => {
    const button = document.createElement('button');
    button.className = `utm_source ${val.replace(/\s/g, '')}`;
    button.textContent = val;
    button.value = val;
    button.style.display = 'inline';
    button.style.marginLeft = '10px';
    button.style.marginRight = '10px';
    utmSourceDiv.appendChild(button);
  });

  // Event delegation for button clicks
  utmSourceDiv.addEventListener('click', (event) => {
    if (event.target.tagName === 'BUTTON') {
      event.preventDefault(); // Prevent default action
      const button = event.target;
      selectLeadSource.value = button.value;
      
      // Apply or reset highlight color
      document.querySelectorAll('.utm_source').forEach(btn => {
        btn.style.backgroundColor = btn === button ? highlightColor : 'white';
      });
    }
  });

  // Update button display based on select change, resetting color if necessary
  selectLeadSource.addEventListener('change', () => {
    document.querySelectorAll('.utm_source').forEach(btn => {
      btn.style.backgroundColor = 'white';
    });
  });
}

createLeadSourceButtons();




//START OF CREATE BUTTONS SPANISH SELECT MENU
const selectSpanishElement = document.querySelector('#spanish');
const selectSpanishOptions = selectSpanishElement.querySelectorAll('option');

selectSpanishElement.style.display = 'none';

selectSpanishOptions.forEach(option => {
  const spanishBtn = document.createElement('button');
  spanishBtn.className = `spanish ${option.value.replace(/\s/g, '')}`;
  spanishBtn.innerHTML = option.innerHTML.replace(/[\d.]/g, '');
  spanishBtn.value = option.value;
  spanishBtn.style.marginLeft = '5px';
  spanishBtn.style.marginRight = '5px';
  spanishBtn.addEventListener('click', (e) => {
    e.preventDefault();
    let color;
    if (option.value === 'Yes') {
      color = '#4CAF50';
    } else if (option.value === 'No') {
      color = '#ffa500';
    } else {
      color = '#4CAF50';
    }
    selectSpanishElement.value = option.value;
    spanishBtn.style.backgroundColor = color;
    document.querySelectorAll('.spanish').forEach(btn => {
      if (btn !== spanishBtn) {
        btn.style.backgroundColor = 'white';
      }
    });
  });
  if (option.value === '') {
    spanishBtn.style.display = 'none';
  }
  selectSpanishElement.parentNode.appendChild(spanishBtn);
});

const checkSelectedOption = () => {
  let currentOption = document.getElementById('pool').value;
  document.querySelectorAll('.poolOption').forEach(btn => {
    let color;
    if (currentOption === 'Yes') {
      color = '#4CAF50';
    } else if (currentOption === 'No') {
      color = '#ffa500';
    }
    if (btn.value === currentOption) {
      btn.style.backgroundColor = color;
    } else {
      btn.style.backgroundColor = 'white';
    }
  });
};

document.getElementById('pool').addEventListener('change', (e) => {
  checkSelectedOption();
});

setInterval(() => {
  checkSelectedOption();
}, 1000);

//END OF CREATE BUTTONS SPANISH SELECT MENU
///////////////////////////////////////////////////////////////////////////
//START OF CREATE BUTTONS MORTGAGE SELECT MENU
const selectMortgageElement = document.querySelector('#has_mortgage');
const selectMortgageOptions = selectMortgageElement.querySelectorAll('option');

selectMortgageElement.style.display = 'none';

selectMortgageOptions.forEach(option => {
  const mortgageBtn = document.createElement('button');
  mortgageBtn.className = `mortgage ${option.value.replace(/\s/g, '')}`;
  mortgageBtn.innerHTML = option.innerHTML.replace(/[\d.]/g, '');
  mortgageBtn.value = option.value;
  mortgageBtn.style.marginLeft = '5px';
  mortgageBtn.style.marginRight = '5px';
  mortgageBtn.addEventListener('click', (e) => {
    e.preventDefault();
    let color;
    if (option.value === 'Yes') {
      color = '#4CAF50';
    } else if (option.value === 'No') {
      color = '#ffa500';
    } else {
      color = '#4CAF50';
    }
    selectMortgageElement.value = option.value;
    mortgageBtn.style.backgroundColor = color;
    document.querySelectorAll('.mortgage').forEach(btn => {
      if (btn !== mortgageBtn) {
        btn.style.backgroundColor = 'white';
      }
    });
  });
  if (option.value === '') {
    mortgageBtn.style.display = 'none';
  }
  selectMortgageElement.parentNode.appendChild(mortgageBtn);
});

const checkSelectedOptionMortgage = () => {
  let currentOption = selectMortgageElement.value;
  document.querySelectorAll('.mortgage').forEach(btn => {
    let color;
    if (currentOption === 'Yes') {
      color = '#4CAF50';
    } else if (currentOption === 'No') {
      color = '#ffa500';
    }
    if (btn.value === currentOption) {
      btn.style.backgroundColor = color;
    } else {
      btn.style.backgroundColor = 'white';
    }
  });
};

selectMortgageElement.addEventListener('change', (e) => {
  checkSelectedOptionMortgage();
});

setInterval(() => {
  checkSelectedOptionMortgage();
}, 1000);
//END OF CREATE BUTTONS MORTGAGE SELECT MENU

//Use localStorage to remember Agent Name
//First we set a change event listener on the select tag
document.getElementById("from_userid").addEventListener("change", function () {
  //We check if the value is different than "All Agents"
  if (this.value !== "All Agents") {
    //If so, we set an item in chrome.storage.local with the value
    chrome.storage.local.set({ 'lastSelected': this.value });
    //We log success message
    console.log('Value is set to ' + this.value);
  }
});

//When the page is loading, we check if we have an item stored in chrome.storage.local
chrome.storage.local.get("lastSelected", function (result) {
  //If so, we set the value of the select tag to the stored item
  if (result.lastSelected) {
    document.getElementById("from_userid").value = result.lastSelected;
  }
});



// Function to automatically adjust the height of text areas in the DOM as we type new lines
function autoAdjustTextArea() {
  let textAreas = document.getElementsByTagName("textarea");
  for (let i = 0; i < textAreas.length; i++) {
    textAreas[i].addEventListener("input", function () {
      this.style.height = "auto";
      this.style.height = Math.min(this.scrollHeight, 300) + "px";
    });
  }
}

autoAdjustTextArea()

//code to autoselect 'Yes' on matrix input when clicking 
setTimeout(() => {
  const miniTemplatesDropDwnbtns = document.querySelectorAll(".miniTemplatesDropDwnbtn");

  miniTemplatesDropDwnbtns.forEach((button) => {
    button.addEventListener("click", () => {
      if (button.textContent.includes("Matrix")) {
        document.querySelector("#matrix").value = "Yes";
      }
      console.log("okay");
    });
  });
}, 5000);


/*For use on Realtor Webforms only*/
if (window.location.href.indexOf("realtor=true") > -1) {
  for (let i = 0; i < document.getElementById("utm_source").length; i++) {
    if (document.getElementById("utm_source").options[i].value === "REALTOR - OutBound Agent") {
      document.getElementById("utm_source").options[i].selected = true;
      break;
    }
  }

  for (let i = 0; i < document.getElementById("disc_price").length; i++) {
    if (document.getElementById("disc_price").options[i].value === "In Range") {
      document.getElementById("disc_price").options[i].selected = true;
      break;
    }
  }

  document.querySelectorAll('.disc_price.AboveRange, .disc_price.FullRetail, .disc_price.CreativeTerms').forEach(element => {
    element.style.display = 'none';
  });

  const bottomLine = document.getElementById("bottom_line");
  bottomLine.parentNode.insertAdjacentHTML("beforeend", "<div style='margin-top:10px;'><b>REMEMBER TO ASK IF IS WORKING WITH ANOTHER REALTOR</b><br></div>");
}

//fix for v2.1.1
let queryString = new URLSearchParams(window.location.search.substr(1));

if (queryString.get("realtor") === "true") {
  document.getElementById("mleadsource").value = queryString.get("sd_marketing_source");
  document.getElementById("fname").value = queryString.get("first_name");
  document.getElementById("lname").value = queryString.get("last_name");
}

//START OF FUNCTION TO display sections bar
var sections = document.querySelectorAll(".form-section");

function createDots(sections) {
  var dots = document.createElement("DIV");
  dots.className = "dots";

  sections.forEach(function (section, index) {
    var dot = document.createElement("SPAN");
    dot.className = "dot";

    if (index === 0) {
      dot.className += " active";
    }

    dot.addEventListener("click", function () {
      scrollTo(section.offsetTop, 300);
    });

    dots.appendChild(dot);
  });

  return dots;
}

function scrollTo(to, duration) {
  var start = document.body.scrollTop,
    change = to - start,
    currentTime = 0,
    increment = 20;

  var animateScroll = function () {
    currentTime += increment;
    var val = Math.easeInOutQuad(currentTime, start, change, duration);
    document.body.scrollTop = val;
    if (currentTime < duration) {
      setTimeout(animateScroll, increment);
    }
  };
  animateScroll();
}

//t = current time
//b = start value
//c = change in value
//d = duration
Math.easeInOutQuad = function (t, b, c, d) {
  t /= d / 2;
  if (t < 1) return c / 2 * t * t + b;
  t--;
  return -c / 2 * (t * (t - 2) - 1) + b;
};

var sections = document.querySelectorAll(".form-section");

document.body.appendChild(createDots(sections));

window.addEventListener("scroll", function (event) {
  var scrollTop = document.body.scrollTop;

  sections.forEach(function (section, index) {
    var active = "";

    if (
      scrollTop >= section.offsetTop - 10 &&
      scrollTop < section.offsetTop + section.offsetHeight
    ) {
      active = " active";
    }

    document.querySelector(".dots .dot.active").className =
      "dot" + active;
  });
});

//END OF FUNCTION TO display sections bar

//START OF FUNCTION TO add a progress bar indicator


// setTimeout(() => {
//   const progressDivBarDiv = document.createElement('div');
//   progressDivBarDiv.className = 'progress';
//     const progressDiv = document.createElement('progress');
//   progressDiv.id = 'js-progress';
//   progressDiv.value = '';
//   progressDiv.max = 100;

//   progressDivBarDiv.appendChild(progressDiv);
//   document.body.insertBefore(progressDivBarDiv, document.body.firstChild);
//   const progressBarDiv = document.querySelector('#progressDivBarDiv');
//   const tableWidth = document.querySelector('#Table_1').offsetWidth;




//   let tableHeight = document.querySelector('#Table_1').offsetHeight;
//   let formHeight = document.querySelector('body > form').offsetHeight;

//   let totalHeight = tableHeight + formHeight
//   console.log(`Total height is: ${totalHeight}px`);

//   let maxScrollHeight = document.documentElement.scrollHeight - window.innerHeight;

//   window.addEventListener('scroll', e => {
//     let currentScrollHeight = window.scrollY;
//     let percentage = (currentScrollHeight/maxScrollHeight)*100;

//     // limit the percentage to 100
//     percentage = Math.min(percentage, 100);
//     document.querySelector("#js-progress").setAttribute('value', percentage);
//     console.log(`Scrolled ${percentage}% of the page`);
//   });

// }, 500);
//END OF FUNCTION TO add a progress bar indicator


//START OF FUNCTION To get zestimate from other tab from within lamassucrm
function getZillowFromTabs() {
  document.getElementById('zestimateTitle').addEventListener('click', getZillowFromTabs);

  chrome.runtime.sendMessage({ message: 'fullAddress', url: fullURLAddress }, function (response) {
    if (response.found) {
      console.log('Exists! Tab ID: ' + response.tabId);
      console.log(response.zestimate);
    } else {
      console.log('Does not exist');
    }
  });
}


function limitInputOnIntegrity() {
  if (!window.location.href.startsWith('https://integrity.')) return;
  ['repairs', 'conditions', 'occupied', 'tenant_details', 'reason', 'closing_time'].forEach(field => {
    const input = document.getElementById(field);
    if (!input) return;
    input.addEventListener('input', () => {
      if (input.value.length > 200) {
        input.value = input.value.slice(0, 200);
        alert(`Reached maximum allowed characters for "${field.replace('_', ' ')}". \nThis limit is only applied to "INTEGRITY"`);
      }
    });
  });
}

//Replace the input for Yes/No buttons
function selectPoolOptions() {
  const url = new URL(window.location.href);
  if (url.hostname.startsWith('kaizen.')) {
    const selectPoolElement = document.getElementById('pool');
    const yesBtn = document.createElement('button');
    const noBtn = document.createElement('button');

    yesBtn.className = 'poolOption';
    yesBtn.innerHTML = 'Yes';
    yesBtn.value = 'Yes';
    yesBtn.style.marginLeft = '5px';
    yesBtn.style.marginRight = '5px';
    yesBtn.addEventListener('click', (e) => {
      e.preventDefault();
      selectPoolElement.value = 'Yes';
      yesBtn.style.backgroundColor = '#4CAF50';
      noBtn.style.backgroundColor = 'white';
    });

    noBtn.className = 'poolOption';
    noBtn.innerHTML = 'No';
    noBtn.value = 'No';
    noBtn.style.marginLeft = '5px';
    noBtn.style.marginRight = '5px';
    noBtn.addEventListener('click', (e) => {
      e.preventDefault();
      selectPoolElement.value = 'No';
      noBtn.style.backgroundColor = '#ffa500';
      yesBtn.style.backgroundColor = 'white';
    });

    selectPoolElement.style.display = 'none';
    selectPoolElement.parentNode.insertBefore(yesBtn, selectPoolElement);
    selectPoolElement.parentNode.insertBefore(noBtn, selectPoolElement);
  }
}

function convertTelLinksToCallto() {
  // Get all the anchor elements on the page
  const anchors = document.getElementsByTagName('a');
  console.log("working....")
  // Iterate through each anchor element
  for (let i = 0; i < anchors.length; i++) {
    const anchor = anchors[i];
    const href = anchor.getAttribute('href');

    // Check if the href starts with 'tel:'
    if (href && href.startsWith('tel:')) {
      // Replace 'tel:' with 'callto:' and set it as the new href
      const newHref = href.replace('tel:', 'callto:');
      anchor.setAttribute('href', newHref);
    }
  }
}


function copyPhoneToNotesStride() {
  if (!window.location.href.startsWith('https://stride.')) return;

  var formatPhoneButton = document.querySelector('.formatPhoneButton');
  var homePhoneInput = document.getElementById('HomePhone');
  var noteTextarea = document.getElementById('note');

  formatPhoneButton.addEventListener('click', function () {
    var homePhoneValue = homePhoneInput.value;
    var existingText = noteTextarea.value;

    if (existingText === '') {
      noteTextarea.value = 'Phone number: ' + homePhoneValue;
    } else {
      noteTextarea.value = 'Phone number: ' + homePhoneValue + '\n' + existingText;
    }
  });
}



///////////////////////////
function highlightActiveTR() {
  // first, ensure that all buttons and the elements under specific TRs are not focusable
  var elementsToSkip = document.querySelectorAll('button, #otherCostsTR button, #otherCostsTR input, #matrixTR button, #matrixTR input,  #matrixTR select');
  elementsToSkip.forEach(function (element) {
    element.setAttribute('tabindex', '-1');
  });

  // then continue with your original logic for inputs
  var inputs = document.querySelectorAll('input[type="text"], input[type="password"], textarea, select');
  inputs.forEach(function (input) {
    input.addEventListener('focus', function () {
      var tr = input.closest('tr');
      tr.style.backgroundColor = '#90EE90'; // Lime color in hex
    });
    input.addEventListener('blur', function () {
      var tr = input.closest('tr');
      tr.style.backgroundColor = ''; // Reset background color
    });
  });
}


///////////////Webform: Reorder <li> in Tenants text.

function updateTenantsQuestions() {
  // Get the 'ul' list inside the 'td' element with the class 'tenant_details'
  const list = document.querySelector('.tenant_details td ul');

  // Get the 'li' item to be moved
  const listItem = list.querySelector('li');

  // Append it to the end of the 'ul' list
  list.appendChild(listItem);
}


///////////////Add link to mortgage calculator
function attachMortageCalculatorLink() {
  try {
    const hasMortgageElement = document.getElementById('has_mortgage');

    if (!hasMortgageElement) {
      throw new Error('Element with id "has_mortgage" not found');
    }

    // Create new link element
    const link = document.createElement('a');
    link.href = '#';
    link.className = 'mortgage-calculator-link';
    link.textContent = 'Current Mortgage Rates';

    // Attach click event to the link
    link.onclick = function (event) {
      event.preventDefault();
      const width = 950;
      const height = 500;
      const left = (screen.width - width) / 2;
      const top = (screen.height - height) / 2;

      // Open the new window
      window.open(
        'https://widgets.icanbuy.com/c/standard/us/en/mortgage/tables/Mortgage.aspx?siteid=0ce53ef9a8469eda',
        '_blank',
        `toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width=${width}, height=${height}, top=${top}, left=${left}`
      );
    }

    // Append the link to the has_mortgage parent element
    hasMortgageElement.parentNode.appendChild(link);

  } catch (error) {
    console.error('An error occurred in attachMortageCalculatorLink: ', error);
  }
}

/////////////////v2.9.7 As per request of Marcus, we added a TAKE OVER CALL button below the "Manager Approval Notes" so the TLs can mark in the notes if the call was taken over by them.


function createButtonWithDiv() {
  var buttonDiv = document.createElement('div');
  var button = document.createElement('button');
  button.id = 'takeOverCallBtn';
  button.innerHTML = 'TAKE OVER CALL';
  button.title = 'Use if this call had a take over by a TL or Manager';
  button.style.marginTop = '1px';
  buttonDiv.appendChild(button);
  return { buttonDiv, button };
}

function checkForTakeOverCall(textarea, button) {
  var isTakeOver = textarea.value.includes(':::TAKE OVER CALL:::');
  button.style.backgroundColor = isTakeOver ? 'green' : '';
  textarea.rows = Math.min(textarea.value.split('\n').length, 50);
}

function toggleTakeOverCall(textarea) {
  var takeOverText = '\n :::TAKE OVER CALL:::';
  if (textarea.value.includes(takeOverText)) {
    textarea.value = textarea.value.replace(takeOverText, '');
  } else {
    textarea.value += takeOverText;
  }
}

function takeOverNotes() {
  var managerNotesTextarea = document.getElementById('manager_notes');
  var { buttonDiv, button: takeOverCallBtn } = createButtonWithDiv();

  managerNotesTextarea.parentNode.insertBefore(buttonDiv, managerNotesTextarea.nextSibling);

  takeOverCallBtn.addEventListener('click', function (event) {
    event.preventDefault();
    toggleTakeOverCall(managerNotesTextarea);
    checkForTakeOverCall(managerNotesTextarea, takeOverCallBtn);
  });

  managerNotesTextarea.addEventListener('input', function () {
    checkForTakeOverCall(managerNotesTextarea, takeOverCallBtn);
  });

  checkForTakeOverCall(managerNotesTextarea, takeOverCallBtn);
}


//END OF TAKE COVER CALL BUTTON FUNCTION

function cloneNotesOnTop() {
  // Get the select menu with ID 'matrixAffiliates'
  var selectMenu = document.getElementById('matrixAffiliates');

  // Check if the select menu has 2 or more options
  if (selectMenu && selectMenu.options.length >= 2) {
    return; // Do nothing
  } else {
    // Get the element with class 'm-notes'
    var mNotesElement = document.querySelector('.m-notes');

    // Check if the element with class 'm-notes' exists
    if (mNotesElement) {
      // Clone the element
      var clonedElement = mNotesElement.cloneNode(true);

      // Find the target element
      var targetElement = document.querySelector('#Table_1 > tbody > tr:nth-child(2) > td');

      // Check if the target element exists
      if (targetElement) {
        // Replace the target element with the cloned element
        targetElement.replaceWith(clonedElement);
      } else {
        console.error("Target element not found!");
      }
    } else {
      console.error("Element with class 'm-notes' not found!");
    }
  }
}






//////////////////////////////////////////////Marketing Lead Source Test Phase
function addMarketingLeadSourceToTables() {
  // Get the URL's query parameters
  var queryParams = new URLSearchParams(window.location.search);

  // Retrieve the 'sd_marketing_source' value
  var marketingSource = queryParams.get('sd_marketing_source') || 'Default Text';

  // Define the HTML snippet, incorporating the marketing source value
  var htmlSnippet = `
      <tr class="xyz">
          <td class="marketing-lead-source" colspan="6" style="text-align: center;">
              <p >
                  <span>MARKETING LEAD SOURCE: ${marketingSource}</span>
              </p>
          </td>
      </tr>`;

  // Array of table IDs
  var tableIds = ['Table_2', 'Table_3', 'Table_4', 'Table_5', 'Table_6', 'Table_5_1'];

  // Loop through each table ID
  tableIds.forEach(function(tableId) {
      // Find the table by ID
      var table = document.getElementById(tableId);

      // Check if the table exists
      if (table) {
          // Create a new table row and set its inner HTML to the HTML snippet
          var newRow = document.createElement('tr');
          newRow.innerHTML = htmlSnippet;

          // Append the new row as the last child of the table body
          table.tBodies[0].appendChild(newRow);
      }
  });
}
function notes_taking() {
    console.log("notes taking loaded");
    // Declare variables for position and size
    let posX = Cookies.get('posX') || '0px',
        posY = Cookies.get('posY') || '0px',
        width = Cookies.get('width') || '250px',
        height = Cookies.get('height') || '160px';

 
    // Create the draggable and resizable textarea inside a div
    let draggableDiv = document.createElement('div');
    draggableDiv.id ='draggableNotesDiv';
    draggableDiv.style.cssText = `position: fixed; width: ${width}; height: ${height}; z-index: 9999;`;
    draggableDiv.style.left = posX;
    draggableDiv.style.top = posY;

    // Ensure that the div element is within the viewport boundaries
    let windowSize = {width: window.innerWidth, height: window.innerHeight},
        divSize = {width: parseInt(width, 10), height: parseInt(height, 10)},
        divPosition = {x: parseInt(posX, 10), y: parseInt(posY, 10)};

    divPosition.x = Math.max(0, Math.min(divPosition.x, windowSize.width - divSize.width));
    divPosition.y = Math.max(0, Math.min(divPosition.y, windowSize.height - divSize.height));

    // Update the div position after bounds check
    draggableDiv.style.left = divPosition.x + 'px';
    draggableDiv.style.top = divPosition.y + 'px';

    // Set posX and posY into cookies
    let cookieOptions = { domain: '.lamassucrm.com', expires: Infinity };
    Cookies.set('posX', divPosition.x, cookieOptions);
    Cookies.set('posY', divPosition.y, cookieOptions);

    let isVisible = Cookies.get('isVisible');
    if (isVisible === 'false') {
        draggableDiv.style.display = "none";
    } else {
        draggableDiv.style.display = "";
    }

    let titleLabelNoteDragWindow = document.createElement('div');
    titleLabelNoteDragWindow.id = 'titleLabelNoteDragWindow';
    titleLabelNoteDragWindow.style.cssText = "background-color: #006AFF; color: #FFFFFF; padding: 1px; cursor: move;";
    let titleLabelNoteDragWindowText = document.createElement('h1');
    titleLabelNoteDragWindowText.textContent = 'Notes: ';
    titleLabelNoteDragWindowText.style.cssText = "margin-block-start: 2px; margin-block-end: 2px;";
    titleLabelNoteDragWindow.appendChild(titleLabelNoteDragWindowText);

    let syncedTextarea = document.createElement('textarea');
    syncedTextarea.id = 'draggableTextareaId'; // Add an ID to the textarea
    syncedTextarea.style.cssText = "width: 100%; height: calc(100% - 40px); resize: none;";  // 40px roughly accounts for the titleLabelNoteDragWindow height
    syncedTextarea.addEventListener('input', function(){
        let originalTextarea = document.getElementById('note');
        originalTextarea.value = this.value;
    });

    let resizeHandle = document.createElement('div');
    resizeHandle.style.cssText = "width: 10px; height: 10px; background-color: #000; position: absolute; right: 0; bottom: 0; cursor: nwse-resize;";
    resizeHandle.addEventListener('mousedown', function(e) {
        e.preventDefault();
        window.addEventListener('mousemove', resize);
        window.addEventListener('mouseup', stopResize);
    });

    function resize(e) {
        draggableDiv.style.width = e.clientX - draggableDiv.offsetLeft + 'px';
        draggableDiv.style.height = e.clientY - draggableDiv.offsetTop + 'px';
        width = draggableDiv.style.width;
        height = draggableDiv.style.height;

        // Set width and height into cookies
        Cookies.set('width', width, { domain: '.lamassucrm.com', expires: Infinity });
        Cookies.set('height', height, { domain: '.lamassucrm.com', expires: Infinity });
    }

    function stopResize() {
        window.removeEventListener('mousemove', resize);
    }

    draggableDiv.appendChild(titleLabelNoteDragWindow);
    draggableDiv.appendChild(syncedTextarea);
    draggableDiv.appendChild(resizeHandle);

    document.body.appendChild(draggableDiv);

    // Initialize draggable functionality
    let draggie = new Draggabilly(draggableDiv, {
        handle: '#titleLabelNoteDragWindow'
    });

// Listen to drag events
// Variables to store the initial offset
let offsetX = 0;
let offsetY = 0;

// Listen to the 'dragStart' event to calculate the offset
draggie.on('dragStart', function(event, pointer) {
    offsetX = pointer.pageX - draggableDiv.offsetLeft;
    offsetY = pointer.pageY - draggableDiv.offsetTop;
});

draggie.on('dragEnd', function(event, pointer) {
    let windowSize = {width: window.innerWidth, height: window.innerHeight},
        divSize = {width: parseInt(width, 10), height: parseInt(height, 10)},
        newPosition = {x: pointer.pageX - offsetX, y: pointer.pageY - offsetY}; // Apply the offset here

    // Check if the window is out of bounds and readjust the position
    newPosition.x = Math.max(0, Math.min(newPosition.x, windowSize.width - divSize.width));
    newPosition.y = Math.max(0, Math.min(newPosition.y, windowSize.height - divSize.height));

    // Update the div position after bounds check
    draggableDiv.style.left = newPosition.x + 'px';
    draggableDiv.style.top = newPosition.y + 'px';

    // Set posX and posY into cookies
    let cookieOptions = { domain: '.lamassucrm.com', expires: Infinity };
    Cookies.set('posX', newPosition.x, cookieOptions);
    Cookies.set('posY', newPosition.y, cookieOptions);
});



    // Initial value of the note textarea
    let prevNoteValue = document.getElementById('note').value;

    // Interval function to check for changes in the #note textarea
    setInterval(function() {
        let noteTextarea = document.getElementById('note');
        if (noteTextarea.value !== prevNoteValue) {
                        // If value has changed, update synced textarea and update prevNoteValue
                        syncedTextarea.value = noteTextarea.value;
                        prevNoteValue = noteTextarea.value;
                    }
                }, 500);  
            
            }



            function draggableNotesVisibility() {
                let notes = document.getElementsByClassName("note");
                for (let note of notes) {
                    note.style.cursor = "pointer"; // Add hand cursor when hovering over the note element
                    let tds = note.getElementsByTagName("td"); // Get all td elements inside the note element
                    for (let td of tds) {
                        if (td.innerText === "Note:") {
                            td.addEventListener("mouseover", function () {
                                td.style.backgroundColor = "#006AFF";
                            });
                            td.addEventListener("mouseout", function () {
                                td.style.backgroundColor = "#F7F7F7";
                            });
                        }
                    }
                    note.addEventListener("dblclick", function () {
                        let draggableDiv = document.getElementById("draggableNotesDiv");
                        if (draggableDiv.style.display === "none") {
                            draggableDiv.style.display = "";
                            // Set isVisible into cookies
                            Cookies.set('isVisible', true, { domain: '.lamassucrm.com', expires: Infinity });
                        } else {
                            draggableDiv.style.display = "none";
                            // Set isVisible into cookies
                            Cookies.set('isVisible', false, { domain: '.lamassucrm.com', expires: Infinity });
                        }
                    });
                }
            }
            


            (function () {
                if (window.location.href.includes("synergy_leadcapture.php") || 
                    window.location.href.includes("lamassu_leadcapture.php")) {
                  notes_taking(); 
                  setTimeout(draggableNotesVisibility, 1000);
                }
              })();
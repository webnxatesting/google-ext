function calculateAndUpdateAverage() {
    const zillowInput = document.getElementById('zillowAverageInput').value.replace(/[,.]/g, '');
    const redfinInput = document.getElementById('redfinAverageInput').value.replace(/[,.]/g, '');
    const propstreamInput = document.getElementById('propstreamAverageInput').value.replace(/[,.]/g, '');

    let sum = 0;
    let count = 0;

    if (zillowInput) {
        sum += parseInt(zillowInput, 10);
        count++;
    }
    if (redfinInput) {
        sum += parseInt(redfinInput, 10);
        count++;
    }
    if (propstreamInput) {
        sum += parseInt(propstreamInput, 10);
        count++;
    }

    if (count > 0) {
        const average = sum / count;
        const formatter = new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        });
        document.getElementById('averageTotal').innerText = formatter.format(average);
    } else {
        document.getElementById('averageTotal').innerText = 'N/A';
    }

    // Update circle colors
    updateCircleColor('zillowAverageInput');
    updateCircleColor('redfinAverageInput');
    updateCircleColor('propstreamAverageInput');
}


// Rest of your code...

function setupInputListeners() {
    const inputs = ['zillowAverageInput', 'redfinAverageInput', 'propstreamAverageInput'];
    inputs.forEach(id => {
        const inputElement = document.getElementById(id);
        inputElement.addEventListener('input', calculateAndUpdateAverage);

        // Enhanced paste event to clean and format the value
        inputElement.addEventListener('paste', function(e) {
            e.preventDefault(); // Prevent the default paste action
            let pasteData = (e.clipboardData || window.clipboardData).getData('text');
            pasteData = pasteData.replace(/[,.]/g, ''); // Remove commas and dots from the pasted data
            if (!isNaN(pasteData) && pasteData.trim() !== '') {
                const formattedValue = parseInt(pasteData, 10).toLocaleString('en-US', {
                    maximumFractionDigits: 0,
                });
                document.execCommand("insertText", false, formattedValue); // Insert the cleaned and formatted data
            }
        });

        // Handle blur event to format value as price without decimals
        inputElement.addEventListener('blur', function() {
            let inputValue = this.value.replace(/[,.]/g, ''); // Strip commas and dots
            if (!isNaN(inputValue) && inputValue.trim() !== '') {
                this.value = parseInt(inputValue, 10).toLocaleString('en-US', {
                    maximumFractionDigits: 0,
                });
            }
        });
    });
}




/////////////////////////////


////////////////////////////////

function createInputTdElement(labelText, inputId) {
    let td = document.createElement("td");
    td.innerHTML = `<label for="${inputId}">${labelText}:</label><input type="text" id="${inputId}" placeholder="Enter price" class="price-input"><span id="${inputId}Circle" class="circle-symbol" title="Paste Price">🟠</span>`;
    td.querySelector(`#${inputId}Circle`).addEventListener('click', () => handleCircleClick(inputId));
    return td;
}


function handleCircleClick(inputId) {
    // Read from the clipboard
    navigator.clipboard.readText().then(text => {
        // Remove any commas or dots to ensure correct parsing
        const processedText = text.replace(/[,.]/g, '');
        if (!isNaN(processedText) && processedText.trim() !== '') {
            // Ensure the value is treated as an integer, removing decimals if any
            const numericValue = parseInt(processedText, 10);
            const formattedValue = numericValue.toLocaleString('en-US', {
                maximumFractionDigits: 0,
            });
            document.getElementById(inputId).value = formattedValue;
            calculateAndUpdateAverage();
        }
    }).catch(err => {
        console.error('Failed to read clipboard contents: ', err);
    });
}



function updateCircleColor(inputId) {
    const inputElement = document.getElementById(inputId);
    const circleElement = document.getElementById(inputId + 'Circle');

    if (inputElement && circleElement) {
        if (inputElement.value) {
            circleElement.innerText = '🟢'; // Green circle for value present
        } else {
            circleElement.innerText = '🟠'; // Orange circle for empty input
        }
    }
}

function insertAfter(newNode, referenceNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
}


function createZestimateAverageRow() {
    var bottomLine = document.querySelector('#bottom_line').closest('tr');

    if (!bottomLine) {
        console.error('bottomLine element not found');
        return;
    }

    var titleTr = document.createElement("tr");
    titleTr.id = "priceAverageTitle";
    var titleTd = document.createElement("td");
    titleTd.setAttribute("colspan", "4");
    titleTd.innerHTML = `<span style="font-weight: bold; color: green;">PLATFORMS PRICE AVERAGE</span><br>`;
    titleTr.appendChild(titleTd);
    insertAfter(titleTr, bottomLine);

    var zestimateTr = document.createElement("tr");
    zestimateTr.id = "zestimateAverage";
    zestimateTr.appendChild(createInputTdElement("Zillow", "zillowAverageInput"));
    zestimateTr.appendChild(createInputTdElement("Redfin", "redfinAverageInput"));
    zestimateTr.appendChild(createInputTdElement("Propstream", "propstreamAverageInput"));
    insertAfter(zestimateTr, titleTr);

    var totalAverageTr = document.createElement("tr");
    totalAverageTr.id = "totalAverageTR";
    totalAverageTr.style.cursor = "pointer";
    totalAverageTr.addEventListener('click', copyTotalAverageClick);

    var totalAverageTd = document.createElement("td");
    totalAverageTd.setAttribute("colspan", "4");
    totalAverageTd.style.textAlign = "center";
    totalAverageTd.innerHTML = `<div style="color:green; font-size:24px; font-weight:900"><label for="averageTotal">Total Average: </label><span id="averageTotal">$$$</span></div>`;
    totalAverageTr.appendChild(totalAverageTd);
    insertAfter(totalAverageTr, zestimateTr);

    setupInputListeners();

    // Create and insert a new tr for the "Send to Notes" button below the totalAverageTr
    var sendToNotesTr = document.createElement("tr");
    var sendToNotesTd = document.createElement("td");
    sendToNotesTd.setAttribute("colspan", "4");
    sendToNotesTd.style.textAlign = "center";

    var sendToNotesButton = document.createElement("button");
    sendToNotesButton.innerText = "Send Averages to Notes";
    sendToNotesButton.id = "sendAveragesButton";
    sendToNotesButton.style.backgroundColor = "white";
    sendToNotesButton.style.color = "orange";
    sendToNotesButton.style.fontWeight = "bold";
    sendToNotesButton.style.border = "1px solid orange";
    sendToNotesButton.style.borderRadius = "10px";
    sendToNotesButton.style.cursor = "pointer";
    sendToNotesButton.style.padding = "10px 20px"; // Add padding for better visual appearance
    sendToNotesButton.addEventListener('click', function(event) {
        event.preventDefault();
        averageSendToNotes();
    });
    
    sendToNotesTd.appendChild(sendToNotesButton);
    sendToNotesTr.appendChild(sendToNotesTd);
    
    // Insert the Send to Notes tr after the totalAverageTr
    insertAfter(sendToNotesTr, totalAverageTr);
}


function insertAfter(newNode, referenceNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
}


// Global variable to store the last sent message
var lastSentMessage = "";

function averageSendToNotes() {
    var notesTextArea = document.getElementById("note");
    if (!notesTextArea) {
        console.error('Textarea element with ID "note" not found');
        return;
    }

    var zillowAverage = document.getElementById("zillowAverageInput").value.replace(/,/g, '') || '0';
    var redfinAverage = document.getElementById("redfinAverageInput").value.replace(/,/g, '') || '0';
    var propstreamAverage = document.getElementById("propstreamAverageInput").value.replace(/,/g, '') || '0';

    var sum = 0;
    var count = 0;
    var details = '';

    if (parseFloat(zillowAverage) > 0) {
        sum += parseFloat(zillowAverage);
        count++;
        details += `Zillow: $${parseFloat(zillowAverage).toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0})}\n`;
    }
    if (parseFloat(redfinAverage) > 0) {
        sum += parseFloat(redfinAverage);
        count++;
        details += `Redfin: $${parseFloat(redfinAverage).toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0})}\n`;
    }
    if (parseFloat(propstreamAverage) > 0) {
        sum += parseFloat(propstreamAverage);
        count++;
        details += `Propstream: $${parseFloat(propstreamAverage).toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0})}\n`;
    }

    var totalAverage = count > 0 ? sum / count : 0;
    var formattedTotalAverage = `$${totalAverage.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;

    var textToAppend = `\n \n The following averages among the platforms were used based on the info: \n\n` +
                        `${details}` +
                        `Total Average: ${formattedTotalAverage}\n`;

    // Check if the message to append is the same as the last sent message
    if (textToAppend === lastSentMessage) {
        console.log("This message has already been sent to notes.");
        return; // Prevent sending the same message again
    }

    notesTextArea.value += textToAppend;
    lastSentMessage = textToAppend; // Update the last sent message
}


function copyTotalAverageClick() {
    const totalAverageSpan = document.getElementById('averageTotal');
    if (!totalAverageSpan.classList.contains("animate")) {
        let averageTotal = totalAverageSpan.innerText;
        // Assuming the value is already in the right format and just needs to be copied
        navigator.clipboard.writeText(averageTotal).then(() => copyAlert(totalAverageSpan));
    }
}

function copyAlert(element) {
    let oldText = element.innerText;
    element.innerText = "Copied!";
    element.classList.add("animate");
    element.addEventListener('animationend', () => {
        element.classList.remove("animate");
        element.innerText = oldText;
        setTimeout(() => {
            element.innerText = oldText;
        }, 1000);
    });
}

if (!window.location.hostname.startsWith("vacantland.") && !window.location.hostname.startsWith("demo.")) {
    createZestimateAverageRow();
}



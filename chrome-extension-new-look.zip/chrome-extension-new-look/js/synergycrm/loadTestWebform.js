// Function to load test webform data
function loadTestWebformData() {
    // Check if the URL of the tab includes "demo.lamassucrm.com"
    if (window.location.href.includes("demo.lamassucrm.com")) {
      // Find the button with the name 'ABANDON'
      const abandonButton = document.querySelector('input[name="ABANDON"]');
      
      // If the button exists
      if (abandonButton) {
        // Attach a click event listener to the button
        abandonButton.addEventListener('click', function(event) {
          // Prevent the default behavior of the button
          event.preventDefault();
          
          // Find the textarea with the id '#manager_notes'
          const managerNotes = document.querySelector('#manager_notes');
          
          // If the textarea exists
          if (managerNotes) {
            // Append 'AAA' to the existing value in the textarea
            managerNotes.value += 'AAA';
          }
  
          // Set values for the input fields
          const inputMappings = {
            'HomePhone': '1234567890',
            'StreetAddress': '123 Mainstreet',
            'City': 'TestCity',
            'ZipCode': '12345',
            'reason': 'reason why for test',
            'bottom_line': '1'
          };
  
          for (let id in inputMappings) {
            const inputElement = document.getElementById(id);
            if (!inputElement) {
              console.warn(`Input with id ${id} not found.`);
              continue;
            }
            inputElement.value = inputMappings[id];
          }
  
          // Set values for the select fields
          const selectMappings = {
            'State': 'AL',
            'utm_source': 'LAMASSU COLD CALL',
            'matrix': 'Yes',
            'disc_price': 'Full Retail',
            'from_userid': '1389',
            'manager_approving': 'No Approval Required'
          };
  
          for (let id in selectMappings) {
            const selectElement = document.getElementById(id);
            if (!selectElement) {
              console.warn(`Select with id ${id} not found.`);
              continue;
            }
            selectElement.value = selectMappings[id];
          }
        });
      }
    }
  }
  
  // Call the function to set up the event listener
  loadTestWebformData();

// function loadTestWebform() {
//     const currentDomain = window.location.hostname;

//     if (currentDomain.startsWith('demo.lamassucrm.com')) {
//         fillFormFields();
//     } else {
//         console.warn('This function is only valid for demo.lamassucrm.com domain.');
//     }
// }

// function hasChildWithText(parent, childTagName, text) {
//     for (let child of parent.children) {
//         if (child.tagName === childTagName && child.textContent.trim() === text) {
//             return true;
//         }
//     }
//     return false;
// }
// function hasChildWithText(parent, childTagName, text) {
//     for (let child of parent.children) {
//         if (child.tagName === childTagName && child.textContent.trim() === text) {
//             return true;
//         }
//     }
//     return false;
// }

function fillFormFields() {
    // Set values for the input fields
    const inputMappings = {
        'HomePhone': '1234567890',
        'StreetAddress': '123 Mainstreet',
        'City': 'TestCity',
        'ZipCode': '12345',
        'reason': 'reason why for test',
        'bottom_line': '1'
    };

    for (let id in inputMappings) {
        const inputElement = document.getElementById(id);
        if (!inputElement) {
            console.warn(`Input with id ${id} not found.`);
            continue;
        }
        inputElement.value = inputMappings[id];
    }

    // Set values for the select fields
    const selectMappings = {
        'State': 'AL',
        'utm_source': 'LAMASSU COLD CALL',
        'matrix': 'Yes',
        'disc_price': 'Full Retail',
        'from_userid': '1389',
        'manager_approving': 'No Approval Required'
    };

    for (let id in selectMappings) {
        const selectElement = document.getElementById(id);
        if (!selectElement) {
            console.warn(`Select with id ${id} not found.`);
            continue;
        }
        selectElement.value = selectMappings[id];
    }
}

// document.addEventListener('DOMContentLoaded', () => {
//     setTimeout(loadTestWebform, 1500);
// });

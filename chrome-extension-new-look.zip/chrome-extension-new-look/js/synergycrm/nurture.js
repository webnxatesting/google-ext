//Functions for the Nurture Campaign. It will help to call faster, reducing repetitive work when dialing. 
function CRMFormatPhone() {
    const phoneLinks = document.querySelectorAll('a[href^="tel:"]');
    
    phoneLinks.forEach(link => {
      link.addEventListener('click', (event) => {
        const phoneNumber = link.textContent.replace(/-/g, '');
        navigator.clipboard.writeText(phoneNumber)
          .then(() => {
            console.log(`Copied ${phoneNumber} to clipboard`);
            window.location.href = link.href;
          })
          .catch((error) => {
            console.error(`Failed to copy ${phoneNumber} to clipboard: ${error}`);
          });
        event.preventDefault();
      });
    });
  }

  function CRMFormatPhonePodio() {
    const phoneElement = document.querySelector('#phone');
    const labelContentElement = phoneElement.querySelector('.label-content');
  
    // Add cursor hand on mouse hover for the word "Phone"
    labelContentElement.style.cursor = 'pointer';
  
    phoneElement.addEventListener('click', (event) => {
      const phoneNumberElement = phoneElement.querySelector('.phone-field-component__view-mode__values .phone-field-component__view-mode__cell[role="gridcell"]');
      if (phoneNumberElement) {
        const phoneNumber = phoneNumberElement.textContent.replace(/-/g, '').replace(/[()]/g, '').replace(/\s+/g, '');
  
        navigator.clipboard.writeText(phoneNumber)
          .then(() => {
            console.log(`Copied ${phoneNumber} to clipboard`);
          })
          .catch((error) => {
            console.error(`Failed to copy ${phoneNumber} to clipboard: ${error}`);
          });
      }
    });
  }
  
  function observeBodyForPhone() {
    const body = document.querySelector('body');
    const observer = new MutationObserver((mutationsList, observer) => {
      for (let mutation of mutationsList) {
        if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
          const addedNode = mutation.addedNodes[0];
          if (addedNode.id === 'phone') {
            CRMFormatPhonePodio();
            break;
          }
        } else if (mutation.type === 'attributes' && mutation.attributeName === 'id' && mutation.target.id === 'phone') {
          CRMFormatPhonePodio();
          break;
        }
      }
    });
  
    observer.observe(body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['id'],
    });
  }
  
  observeBodyForPhone();
  
  
  

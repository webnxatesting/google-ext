function matrixHtml() {
  return {
    template: `
     <table id='matrix-responsive-XL' class='matrix-table'>
      <thead>
        <tr>
          <td class='m-notes' colspan='6'><p class='m-p' id='notesValue'>{{notes}}</p></td>
        </tr> 
          <th class='zestimate' colspan='6' style="background: #fff !important; border: none; color: black; font-size: 14px; font-weight: 300;">
            <div class="d-flex text-center justify-content-center" style="line-height: 40px; gap: 20px">                        
            <div class='zestimateSpan'>
              <span id='zestimateTitle' class='zestimateTitle' style="color: #000">
                ZESTIMATE:</span>
                <span class='currency'>$</span>
                <input id='zestimateInput'
                  [keyup]="zestimateTyped"
                  [keypress]="preventDefault"
                  autocomplete="off" type='text' size='8'>
              </div>
              <div class='askingPriceSpan'>
                <span class='zestimateTitle' style="color: #000">ENTER ASKING PRICE:</span>
                <span class='currency'>$</span>
                <input id='askingPriceInput'
                  [keyup]="askingPriceTyped"
                  [keypress]="preventDefault"
                  autocomplete="off" type='text' size='8'>
              </div>            
            </div>
          </th>
        </tr>
      </thead>
      <tbody id='matrixTbody'>
        <tr>
          <th colspan='6' class='matrix-csm p-0'>
            <div class="row text-center" style="line-height: 40px; color: #ffffff">
            <div class='csmSpan col-3' style="background: #24a1b0">CSM: <span id='csmValue'>{{csm}}</span></div>
            <div class='investorsSpan col-3' style="background: #0695a6">
              INVESTORS: <span id='investorValue'>{{investor}}</span>
            </div>
            <div class='col-3' style="background: #027d8c">
              FORECLOSURE: <span id='foreclosureValue'>{{foreclosure}}</span>
            </div>
            <div class='col-3' style="background: #005e68">
              TERMS: <span id='termsValue'>{{terms}} {{termsInPercentage}}</span>
            </div>
            </div>
            </div>
          </th>
        </tr>
        <tr>
          <td colspan="6" style="background: #415f61">
            <div class="row" style="color: #fff;">
              <div class="col"></div>
              
              <div class="col-3 text-center row">
                <div class="col-12 mb-3">CAMPAIGN</div>
                <div id='affiliatesSelection' class='m-r-campaign m-standard mb-3 col-12' style="background: none; border: none;">
                  <select 
                      name='options'
                      id='matrixAffiliates'
                      options='affiliateItems'
                      [change]='campaignSelected'
                      style="min-width: 200px;"
                  >
                  </select>
                </div>
                <div class="col-12 mb-2" style="background: #24a1b0; line-height: 30px;">IN RANGE</div>
                <div class="col-12 mb-2">
                  <div class="row">
                  <div class='m-r-ir col' [click]='onClickIrBegin' style="line-height: 30px; background: #24a1b0;">
                    <span [class]='irBeginReadWrite'>{{irBegin}}%</span>
                    <input [class]='irBeginReadWrite' type='number'
                          id='editIrBeginValue'
                          [keypress]="irBeginTyped"
                          out="irBegin">
                  </div>
                  <div class='m-r-ir col' [click]='onClickIrEnd' style="line-height: 30px; background: #24a1b0; margin-left: 0.5rem;">
                    <span [class]='irEndReadWrite'>{{irEnd}}%</span>
                    <input [class]='irEndReadWrite' type='number'
                          id='editIrEndValue'
                          [keypress]="irEndTyped"
                          out="irEnd">
                  </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="row" style="line-height: 30px;">
                  <div class='col' style="border: 1px solid #24a1b0;"><span id='irBeginDollarValue'>{{irDollarBegin}}</span></div>
                  <div class='col' style="border: 1px solid #24a1b0; margin-left: 0.5rem;"><span id='irEndDollarValue'>{{irDollarEnd}}</span></div>
                  </div>
                </div>
              </div>


              <div class="col-3 text-center row" style="margin-left: 20px;">
                <div class="col-12 mb-3">MULTI FAMILY</div>
                <div id='affiliatesSelection' class='m-r-campaign m-standard mb-3 col-12' style="background: none; border: none; line-height: 25px;">
                  <span class='rentValueSpan'></span><span id='multiValue'></span>
                  <span id='multiDollarValue'>{{dollarMultiFamily}}</span>
                </div>
                <div class="col-12 mb-2" style="background: #ce9b01; line-height: 30px;">ABOVE RANGE</div>
                <div class="col-12 mb-2">
                  <div class="row">
                  <div class='m-r-ir col' [click]='onClickIrBegin' style="line-height: 30px; background: #ce9b01;">
                    <span [class]='arBeginReadWrite'>{{arBegin}}%</span>
                    <input [class]='arBeginReadWrite' type='number'
                          id='editArBeginValue'
                          [keypress]='arBeginTyped'
                          out="arBegin">
                  </div>
                  <div class='m-r-ir col' [click]='onClickIrEnd' style="line-height: 30px; background: #ce9b01; margin-left: 0.5rem;">
                    <span [class]='arEndReadWrite'>{{arEnd}}%</span>
                    <input [class]='arEndReadWrite' type='number'
                          id='editArEndValue'
                          [keypress]="arEndTyped"
                          out="arEnd">
                  </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="row" style="line-height: 30px;">
                  <div class='col' style="border: 1px solid #24a1b0;"><span id='arBeginDollarValue'>{{arDollarBegin}}</span></div>
                  <div class='col' style="border: 1px solid #24a1b0; margin-left: 0.5rem;"><span id='arEndDollarValue'>{{arDollarEnd}}</span></div>
                  </div>
                </div>
              </div>


              <div class="col-3 text-center row" style="margin-left: 20px;">
                <div class="col-12 mb-3">RENT MATRIX</div>
                <div id='affiliatesSelection' class='m-r-campaign m-standard mb-3 col-12' style="background: none; border: none; line-height: 25px;">
                  <span class='multiValueSpan'><span id='rentValue'>{{rent}}%</span></span>
                  <span class='multiInputSpan' id='rentDollarValue'>{{dollarRent}}</span>
                </div>
                <div class="col-12 mb-2" style="background: #a52d2e; line-height: 30px;">FULL RANGE</div>
                <div class="col-12 mb-2">
                  <div class="row">
                  <div class='m-r-ir col' [click]='onClickIrBegin' style="line-height: 30px; background: #a52d2e;">
                    <span [class]='frBeginReadWrite'>{{frBegin}}%</span>
                    <input [class]='frBeginReadWrite' type='number'
                          id='editFrBeginValue'
                          [keypress]="frBeginTyped"
                          out="frBegin">
                  </div>
                  <div class='m-r-ir col' [click]='onClickIrEnd' style="line-height: 30px; background: #a52d2e; margin-left: 0.5rem;">
                    <span [class]='frEndReadWrite'>{{frEnd}}%</span>
                    <input [class]='frEndReadWrite' type='number'
                          id='editFrEndValue'
                          [keypress]="frEndTyped"
                          out="frEnd">
                  </div>
                  </div>
                </div>
                <div class="col-12">
                  <div class="row" style="line-height: 30px;">
                  <div class='col' style="border: 1px solid #24a1b0;"><span id='frBeginDollarValue'>{{frDollarBegin}}</span></div>
                  <div class='col' style="border: 1px solid #24a1b0; margin-left: 0.5rem;"><span id='frEndDollarValue'>{{frDollarEnd}}</span></div>
                  </div>
                </div>
              </div>

              <div class="col"></div>
            </div>
          </td>
        </tr>
        <tr>
          <td class='m-notes' colspan='6' style="background: #24a1b0">
            <span>Marketing Lead Source: {{marketingLeadSource}}</span>
          </td>
        </tr>
      </tbody>
    </table>
    `,

    model: function () {
      const self = this;

      self.affiliates = [];

      self.row = {
          id:-1,
          subdomain:"",
          five9CampaignName:"",
          affiliate: "",
          ir:[0,0],
          ar:[0,0],
          fr:[0,0],
          rent:0,
          multiFamily:0,
          investor:false,
          foreclosure:false,
          terms:false,
          csm:"",
          notes:"",
      };

      self.onInit = function () {
        self.marketingLeadSource = new URLSearchParams(window.location.search)
          .get('sd_marketing_source');
        self.irBegin = 0;
        self.irEnd = 0;
        self.arBegin = 0;
        self.arEnd = 0;
        self.frBegin = 0;
        self.frEnd = 0;
        self.rent = 0;
        self.multiFamily = 0;
        self.investor = 0;
        self.foreclosure = 0;
        self.terms = 0;
        self.csm = "";
        self.notes = "";
        self.irDollarBegin = 0;
        self.irDollarEnd = 0;
        self.arDollarBegin = 0;
        self.arDollarEnd = 0;
        self.frDollarBegin = 0;
        self.frDollarEnd = 0;
        self.dollarMultiFamily = "Enter Zestimate";
        self.dollarRent = "Enter Asking Price";
        self.irBeginReadWrite = {read:true,write:false};
        self.irEndReadWrite = {read:true,write:false};
        self.arBeginReadWrite = {read:true,write:false};
        self.arEndReadWrite = {read:true,write:false};
        self.frBeginReadWrite = {read:true,write:false};
        self.frEndReadWrite = {read:true,write:false};
        self.rangesEditing = false;
        self.termsInPercentage = "";

        const matrixUrl = "https://webtools.lamassucrm.com:3000/rs/matrix/list";
        fetch(matrixUrl)
          .then(response => response.json())
          .then(data => {
            const matrixSavedKey = "matrix.data";
            storeLocal(matrixSavedKey, data);
            self.loadAffiliates(data);
          })
          .catch((error) => {
            const matrixSavedKey = "matrix.data";
            readLocal(matrixSavedKey, function(data) {
              const subdomain = subDomainFromWindowLocation();
              self.loadAffiliates(data);
            });
          });
      };

      self.loadAffiliates = function (data) {
        const subdomain = subDomainFromWindowLocation();
        self.affiliates = data.filter(r => r.subdomain===subdomain);
        if (self.affiliates.length===1)
          self.row = self.affiliates[0];
        self.affiliateItems = self.affiliates.map(function (afl) {
          return {
            text: `${afl.subdomain} (${afl.five9CampaignName})`,
            value: afl.id,
            selected: (self.affiliates.length === 1),
          };
        });
        self.update();
      }

      self.zestimateTyped = function (evt) {
        const zestimate = evt.target;
        if (zestimate.value.length===0)
          zestimate.value = "0";
        self.zestimate = parseInt(zestimate.value.replaceAll(",", ""));
        zestimate.value = self.zestimate.toLocaleString("en-US");
        self.update();
      };

      self.askingPriceTyped = function (evt) {
        const askingPrice = evt.target;
        if (askingPrice.value.length===0)
          askingPrice.value = "0";
        self.askingPrice = parseInt(askingPrice.value.replaceAll(",", ""));
        askingPrice.value = self.askingPrice.toLocaleString("en-US");
        self.update();
      };

      self.campaignSelected = function (evt) {
        const index = evt.target.options.selectedIndex;
        self.row = self.affiliates[index];
        self.update();
      };

      self.irBeginTyped = function (evt) {
        calcAfterTyping(evt, () => {
          self.row.ir[0] = parseInt(evt.target.value)/100.;
          self.irBeginReadWrite = toggle(self.irBeginReadWrite);
        });
      };

      self.irEndTyped = function (evt) {
        calcAfterTyping(evt, () => {
          self.row.ir[1] = parseInt(evt.target.value)/100.;
          self.row.ar[0] = (parseInt(evt.target.value)+1)/100.;
          self.irEndReadWrite = toggle(self.irEndReadWrite);
        });
      };

      self.arBeginTyped = function (evt) {
        calcAfterTyping(evt, () => {
          self.row.ar[0] = parseInt(evt.target.value)/100.;
          self.row.ir[1] = (parseInt(evt.target.value)-1)/100.;
          self.arBeginReadWrite = toggle(self.arBeginReadWrite);
        });
      };

      self.arEndTyped = function (evt) {
        calcAfterTyping(evt, () => {
          self.row.ar[1] = parseInt(evt.target.value)/100.;
          self.row.fr[0] = (parseInt(evt.target.value)+1)/100.;
          self.arEndReadWrite = toggle(self.arEndReadWrite);
        });
      };

      self.frBeginTyped = function (evt) {
        calcAfterTyping(evt, () => {
          self.row.fr[0] = parseInt(evt.target.value)/100.;
          self.row.ar[1] = (parseInt(evt.target.value)-1)/100.;
          self.frBeginReadWrite = toggle(self.frBeginReadWrite);
        });
      };

      self.frEndTyped = function (evt) {
        calcAfterTyping(evt, () => {
          self.row.fr[1] = parseInt(evt.target.value)/100.;
          self.frEndReadWrite = toggle(self.frEndReadWrite);
        });
      };

      function calcAfterTyping (evt, calc) {
        if (evt.code==="Enter"||evt.code==="NumpadEnter") {
          evt.preventDefault();
          calc();
          self.update();
        }
      }

      self.preventDefault = function (evt) {
        if (evt.code==="Enter"||evt.code==="NumpadEnter") {
          evt.preventDefault();
        }
      };

      self.preventClickDefault = function (evt) {
        evt.preventDefault();
      }

      self.onClickIrBegin = function (evt) {
        if (!self.rangesEditing) {
          self.irBeginReadWrite = toggle(self.irBeginReadWrite);
          findInput(evt.target).focus();
        }
      };

      self.onClickIrEnd = function (evt) {
        if (!self.rangesEditing) {
          self.irEndReadWrite = toggle(self.irEndReadWrite);
          findInput(evt.target).focus();
        }
      }

      self.onClickArBegin = function (evt) {
        if (!self.rangesEditing) {
          self.arBeginReadWrite = toggle(self.arBeginReadWrite);
          findInput(evt.target).focus();
        }
      };

      self.onClickArEnd = function (evt) {
        if (!self.rangesEditing) {
          self.arEndReadWrite = toggle(self.arEndReadWrite);
          findInput(evt.target).focus();
        }
      }

      self.onClickFrBegin = function (evt) {
        if (!self.rangesEditing) {
          self.frBeginReadWrite = toggle(self.frBeginReadWrite);
          findInput(evt.target).focus();
        }
      };

      self.onClickFrEnd = function (evt) {
        if (!self.rangesEditing) {
          self.frEndReadWrite = toggle(self.frEndReadWrite);
          findInput(evt.target).focus();
        }
      }

      function findInput (target) {
        const input = target.querySelector("input");
        if (!input) 
          return target.nextElementSibling;
        return input;
      }

      function toggle(readWrite) {
        const obj = {
          read: !readWrite.read,
          write: !readWrite.write,
        };
        self.rangesEditing = !self.rangesEditing;
        return obj;
      }

      self.update = function () {
        self.irBegin = typeof self.row.ir==="string" ?
          self.row.ir : Math.round(self.row.ir[0]*100);
        self.irEnd = typeof self.row.ir==="string" ?
          "" : Math.round(self.row.ir[1]*100);
        self.arBegin = typeof self.row.ar==="string" ?
          self.row.ar : Math.round(self.row.ar[0]*100);
        self.arEnd = typeof self.row.ar==="string" ?
          "" : Math.round(self.row.ar[1]*100);
        self.frBegin = typeof self.row.fr==="string" ?
          self.row.fr : Math.round(self.row.fr[0]*100);
        self.frEnd = typeof self.row.fr==="string" ?
          self.row.fr : Math.round(self.row.fr[1]*100);
        self.rent = typeof self.row.rent==="string" ?
          self.row.rent : self.row.rent*100;
        self.multiFamily = typeof self.row.multiFamily==="string" ?
          self.row.multiFamily : `${Math.round(self.row.multiFamily*100)}%`;
        self.investor = self.row.investor ? "YES" : "NO";
        self.foreclosure = self.row.foreclosure ? "YES" : "NO";
        self.terms = self.row.terms ? "YES" : "NO";
        if (self.row.terms===true) {
          self.termsInPercentage = "(IN-RANGE 20%):  " +
            self.toDollar(Math.round(self.askingPrice*0.2));
        } else {
          self.termsInPercentage = "";
        }
        self.csm = self.row.csm;
        self.notes = modifyAsterisks(self.row.notes);
        if (self.zestimate) {
          self.irDollarBegin = typeof self.row.ir==="string" ?
            "" : self.toDollar(Math.round(self.zestimate*self.row.ir[0]));
          self.irDollarEnd = typeof self.row.ir==="string" ?
            "" : self.toDollar(Math.round(self.zestimate*self.row.ir[1]));
          self.arDollarBegin = typeof self.row.ar==="string" ?
            "" : self.toDollar(Math.round(self.zestimate*self.row.ar[0]));
          self.arDollarEnd = typeof self.row.ar==="string" ?
            "" : self.toDollar(Math.round(self.zestimate*self.row.ar[1]));
          self.frDollarBegin = typeof self.row.fr==="string" ?
            "" : self.toDollar(Math.round(self.zestimate*self.row.fr[0]));
          self.frDollarEnd = typeof self.row.fr==="string" ?
            "" : self.toDollar(Math.round(self.zestimate*self.row.fr[1]));
          self.dollarMultiFamily = typeof self.row.multiFamily==="string" ?
            self.row.multiFamily : self.toDollar(Math.round(self.zestimate*self.row.multiFamily));
        }
        if (self.askingPrice)
          self.dollarRent = typeof self.row.rent==="string" ?
            self.row.rent : self.toDollar(Math.round(self.askingPrice*self.row.rent));
          
            document.getElementById('notesValue').innerHTML = self.notes;

            
      };

      self.toDollar = function (value) {
        return '$' + value.toLocaleString("en-US");
      };
    }
  };

  
}

function modifyAsterisks(html) {
  const replacements = [
    { pattern: /\*\*\*\*(.*?)\*\*\*\*/g, style: 'color: red; animation: blinker 0.8s linear infinite;' },
    { pattern: /\*\*\*(.*?)\*\*\*/g, style: 'color: green; animation: blinker 0.8s linear infinite;' },
    { pattern: /\*\*(.*?)\*\*/g, style: 'color: green;' },
    { pattern: /\*(.*?)\*/g, style: 'color: red;' }
  ];

  for (const rep of replacements) {
    html = html.replace(rep.pattern, `<span style="${rep.style}">$1</span>`);
  }

  return html;
}

// Ensure the blinking CSS is added only once
if (!document.querySelector('#blinkerCSS')) {
  const style = `
    @keyframes blinker {  
      50% { opacity: 0; }
    }
  `;
  const styleElement = document.createElement('style');
  styleElement.id = 'blinkerCSS';
  styleElement.textContent = style;
  document.head.appendChild(styleElement);
}
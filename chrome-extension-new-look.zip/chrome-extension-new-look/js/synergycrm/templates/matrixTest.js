"use strict";

const myDiv = document.getElementById("insert-matrix");
const costs = document.getElementById("insert-other-costs");
registerHtmlTemplate(matrixHtml(), myDiv);
registerHtmlTemplate(otherCosts(), costs);
function subDomainFromWindowLocation() {
  return "demo";
}

function storeLocal (key, data, callback) {
}

function readLocal (key, callback) {
}
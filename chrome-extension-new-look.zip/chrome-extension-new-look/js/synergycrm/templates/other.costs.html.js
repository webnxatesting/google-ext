function otherCosts() {
  return { 
    template: `
      <table class='other_costs_table' id='other-costs-table'>
        <thead>
        <tr class='otherCosts'>
          <td  colspan='8'>
            <button class='otherCostsBtn' [click]='onToggleCostBody'>OTHER SELLING COSTS</button>
          </td>
          <td></td>
        </tr>
      </thead>
      <tbody id='otherCostsTbody' [class]='toggleOtherCost'>
        <tr>
          <th colspan='3' class='costs_header_1'>REPAIRS AND CONTRACTORS</th>
          <th colspan='2' class='costs_header_3'>REALTOR COSTS</th>
        </tr>
        <tr>
          <td class='orange2'>Central AC</td>
          <td class='orange2'>
            <input type='number'
                   [change]='centralACChanged'
                   [keyup]='centralACChanged'
                   [keypress]='stopFormSubmit'
                   out='centralACNumber'
                   id='central_ac'
                   step='1'>
          </td>
          <td class='orange2' id='central_ac_result'>{{centralACResultDollar}}</td>
          <td class='empty'>&nbsp;</td>
          <td class='empty'></td>
          <td class='empty'></td>
          <td class='blue2 realtor_comission'>
            Realtor commission
            <input type='number'
                   [change]='realtorComissionChanged'
                   [keyup]='realtorComissionChanged'
                   [keypress]='stopFormSubmit'
                   out='realtorComission'
                   id='realtor_comission'
                   name='realtor_comission'
                   step='1'
                   max='6'> %
          </td>
          <td class='blue2'>{{realtorComissionResultDollar}}</td>
        </tr>
        <tr>
          <td class='orange2'>Bathrooms</td>
          <td class='orange2'>
            <input type='number'
                   [change]='bathroomsChanged'
                   [keyup]='bathroomsChanged'
                   [keypress]='stopFormSubmit'
                   out='bathroomsNumber'
                   id='bathrooms'
                   step='1'>
          </td>
          <td class='orange2' id='bathrooms_result'>{{bathroomsResultDollar}}</td>
          <td class='empty'></td>
          <td class='empty' colspan='2'></td>
          <td class='blue2 staging'>
            Staging and prep work
            <input type='number'
                   [change]='stagingPrepChanged'
                   [keyup]='stagingPrepChanged'
                   [keypress]='stopFormSubmit'
                   out='stagingPrep'
                   id='realtor_staging_prep'
                   name='realtor_staging_prep'
                   step='1'
                   max='6'> %
          </td>
          <td class='blue2'>{{stagingPrepResultDollar}}</td>
        </tr>
        <tr>
          <td class='orange2'>Kitchen</td>
          <td class='orange2'>
            <input type='number'
                   [change]='kitchenChanged'
                   [keyup]='kitchenChanged'
                   [keypress]='stopFormSubmit'
                   out='kitchenNumber'
                   id='kitchen'
                   step='1'>
          </td>
          <td class='orange2' id='kitchen_result'>{{kitchenResultDollar}}</td>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
          <td class='blue1 realtor_deductions'>Total realtor deductions</td>
          <td class='blue1'>{{totalRealtorDeductionsDollar}}</td>
        </tr>
        <tr>
          <td class='orange2'>Flooring</td>
          <td class='orange2'>
            <input type='number' 
                   [change]='flooringChanged'
                   [keyup]='flooringChanged'
                   [keypress]='stopFormSubmit'
                   out='flooringNumber'
                   id='flooring'
                   step='1'><span style="color:red;"> (sqft)</span>
          </td>
          <td class='orange2' id='flooring_result'>{{flooringResultDollar}}</td>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
        </tr>
        <tr>
          <td class='orange2'>Copper Plumbing</td>
          <td class='orange2'>
            <input type='number'
                   [change]='copperChanged'
                   [keyup]='copperChanged'
                   [keypress]='stopFormSubmit'
                   out='copperNumber'
                   id='copper'
                   step='1'><span style="color:red;"> (sqft)</span>
          </td>
          <td class='orange2' id='copper_result'>{{copperResultDollar}}</td>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
          <td class='pink1 taxes_header_1' colspan='2'>TAXES</td>
        </tr>
        <tr>
          <td class='orange2'>Painting</td>
          <td class='orange2'>
            <input type='number'
                   [change]='paintingChanged'
                   [keyup]='paintingChanged'
                   [keypress]='stopFormSubmit'
                   out='paintingNumber'
                   id='painting'
                   step='1'> <span style="color:red;"> (sqft)</span>
          </td>
          <td class='orange2' id='painting_result'>{{paintingResultDollar}}</td>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
          <td class='pink2 escrow'>
            Title Escrow and transfer tax
            <input type='number'
                   [change]='escrowTransferChanged'
                   [keyup]='escrowTransferChanged'
                   [keypress]='stopFormSubmit'
                   out='escrowTransfer'
                   id='escrow_transfer'
                   name='escrow_transfer'
                   step='1'
                   max='3'> %
          </td>
          <td class='pink2'>{{escrowTransferResultDollar}}</td>
        </tr>
        <tr>
          <td class='orange2'>Roofing</td>
          <td class='orange2'>
            <input type='number'
                   [change]='roofingChanged'
                   [keyup]='roofingChanged'
                   [keypress]='stopFormSubmit'
                   out='roofingNumber'
                   id='roofing'
                   step='1'><span style="color:red;"> (sqft)</span>
          </td>
          <td class='orange2' id='roofing_result'>{{roofingResultDollar}}</td>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
          <td class='pink2 seller_concessions'>
            Seller concessions
            <input type='number'
                   [change]='sellerConsessionsChanged'
                   [keyup]='sellerConsessionsChanged'
                   [keypress]='stopFormSubmit'
                   out='sellerConsessions'
                   id='seller_consessions'
                   name='seller_consessions'
                   step='1'
                   max='3'> %
          </td>
          <td class='pink2' id='seller_concessions_result'>{{sellerConsessionsResultDollar}}</td>
        </tr>
        <tr>
          <td class='orange2'>Wood sidings</td>
          <td class='orange2'>
            <input type='number'
                   [change]='woodSidingsChanged'
                   [keyup]='woodSidingsChanged'
                   [keypress]='stopFormSubmit'
                   out='woodSidingsNumber'
                   id='wood_sidings'
                   step='1'><span style="color:red;"> (sqft)</span></td>
          <td class='orange2' id='wood_sidings_result'>{{woodSidingsResultDollar}}</td>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
          <td class='pink1'>TOTAL TAXES DEDUCTIONS</td>
          <td class='pink1' id='total_taxes_deductions_result'>{{totalTaxesDeductionsDollar}}</td>
        </tr>
        <tr>
          <td class='orange2'>Electrical</td>
          <td class='orange2'>
            <input type='number'
                   [change]='electricalChanged'
                   [keyup]='electricalChanged'
                   [keypress]='stopFormSubmit'
                   out='electricalNumber'
                   id='electrical'
                   step='1'><span style="color:red;"> (sqft)</span></td>
          <td class='orange2' id='electrical_result'>{{electricalResultDollar}}</td>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
          <td class='empty'></td>
          <td class='empty'></td>
        </tr>
        <tr>
          <td class='orange3'>TOTAL REPAIRS</td>
          <td colspan='2' class='orange3' id='total_repairs_result'>{{totalRepairsResultDollar}}</td>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
          <td class='costs_header_2' colspan='2' style='color:red;'>TOTAL WITH ALL DEDUCTIONS</td>
          </tr>
        <tr class='otherCostsTR'>
          <th class='orange2'>CONTRACTORS</th>
          <th class='orange2'>
            <input type='number'
                   [change]='contractorsChanged'
                   [keyup]='contractorsChanged'
                   [keypress]='stopFormSubmit'
                   out='contractorsNumber'
                   id='contractors'
                   step='1'></th>
          <th class='orange2' id='contractors_result'>{{contractorsResultDollar}}</th>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
          <td class='costs_header_2' colspan='2'>
            <input type='checkbox'
                   [change]='totalCostOptionsChanged'
                   out='totalRepairsAndContractorsOption'
                   id='totalRepairsAndContractorsOption'
                   name='totalRepairsAndContractorsOption' binary>
            <label for='totalRepairsAndContractorsOption'>REPAIRS AND CONTRACTORS</label> |
            <input type='checkbox'
                   [change]='totalCostOptionsChanged'
                   out='totalRealtorCostsOption'
                   id='totalRealtorCostsOption'
                   name='totalRealtorCostsOption' binary>
            <label for='totalRealtorCostsOption'>REALTOR COSTS</label> |
            <input type='checkbox'
                   [change]='totalCostOptionsChanged'
                   out='totalTaxesOption'
                   id='totalTaxesOption'
                   name='totalTaxesOption' binary>
            <label for='totalTaxesOption'>TAXES</label>
          </td>
        </tr>
        <tr>
          <td  class='orange3'>TOTAL REPAIRS &nbsp; + &nbsp; CONTRACTORS </td>
          <td  colspan='2' class='orange3' id='grand_total_contractors_result'>
            {{grandTotalContractorsResultDollar}}
          </td>
          <td class='empty'></td>
          <td colspan='2' class='empty'></td>
          <td class='redblack' colspan='2' id='total_all_deductions'>{{totalAllDeductions}}</td>
        </tr>
      </tbody>
    </table>
    `,

    dependencies: [
      {
        selector: "#askingPriceInput",
        name: "askingPriceInput",
        event: "keyup",
        callback: "askingPriceChanged"
      },
      {
        selector: "#State",
        name: "stateSelect",
        event: "change",
        callback: "stateChanged"
      },
    ],

    model: function () {
      const self = this;

      self.askingPriceChanged = function (evt) {
        self.askingPrice = getAskingPrice();
        self.updateRealtorCosts();
        self.updateTaxes();
        self.updateTotalWithAllDeductions();
      };

      self.stateChanged = function (evt) {
        self.state = getState();
        readRepairAndContractors();
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      const statesByRegion = {
        pacific: ["AK", "CA", "HI", "OR", "WA"],
        midAtlantic: ["DE", "DC", "MD", "NJ", "NY", "PA"],
        newEngland: ["CT", "ME", "MA", "NH", "RI", "VT"],
        mountain: ["AZ", "CO", "ID", "MT", "NV", "NM", "UT", "WY"],
        eastNorthCentral: ["IL", "IN", "MI", "OH", "WI"],
        westNorthCentral: ["IA", "KS", "MN", "MO", "NE", "ND", "SD"],
        southAtlantic: ["AL", "FL", "GA", "NC", "SC", "VA", "WV"],
        eastSouthCentral: ["KY", "MS", "TN"],
        westSouthCentral: ["AR", "LA", "OK", "TX"]
      };

      const repairAndContractors = {
        centralAC: 0,
        bathrooms: 0,
        kitchen: 0,
        flooring: 0,
        copper: 0,
        painting: 0,
        roofing: 0,
        woodSidings: 0,
        electrical: 0,
      };

      let fetchedRepairAndContractors = [];

      self.onInit = function () {
        self.state = getState();
        self.askingPrice = getAskingPrice();
        self.centralACNumber = 0;
        self.bathroomsNumber = 0;
        self.kitchenNumber = 0;
        self.flooringNumber = 0;
        self.copperNumber = 0;
        self.paintingNumber = 0;
        self.roofingNumber = 0;
        self.woodSidingsNumber = 0;
        self.electricalNumber = 0;
        self.contractorsNumber = 1;
        self.realtorComission = 6;
        self.stagingPrep = 1;
        self.escrowTransfer = 3;
        self.sellerConsessions = 2;
        self.totalRepairsAndContractorsOption = true;
        self.totalRealtorCostsOption = true;
        self.totalTaxesOption = true;
        fetch ("https://webtools.lamassucrm.com:3000/rs/othercosts/list")
          .then(response => response.json())
          .then ((data) => {
            self.toggleOtherCost = {hidden: false};
            fetchedRepairAndContractors = data;
            readRepairAndContractors();
            self.update();
          });
      };

      function getState () {
        return self.stateSelect.value;
      }

      function getAskingPrice () {
        if (self.askingPriceInput.value.trim()==="")
          return 0;
        return parseInt(self.askingPriceInput.value.replaceAll(",", ""));
      }

      function readRepairAndContractors () {
        const selection = Object
          .keys(statesByRegion)
          .filter(key => statesByRegion[key].includes(self.state))
          .reduce((_, current) => current, "");
        const region = selection==="" ? "defaultPrice" : selection;
        for (let key in repairAndContractors)
          repairAndContractors[key] =
            fetchedRepairAndContractors.find(obj => obj.item===key)[region];
      }

      self.centralACChanged = function (evt) {
        self.centralACNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.bathroomsChanged = function (evt) {
        self.bathroomsNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.kitchenChanged = function (evt) {
        self.kitchenNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.flooringChanged = function (evt) {
        self.flooringNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.copperChanged = function (evt) {
        self.copperNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.paintingChanged = function (evt) {
        self.paintingNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.roofingChanged = function (evt) {
        self.roofingNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.woodSidingsChanged = function (evt) {
        self.woodSidingsNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.electricalChanged = function (evt) {
        self.electricalNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.contractorsChanged = function (evt) {
        self.contractorsNumber = parseInt(evt.target.value);
        self.updateRepairAndContractors();
        self.updateTotalWithAllDeductions();
      };

      self.realtorComissionChanged = function (evt) {
        self.realtorComission = parseInt(evt.target.value);
        self.updateRealtorCosts();
        self.updateTotalWithAllDeductions();
      };

      self.stagingPrepChanged = function (evt) {
        self.stagingPrep = parseInt(evt.target.value);
        self.updateRealtorCosts();
        self.updateTotalWithAllDeductions();
      };

      self.escrowTransferChanged = function (evt) {
        self.escrowTransfer = parseInt(evt.target.value);
        self.updateTaxes();
        self.updateTotalWithAllDeductions();
      };

      self.sellerConsessionsChanged = function (evt) {
        self.sellerConsessions = parseInt(evt.target.value);
        self.updateTaxes();
        self.updateTotalWithAllDeductions();
      };

      self.totalCostOptionsChanged = function (evt) {
        self[evt.target.id] = evt.target.checked;
        self.updateTotalWithAllDeductions();
      };

      self.update = function () {
        self.updateRepairAndContractors();
        self.updateRealtorCosts();
        self.updateTaxes();
        self.updateTotalWithAllDeductions();
      };

      self.updateRepairAndContractors = function () {
        self.centralACResult = repairAndContractors.centralAC*self.centralACNumber;
        self.bathroomsResult = repairAndContractors.bathrooms*self.bathroomsNumber;
        self.kitchenResult = repairAndContractors.kitchen*self.kitchenNumber;
        self.flooringResult = repairAndContractors.flooring*self.flooringNumber;
        self.copperResult = repairAndContractors.copper*self.copperNumber;
        self.paintingResult = repairAndContractors.painting*self.paintingNumber;
        self.roofingResult = repairAndContractors.roofing*self.roofingNumber;
        self.woodSidingsResult = repairAndContractors.woodSidings*self.woodSidingsNumber;
        self.electricalResult = repairAndContractors.electrical*self.electricalNumber;
        self.centralACResultDollar = toDollar(self.centralACResult);
        self.bathroomsResultDollar = toDollar(self.bathroomsResult)
        self.kitchenResultDollar = toDollar(self.kitchenResult)
        self.flooringResultDollar = toDollar(self.flooringResult)
        self.copperResultDollar = toDollar(self.copperResult)
        self.paintingResultDollar = toDollar(self.paintingResult)
        self.roofingResultDollar = toDollar(self.roofingResult)
        self.woodSidingsResultDollar = toDollar(self.woodSidingsResult)
        self.electricalResultDollar = toDollar(self.electricalResult)

        self.totalRepairsResult =
            self.centralACResult
          + self.bathroomsResult
          + self.kitchenResult
          + self.flooringResult
          + self.copperResult
          + self.paintingResult
          + self.roofingResult
          + self.woodSidingsResult
          + self.electricalResult;
        self.totalRepairsResultDollar = toDollar(self.totalRepairsResult);

        self.contractorsResult = Math.round(
            self.contractorsNumber
          * self.totalRepairsResult
          * 0.15);
        self.contractorsResultDollar = toDollar(self.contractorsResult);

        self.grandTotalContractorsResult = 
            self.totalRepairsResult
          + self.contractorsResult;
        self.grandTotalContractorsResultDollar = toDollar(self.grandTotalContractorsResult);
      };

      self.updateRealtorCosts = function () {
        self.realtorComissionResult = 
          Math.round(self.askingPrice*self.realtorComission/100.);
        self.realtorComissionResultDollar = toDollar(self.realtorComissionResult);
        self.stagingPrepResult = 
          Math.round(self.askingPrice*self.stagingPrep/100.);
        self.stagingPrepResultDollar = toDollar(self.stagingPrepResult);
        self.totalRealtorDeductions =
            self.realtorComissionResult
          + self.stagingPrepResult;
        self.totalRealtorDeductionsDollar = toDollar(self.totalRealtorDeductions);
      };

      self.updateTaxes = function () {
        self.escrowTransferResult =
          Math.round(self.askingPrice*self.escrowTransfer/100.);
        self.escrowTransferResultDollar = toDollar(self.escrowTransferResult);
        self.sellerConsessionsResult =
          Math.round(self.askingPrice*self.sellerConsessions/100.);
        self.sellerConsessionsResultDollar = toDollar(self.sellerConsessionsResult);
        self.totalTaxesDeductions =
            self.sellerConsessionsResult
          + self.escrowTransferResult;
        self.totalTaxesDeductionsDollar = toDollar(self.totalTaxesDeductions);
      };

      self.updateTotalWithAllDeductions = function () {
        self.totalAllDeductions = 0;
        if (self.totalRepairsAndContractorsOption)
          self.totalAllDeductions += self.grandTotalContractorsResult;
        if (self.totalRealtorCostsOption)
          self.totalAllDeductions += self.totalRealtorDeductions;
        if (self.totalTaxesOption)
          self.totalAllDeductions += self.totalTaxesDeductions;
        self.totalAllDeductions = toDollar(self.totalAllDeductions);
      };

      self.onToggleCostBody = function (evt) {
        self.stopFormSubmitOnClick(evt);
        self.toggleOtherCost = {hidden: !self.toggleOtherCost.hidden};
      };

      self.stopFormSubmit = function (evt) {
        if (evt.code==="Enter"||evt.code==="NumpadEnter") {
          evt.preventDefault();
        }
      };

      self.stopFormSubmitOnClick = function (evt) {
        evt.preventDefault();
      };

      function toDollar (value) {
        return '$' + value.toLocaleString("en-US");
      };
    },
  };
}

//START OF FUNCTION TO Show tooltips on OtherCosts items

function toolTips() {
  let tooltips = {
    ".realtor_comission": "A realtor's commission (~3% to 6% sale price) is the fee charged for their services in helping to sell a home.",
    ".staging": "Staging costs (~1% of sale price). \n Staging and prep work are the costs associated with getting the home ready for sale, such as hiring a professional stager, making repairs, and deep cleaning. \n IF THE PROPERTY IS IN PERFECT CONDITIONS, STAGING COSTS SHOULD BE 0%",
    ".seller_concessions": "Seller concessions (~0% to 2%) \n Seller concessions are extras that the seller agrees to pay for on behalf of the buyer. This could include things like paying for the buyer's home inspection or contributing towards their closing costs. ",
    ".overlap_costs": "Home transition and overlap costs (~1%). \n There’s usually a transition period between selling your current home and moving into a new one. If you’ve already closed on a new place, you might pay ownership costs for two homes simultaneously. That can include both mortgages, utility costs, HOA fees, property taxes and homeowners insurance. If you haven’t closed on the new home or you’re still searching for the right one, you’ll need to budget for temporary living arrangements. ",
    ".escrow": "Title escrow and transfer tax (~3%) \n are the fees charged for transferring the ownership of the home from the seller to the buyer."
  };

  for (let key in tooltips) {
    let elements = document.querySelectorAll(key);
    elements.forEach(element => {
      element.addEventListener('mouseenter', (e) => {
        let tooltip = document.createElement('div');
        tooltip.className = 'tooltip';
        tooltip.innerText = tooltips[key];
        element.appendChild(tooltip);
      });
      element.addEventListener('mouseleave', (e) => {
        element.removeChild(element.lastChild);
      });
    });
  }

}
'use strict';

function registerHtmlTemplate (templateObj, contentNode, rootNode) {
  if (!templateObj["template"])
    throw new Error("No template property found");
  if (!templateObj["model"])
    throw new Error("No model property found");
  if (!rootNode)
    rootNode = document;

  contentNode.innerHTML += templateObj.template;
  contentNode.modelObj = new templateObj.model();
  contentNode.modelObj.observers = {};
  addDependencies(contentNode.modelObj, templateObj.dependencies, rootNode);
  analyzeDomTree(contentNode);
  callOnInit(contentNode.modelObj);
}

function addDependencies(model, dependencies, rootNode) {
  if (dependencies) {
    dependencies.forEach(dep => {
      const element = rootNode.querySelector(dep.selector);
      element.addEventListener(dep.event, model[dep.callback]);
      if (dep.name)
        model[dep.name] = element;
    });
  }
}

function analyzeDomTree (contentNode) {
  const model = contentNode.modelObj;
  traverse(contentNode, nodeIsTextWithKeyExpressionOrElement, (node) => {
    if (node.nodeType===Node.TEXT_NODE) {
      node.curlyBracedText = node.data;
      distinctKeyExpressions(node.data, (_,key) => {
        registerSettersGetters(model, key);
        model.observers[key].push(new TextNodeObserver(node, model));
        replaceKeyExpressions(node, model);
      });

    } else {
      if (nodeIsSelectHavingOptionsAttribute(node)) {
        const key = node.getAttribute("options");
        registerSettersGetters(model, key);
        model.observers[key].push(new SelectObserver(key, node, model));
        replaceSelectOptions(node, model[key]);
      }

      if (node.hasAttribute("out")) {
        const key = node.getAttribute("out");
        registerSettersGetters(model, key);
        model.observers[key].push(new InputObserver(key, node, model));
        node.value = model[key];
      }

      if (node.hasAttribute("[class]")) {
        const key = node.getAttribute("[class]");
        registerSettersGetters(model, key);
        model.observers[key].push(new ClassObserver(key, node, model));
        replaceClasses (node, model[key]);
      }

      [...node.attributes]
        .map(att => att.name)
        .filter(att => isListenerExpression(att) && att!=="[class]")
        .forEach(att => {
          const event = att.slice(1,att.length-1);
          node.addEventListener(event, model[node.getAttribute(att)], false);
        });
    }
  });
}

function nodeIsTextWithKeyExpressionOrElement (node) {
  return node.nodeType===Node.TEXT_NODE && hasCurlyExpressions(node)
      || node.nodeType===Node.ELEMENT_NODE;
}

function registerSettersGetters (modelObj, key) {
  if (modelObj.observers[key]!==undefined) return;
  let boxed = { value: modelObj[key] };
  modelObj.observers[key] = [];
  Object.defineProperty(modelObj, key, {
    set: function (v) {
      boxed.value = v;
      modelObj.observers[key].forEach(o => o.update());
    },
    get: function () { return boxed.value; },
  });
}

function TextNodeObserver (textNode, modelObj) {
  const self = this;
  self.update = function () {
    replaceKeyExpressions(textNode, modelObj);
  };
}

function SelectObserver (key, select, modelObj) {
  const self = this;
  self.update = function () {
    const options = modelObj[key];
    replaceSelectOptions(select, options);
  };
}

function InputObserver (key, input, modelObj) {
  const self = this;
  self.update = function () {
    if (input.hasAttribute("binary") && typeof modelObj[key]==="boolean")
      input.checked = modelObj[key];
    else
      input.value = modelObj[key];
  };
}

function ClassObserver(key, node, model) {
  const self = this;
  self.update = function () {
    replaceClasses (node, model[key]);
  }
}

function replaceKeyExpressions (textNode, model) {
  textNode.data = textNode.curlyBracedText;
  distinctKeyExpressions(textNode.data, (keyExpr, key) => {
    if (model[key]!==undefined)
      textNode.data = textNode.data.replaceAll(keyExpr, model[key]);
  });
}

function replaceSelectOptions (select, newOptions) {
  while (select.options.length > 0) select.remove(0);
  select.selectedIndex = -1;
  if (newOptions) {
    for (let o of newOptions)
      select.add(new Option(o.text, o.value, o.defaultSelected, o.selected));
    const selected = newOptions.filter(o => o.selected || o.defaultSelected);
    if (selected.length===0) {
      select.selectedIndex = -1;
    }
  }
}

function distinctKeyExpressions (text, matcher) {
  const used = [];
  for (let [keyExpr,key] of text.matchAll(keyExpression()))
    if (!used.includes(keyExpr)) {
      matcher(keyExpr, key);
      used.push(keyExpr);
    }
}

function replaceClasses (node, newClasses) {
  for (let token in newClasses)
    node.classList.toggle(token, newClasses[token]);
}

function hasCurlyExpressions (node) {
  const expr = keyExpression();
  return expr.test(node.data);
}

function isListenerExpression (attribute) {
  return attribute.startsWith("[") && attribute.endsWith("]");
}

function nodeIsSelectHavingOptionsAttribute (node) {
  return node.nodeName.toLowerCase() === "select"
    && node.hasAttribute("options");
}

function callOnInit (modelObj) {
  if (modelObj.onInit !== undefined) {
    modelObj.onInit();
  }
}

function traverse (contentNode, matches, apply) {
  const stack = [contentNode];
  while (stack.length > 0) {
    const node = stack[stack.length-1];
    if (matches(node)) apply(node);
    stack.pop();
    if (node.childNodes) {
      const children = [... node.childNodes];
      children.forEach(c => stack.push(c));
    }
  }
}

function keyExpression () {
  return /\{\{([A-Za-z]+[A-Za-z0-9]*)\}\}/g;
}
function validate_form() {
  // Validation for First Name
  if ("" == document.getElementById("fname").value) return alert("First Name Required"), false;

  // Validation for Last Name
  if ("" == document.getElementById("lname").value) return alert("Last Name Required"), false;

  // Generating and Validating Client Name
  document.getElementById("ClientName").value = document.getElementById("fname").value + " " + document.getElementById("lname").value;
  if ("" == document.getElementById("ClientName").value) return alert("ClientName Required"), false;

  // Validation for Home Phone
  if ("" == document.getElementById("HomePhone").value) return alert("Phone 01 Required"), false;

  // Validation for Street Address
  if ("" == document.getElementById("StreetAddress").value) return alert("StreetAddress Required"), false;

  // Validation for City
  if ("" == document.getElementById("City").value) return alert("City Required"), false;

  // Validation for State
  if ("" == document.getElementById("State").options[document.getElementById("State").selectedIndex].value) return alert("State Required"), false;

  // Validation for ZipCode
  if ("" == document.getElementById("ZipCode").value) return alert("ZipCode Required"), false;

  // Validation for Reason/Motive
  if ("" == document.getElementById("reason").value) return alert("Motive/Reason for Selling Required"), false;

  // Validation for Bottom Line Price
  if ("" == document.getElementById("bottom_line").value) return alert("Bottom Line Price US$ Required"), false;

  // Validations for the "QUALIFIED" button index
  if ("QUALIFIED" == buttonIndex) {
    if ("" == document.getElementById("utm_source").options[document.getElementById("utm_source").selectedIndex].value) return alert("LeadSource Required"), false;
    if ("" == document.getElementById("matrix").options[document.getElementById("matrix").selectedIndex].value) return alert("Matrix Required"), false;
    if ("" == document.getElementById("disc_price").options[document.getElementById("disc_price").selectedIndex].value) return alert("Asking Price % Required"), false;
    if ("" == document.getElementById("reason").value) return alert("Motive/Reason for Selling Required"), false;
    if ("" == document.getElementById("mleadsource").value) return alert("Marketing Lead Source Required"), false;
    if ("" == document.getElementById("from_userid").options[document.getElementById("from_userid").selectedIndex].value) return alert("Agent Required"), false;
    if ("" == document.getElementById("manager_approving").options[document.getElementById("manager_approving").selectedIndex].value) return alert("Approving Manager Required"), false;
  }

  // Additional validation for agentNicks dropdown
  // Checking if the selected index is 0


  // Removing colons from the notes and ensuring proper return
  var e = document.getElementById("note").value;
  document.getElementById("note").value = e.replaceAll(":", "");
  return true;
}



let buttonIndex;

// Utility function to create the popup HTML
function createPopupHTML() {
  return `
        <div class="overlay">
            <div class="notes-ai-popup">
                <div class="footer-div">
                    <button class="button-submit-rephrased">Send Lead</button>
                    
                </div>
                <div class="text-area-container">
                    <div class="div-original">
                        <textarea class="text-area-for-original-notes"></textarea>
                    </div>
                    <div class="div-rephrased">
                        <textarea class="text-area-for-rephrased-text"></textarea>
                    </div>
                </div>
                <div class="div-header">
                    <div class="header-original">
                        <div class="original-notes">MY NOTES</div>
                    </div>
                    <div class="header-rephrased">
                        <div class="ai-notes">AI IMPROVED NOTES</div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Utility function to make the OpenAI API call
async function fetchRephrasedNote(noteText) {
  const requestBody = {
    model: 'gpt-4-1106-preview',
    messages: [
      {
        role: 'system',
        content: `You are a real estate agent who spoke with a seller and took notes. You must refine the given notes without augmenting or removing information or without giving a final conclusion, nor "Call to Action" nor "Closing statement". Please:

        - Structure content with logical categories.
        - Improve grammar and phrasing for clarity, just replace abbreviations with the full form.
        - Use bullet points for clear presentation. 
        - Don't use words like "Charming" or decorated words because is not the language of the original noted writer.
        - Present the information as final, ready-to-use text for a listing.
        - Do not include any instructions or meta-comments in the response.
        - In case part of the notes talk about "propstream": These phrases should be integrated as they are, retaining their exact wording and sense and don't add extra wording to the 'propstream' part.
        - In case part of the notes talk about "matrix" , that part MUST be integrated as they are, retaining their exact wording. Example "Matrix approval terms" or "matrix" is a note, it should be in the exact form and context as it is in the original notes. Avoid repeating or rephrasing it in different parts of the response if the same is not done as well in original notes.
        - Present the information as a polished, ready-to-use text for a property listing without any instructional or meta-comments.
        - Avoid repeating information already noted, for example, conclusions are not needed, only focus on presenting the details in a concise, professional format. Final "Call to Actions" and "Closing statement" must be avoided.

        - Notes are:`
      },
      {
        role: 'user',
        content: `Notes: "${noteText}"`
      }
    ]
  };

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': 'Bearer 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',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(requestBody)
  });

  if (!response.ok) {
    console.error('API request error with status:', response.status);
    throw new Error('API request failed');
  }

  const responseData = await response.json();
  return responseData.choices[0].message.content;
}


const fieldsToExclude = [
  'closer_sch', 
  'closer_min', 
  'z_link', 
  'z_estimate', 
  'aiNotesToggleCheckbox', 
  'totalRepairsAndContractorsOption', 
  'totalRealtorCostsOption', 
  'totalTaxesOption'
];

function disableExcludedFields() {
  fieldsToExclude.forEach(fieldId => {
    const field = document.getElementById(fieldId);
    if (field) {
      field.disabled = true;
    }
  });
}





// Event listener for the "Send Lead" button click
function onSendLeadClick() {
  // Disable fields that should not be sent
  disableExcludedFields();

  // Get the rephrased note value
  let rephrasedNoteValue = document.querySelector('.text-area-for-rephrased-text').value;
  rephrasedNoteValue = rephrasedNoteValue.replaceAll(":", "-");

  // Get the original note value
  const originalNoteValue = document.querySelector('.text-area-for-original-notes').value.trim();

  // If the rephrased note is empty or contains only spaces, use the original note value
  const noteToSend = rephrasedNoteValue === '' ? originalNoteValue : rephrasedNoteValue;

  document.getElementById('note').value = noteToSend;

  togglePageScroll(); // Enable page scroll when the popup is closed
  document.forms["main"].submit();
}




function togglePageScroll() {
  document.body.style.overflow = document.body.style.overflow === 'hidden' ? '' : 'hidden';
}


function preventPageScrollOnTextArea(event) {
  const textarea = event.target;
  if ((textarea.scrollTop === 0 && event.deltaY < 0) ||
    (textarea.scrollHeight - textarea.clientHeight === textarea.scrollTop && event.deltaY > 0)) {
    event.preventDefault();
    event.stopPropagation();
  }
}


//notesAI.js

// Function to handle the QUALIFIED button click
async function handleQualifiedButtonClick(event) {
  buttonIndex = 'QUALIFIED';

   // Disable fields that should not be sent
   disableExcludedFields();

  let isFormValid;
  let isCheckboxChecked;
  try {
    isFormValid = validate_form(); // Check form validation
    isCheckboxChecked = aiNotesToggleCheckbox.checked; // Check checkbox state
  } catch (error) {
    console.error("Error validating form or checking checkbox:", error);
  }

  let noteText;
  let isLotSizeIncluded;
  try {
    noteText = document.getElementById('note').value; // Fetch the note text
    isLotSizeIncluded = noteText.includes("LOT SIZE"); // Check if it includes "LOT SIZE"
    isDwellingIncluded = /dwellings?/i.test(noteText); 
  } catch (error) {
    console.error("Error fetching note or checking for LOT SIZE:", error);
  }

  if (!isFormValid) {
    event.preventDefault();
    return;
  }

  if (isCheckboxChecked && !isDwellingIncluded) {
    event.preventDefault();
    buttonIndex = 'QUALIFIED';

    const isFormValid = validate_form();
    if (!isFormValid) return;

    const popupHTML = createPopupHTML();
    document.body.insertAdjacentHTML('beforeend', popupHTML);

    togglePageScroll();

    // Add event listeners to the text areas to prevent the default scroll behavior of the underlying page
    document.querySelector('.text-area-for-original-notes').addEventListener('wheel', preventPageScrollOnTextArea);
    document.querySelector('.text-area-for-rephrased-text').addEventListener('wheel', preventPageScrollOnTextArea);

    const notesElement = document.querySelector('.ai-notes');
    notesElement.innerHTML = '<span style="color:white">IMPROVING NOTES, WAIT<span class="dot dot1">.</span><span class="dot dot2">.</span><span class="dot dot3">.</span></span>';

    const noteText = document.getElementById('note').value;
    document.querySelector('.text-area-for-original-notes').value = noteText;

    document.querySelector('.original-notes').addEventListener('dblclick', function () {
      const rephrasedTextArea = document.querySelector('.text-area-for-rephrased-text');
      const originalTextArea = document.querySelector('.text-area-for-original-notes');

      rephrasedTextArea.value = '';
      notesElement.innerHTML = '<div style="color:red" class="ai-notes">REMOVED AI NOTES</div>';

     
    });

    notesElement.style.cursor = 'pointer';

    try {
      const rephrasedNote = await fetchRephrasedNote(noteText);
      document.querySelector('.text-area-for-rephrased-text').value = rephrasedNote;
      prependNicknameToRephrasedText(document.querySelector('.text-area-for-rephrased-text'));
      notesElement.innerText = 'AI IMPROVED NOTES';
    } catch (error) {
      console.error('Error fetching or processing the rephrased note:', error);
      notesElement.innerText = 'CONNECT ERROR - SEND ORIGINAL';
    }

    document.querySelector('.button-submit-rephrased').addEventListener('click', onSendLeadClick);
  }
  // If checkbox is unchecked, the function will exit without calling preventDefault, 
  // so the webform will be submitted as usual.
}

// Creating AI Notes toggle
const aiNotesToggleDiv = document.createElement('div');
aiNotesToggleDiv.style.textAlign = 'center';

const aiNotesLabel = document.createElement('label');
aiNotesLabel.htmlFor = 'aiNotesToggleCheckbox';
aiNotesLabel.style.marginRight = '10px';

const aiNotesLabelSpan = document.createElement('span');
aiNotesLabelSpan.className = 'checkboxLabelAINotes';
aiNotesLabelSpan.style.color = 'white';
aiNotesLabelSpan.style.fontWeight = '500';
aiNotesLabelSpan.innerText = '🤖 AI NOTES';

aiNotesLabel.appendChild(aiNotesLabelSpan);

const aiNotesToggleCheckbox = document.createElement('input');
aiNotesToggleCheckbox.type = 'checkbox';
aiNotesToggleCheckbox.id = 'aiNotesToggleCheckbox';
aiNotesToggleCheckbox.name = 'aiNotesToggleCheckbox';

aiNotesToggleDiv.appendChild(aiNotesLabel);
aiNotesToggleDiv.appendChild(aiNotesToggleCheckbox);

const targetFormDiv = document.querySelector('body > form > div');
targetFormDiv.parentNode.insertBefore(aiNotesToggleDiv, targetFormDiv);

chrome.storage.sync.get(['aiNotesToggleState'], function (result) {
  aiNotesToggleCheckbox.checked = result.aiNotesToggleState ?? true;

  document.querySelector('input[name="QUALIFIED"]').addEventListener('click', handleQualifiedButtonClick);
});






///////////////////////////////////////
// Event listener for checkbox state change
aiNotesToggleCheckbox.addEventListener('change', function () {
  const isCheckboxChecked = this.checked;

  // Log the checkbox state
  console.log('Checkbox state changed:', isCheckboxChecked);

  // Save the checkbox state to chrome.storage.sync
  try {
    chrome.storage.sync.set({ 'aiNotesToggleState': isCheckboxChecked }, function() {
      if(chrome.runtime.lastError) {
        console.error('Error setting value in Chrome storage:', chrome.runtime.lastError);
      } else {
        console.log('aiNotesToggleState saved successfully:', isCheckboxChecked);
      }
    });
  } catch (error) {
    console.error('Error accessing or modifying Chrome storage:', error);
  }

  const qualifiedButton = document.querySelector('input[name="QUALIFIED"]');

  if (isCheckboxChecked) {
    qualifiedButton.addEventListener('click', handleQualifiedButtonClick);
  } else {
    qualifiedButton.removeEventListener('click', handleQualifiedButtonClick);
  }
});

chrome.storage.sync.get(['aiNotesToggleState'], function (result) {
  if (chrome.runtime.lastError) {
    console.error('Error getting value from Chrome storage:', chrome.runtime.lastError);
    return;
  }

  console.log('aiNotesToggleState from Chrome storage:', result.aiNotesToggleState);

  aiNotesToggleCheckbox.checked = result.aiNotesToggleState ?? true;
  
  document.querySelector('input[name="QUALIFIED"]').addEventListener('click', handleQualifiedButtonClick);
});


///////

//Create floating icons on DOM
var img = document.createElement("img");
img.src = chrome.runtime.getURL("img/realtorsIcon.png");
img.id = "realtorIcon";
document.body.appendChild(img);

var img = document.createElement("img");
img.src = chrome.runtime.getURL("img/lamassuSuperCharge.png");
img.id = "lamassuSuperCharge";
document.body.appendChild(img);

var realtorUrl = window.location.href;


const params = new URLSearchParams(window.location.search);
const old_asking_price = params.get('old_asking_price');
const reason_for_selling = params.get('reason_for_selling');
console.log(old_asking_price);
console.log(reason_for_selling);




var sd_marketing_source = realtorUrl
  .split("sd_marketing_source=")[1].split("&")[0];
//console.log(sd_marketing_source);

//regex
if (sd_marketing_source.match(/LAM_SC/)) {
  //set display none to element with id lamassuSuperCharge
  var lamassuSuperCharge = document.getElementById("lamassuSuperCharge");
  lamassuSuperCharge.style.display = "block";


  //Insert Super Charge information
 const superChargeHTML = `
 <td colspan="4" bgcolor="#F7F7F7" style="color:green;font-size:20px;"><b> ♻️ THIS IS A LAMASSU SUPER CHARGED LEAD!!! ♻️</b>
 <span style="font-size:18px">
 <b><p>Previous asking price was: <span style="color:black">${old_asking_price} </span></p></b>
 <b><p>Previous reason for selling is: <span style="color:black">${reason_for_selling}</span></b></p></td>
</span>
 </td>'
 `

  setTimeout(function() {

    var superChargeTR = document.createElement("tr");
    superChargeTR.setAttribute("align", "left");
    superChargeTR.setAttribute("colspan", "4");
    superChargeTR.innerHTML = superChargeHTML 
    
    var tableBody = document.querySelector("#Table_2 > tbody");
    tableBody.insertBefore(superChargeTR, tableBody.firstChild);

  }, 1000);

}


//Hide or show Eligible Realtor icon if zipcode matches
const realtorZipcodes = [];

fetch("https://webtools.lamassucrm.com:3000/rs/realtorzips/list")
  .then((response) => response.json())
  .then((data) => {
    for (let i = 0; i < data.length; i++) {
      if (typeof data[i].zipCode === 'number') {
        data[i].zipCode = data[i].zipCode.toString();
      }
      if (data[i].zipCode.length === 4) {
        data[i].zipCode = "0" + data[i].zipCode;
      }
      realtorZipcodes.push(data[i].zipCode);
    }

    realtorZipcodes.forEach(function (zipcode) {
        //console.log(zipcode);
      });


      var ZipCodeRealtor;
setInterval(function(){
        ZipCodeRealtor = document.getElementById('ZipCode').value;
        if(ZipCodeRealtor.length == 4){
          ZipCodeRealtor = "0" + ZipCodeRealtor;
        }
        console.log(ZipCodeRealtor);

        if(realtorZipcodes.includes(ZipCodeRealtor)){
            document.getElementById('realtorIcon').style.display = 'block';
          }
          else {
            document.getElementById('realtorIcon').style.display = 'none';
          }

    }, 700);


});







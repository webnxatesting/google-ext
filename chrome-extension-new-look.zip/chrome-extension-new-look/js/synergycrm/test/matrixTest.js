"use strict";

const myDiv = document.getElementById("insert-matrix");
myDiv.innerHTML = matrixHTML();

function subDomainFromWindowLocation() {
  return "demo";
}

insertMatrixRows(
  [
    {
      id:1,
      subdomain:"demo",
      five9CampaignName:"ABC_OUTPUT",
      affiliate: "ADUA",
      ir:[0.4,0.7],
      ar:[0.71,0.86],
      fr:[0.87,1.05],
      rent:0.0125,
      multiFamily:0.8,
      investor:true,
      foreclosure:true,
      csm:"LONDON",
      notes:"Be AWARE!!!",
    },
    {
      id:2,
      subdomain:"demo",
      five9CampaignName:"DEF_OUTPUT",
      affiliate: "ADUA",
      ir:[0.3,0.6],
      ar:[0.61,0.76],
      fr:[0.77,1.05],
      rent:0.0125,
      multiFamily:0.8,
      investor:false,
      foreclosure:false,
      csm:"NELSON",
      notes:"Be AWARE!!!",
    },
  ]
);
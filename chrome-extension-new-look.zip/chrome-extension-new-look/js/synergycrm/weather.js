/////////////////////////////Weather

// Assuming stateToTimeZone is accessible here
const stateToTimeZone = { 'AL': 'America/Chicago', 'AK': 'America/Anchorage', 'AZ': 'America/Phoenix', 'AR': 'America/Chicago', 'CA': 'America/Los_Angeles', 'CO': 'America/Denver', 'CT': 'America/New_York', 'DE': 'America/New_York', 'FL': 'America/New_York', 'GA': 'America/New_York', 'HI': 'Pacific/Honolulu', 'ID': 'America/Boise', 'IL': 'America/Chicago', 'IN': 'America/Indiana/Indianapolis', 'IA': 'America/Chicago', 'KS': 'America/Chicago', 'KY': 'America/New_York', 'LA': 'America/Chicago', 'ME': 'America/New_York', 'MD': 'America/New_York', 'MA': 'America/New_York', 'MI': 'America/Detroit', 'MN': 'America/Chicago', 'MS': 'America/Chicago', 'MO': 'America/Chicago', 'MT': 'America/Denver', 'NE': 'America/Chicago', 'NV': 'America/Los_Angeles', 'NH': 'America/New_York', 'NJ': 'America/New_York', 'NM': 'America/Denver', 'NY': 'America/New_York', 'NC': 'America/New_York', 'ND': 'America/Chicago', 'OH': 'America/New_York', 'OK': 'America/Chicago', 'OR': 'America/Los_Angeles', 'PA': 'America/New_York', 'RI': 'America/New_York', 'SC': 'America/New_York', 'SD': 'America/Chicago', 'TN': 'America/Chicago', 'TX': 'America/Chicago', 'UT': 'America/Denver', 'VT': 'America/New_York', 'VA': 'America/New_York', 'WA': 'America/Los_Angeles', 'WV': 'America/New_York', 'WI': 'America/Chicago', 'WY': 'America/Denver' };


async function fetchWeatherData() {
    const params = new URLSearchParams(window.location.search);
    let zip = params.get('zip');

    if (!zip) {
        console.error("ZIP code not found in the URL");
        return;
    }

    if (zip.length < 5) {
        zip = '0' + zip;
    }

    // Construct the complete server API URL
    const serverApiUrl = `https://webtools.lamassucrm.com:3002/weather?zip=${zip}`;

    try {
        const response = await fetch(serverApiUrl);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log("Fetched Weather Data:", data);
        updateWeatherToDOM(data, state);

        // Schedule the next update after 20 minutes
        setTimeout(fetchWeatherData, 20 * 60 * 1000);

    } catch (error) {
        console.error("Error fetching weather data:", error);
    }
}

async function updateWeatherToDOM(data, state) {
    if (!data || !data.location || !data.current) {
        console.error("Invalid weather data");
        return;
    }

    const displayTimeZone = stateToTimeZone[state];

    if (!displayTimeZone) {
        console.error(`Time zone for state ${state} not found.`);
        return; // Early return if time zone is not found
    }



    let weatherToDOM = `
      <div id="zipWeather" style="position: fixed; top: 18px; left: 50%; transform: translateX(-50%); width: 100%; z-index: 500; font-family: Arial, sans-serif; text-align: center; background-color: #4B4B4B; padding: 10px; border-radius: 8px;">
          <span style="color: white; font-size: 18px;"><strong>Weather in ${data.location.name}:</strong></span>
          <span style="margin-left: 10px; font-size: 16px;">Temperature: ${data.current.temp_c}°C / ${data.current.temp_f}°F</span>
          <span style="margin-left: 10px; font-size: 16px;">Condition: ${data.current.condition.text}</span>
          <img src="https:${data.current.condition.icon}" alt="${data.current.condition.text}" style="height: 50px; width: 50px; vertical-align: middle; margin-left: 10px;">
      </div>
      <div id="timeZoneBar" style="position: fixed; top: 65px; left: 50%; transform: translateX(-50%); font-weight:bold; width: 100%; z-index: 550; color: white; font-family: Arial, sans-serif; text-align: center;"></div>
    `;

    document.body.insertAdjacentHTML("afterbegin", weatherToDOM);

    // Initial display
    updateLocalTime();


    // Function to update the local time display
    function updateLocalTime() {
        const options = { hour: '2-digit', minute: '2-digit', hour12: true };
        const displayLocalTime = new Intl.DateTimeFormat('en-US', { timeZone: displayTimeZone, ...options }).format(new Date());

        // Selects the existing time zone bar for efficient updates
        const timeZoneBar = document.getElementById('timeZoneBar');
        if (timeZoneBar) { // Check if timeZoneBar exists
            timeZoneBar.textContent = `Seller's Local Time: ${displayLocalTime}`;
        }
    }

    // Update every 50 seconds 
    setInterval(updateLocalTime, 50000);
}



setTimeout(() => {
    fetchWeatherData();
}, 1000);


///////////////////End of Weather
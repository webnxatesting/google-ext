"use strict";

/*COPY TO CLIPBOARD: Zestimate Price */
let urlZillowPattern = new RegExp("https://.*\\.zillow\\.com/?.*");
let zillowTopInfoBox_css = document.querySelector(".Spacer-c11n-8-82-3__sc-17suqs2-0.dwRHUV"); //This is the place at the top where Redfin, Realtor and other info are located.

let zillowTopInfoBox_xpath = document.evaluate("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[2]/div/div[1]", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;


if (urlZillowPattern.test(window.location.href)) {
//FIX for v2.4.3: I changed the use of CSS selector to use xPath, because Zillow.com was often changing css selectors names and breaking the functions.
//element_ is the old way. If we need to use element_ instead of element, we need to change element to element_[0] in certains parts of the code

//Zestimate price selector
let element = document.evaluate("/html/body/div[1]/div/div[2]/div/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[2]/div/div[1]/span/span[2]/span", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                                 

console.log(element); //is the final element
  function copyAlert(zestimateElement) {
    let oldText = zestimateElement.innerText;
    zestimateElement.innerText = "Copied!";
    zestimateElement.classList.add("animate");
    zestimateElement.addEventListener('animationend', () => {
      zestimateElement.classList.remove("animate");
      zestimateElement.innerText = oldText;
      setTimeout(() => {
        zestimateElement.innerText = oldText;
      }, 1000);
    });
  }

  
  function copyClick() {
    if (!element.classList.contains("animate")) { //if (!element_[0].classList.contains("animate")) {
      let zestimate = element.innerText; //let zestimate = element_[0].innerText;
      let zestimate_final = zestimate.slice(1, zestimate.length);
      navigator.clipboard.writeText(zestimate_final).then(() => copyAlert(element)); //copyAlert(element_[0]));
    }
  }

  if (element) {
  element.addEventListener('click', copyClick);
} //element_[0].addEventListener('click', copyClick);
  /*GET: Zillow Address */

  /* Create and append images */

  var imgcontainer = document.createElement('div');
  imgcontainer.id = 'imgcontainer';
  /*Search icon */

  var img1 = document.createElement("img");
  img1.src = chrome.runtime.getURL("img/search_icon_small.png");
  img1.id = "search-icon";
  img1.className = "search-img";
  imgcontainer.appendChild(img1);
  /* Redfin Image and Link*/

  
  //removed realtor button. QA Department asked it.
  /*Realtor Image and Link */
  var img3 = document.createElement("img");
  img3.src = chrome.runtime.getURL("img/google1x.png");
  img3.className = "search-img";
  img3.id = "search-img-google";
  imgcontainer.appendChild(img3);
  /*Insert imgcontainer on DOM */
  
  var img2 = document.createElement("img");
  img2.src = chrome.runtime.getURL("img/redfin1x.png");
  img2.id = "search-img-redfin";
  img2.className = "search-img";
  imgcontainer.appendChild(img2);


// Check if the zillowTopInfoBox_xpath element exists

if (zillowTopInfoBox_xpath) {
    zillowTopInfoBox_xpath.appendChild(imgcontainer);

    // Create a MutationObserver
    let observer = new MutationObserver(function(mutations) {
        // Check if the imgcontainer element has been removed
        let imgcontainerExists = document.querySelector("#imgcontainer");
        if (!imgcontainerExists) {
            zillowTopInfoBox_xpath.appendChild(imgcontainer);
        }
    });

    // Observe changes to the DOM
    observer.observe(document.body, {childList: true, subtree: true});
}

  function redfinLink() {
    let address = decomposeAddress();
  
    if (!address) {
      console.error("Address not found or decomposed incorrectly!");
      return;
    }
  
    navigator.clipboard.writeText(address.full).then(() => {
      window.open("https://www.google.com/search?q=" + zillowAddressText + " redfin.com", "_blank");
      setTimeout(() => {
        window.open("https://www.redfin.com", "_blank");
      }, 200);
    });
  }

  function googleSearchLink() {
    let address = decomposeAddress();
    navigator.clipboard.writeText(address.full).then(() => {
      window.open("https://www.google.com/search?q=" +  zillowAddressText + " site:zillow.com", "_blank");
       
    });
  }




// Add event listener to Redfin image if it exists
let redfinImg = document.getElementById("search-img-redfin");
if (redfinImg) {
  redfinImg.addEventListener('click', redfinLink);
} else {
  console.error("Redfin image element not found!");
}

// Add event listener to Google Search image if it exists
let googleSearchImg = document.getElementById("search-img-google");
if (googleSearchImg) {
  googleSearchImg.addEventListener('click', googleSearchLink);
} else {
  console.error("Google Search image element not found!");
}

// Retrieve Zillow address text if the element exists
let zillowAddressElement = document.querySelector('.summary-container h1');
let zillowAddressText = zillowAddressElement ? zillowAddressElement.innerText : null;

function decomposeAddress() {
  if (!zillowAddressText) return null;

  let streetNumberFirstSliced = zillowAddressText.slice(0, zillowAddressText.indexOf(","));
  let streetNumberLastSliced = zillowAddressText.slice(zillowAddressText.indexOf(",") + 1, zillowAddressText.length).trim();
  
  return {
    full: zillowAddressText,
    first: streetNumberFirstSliced,
    last: streetNumberLastSliced
  };
}




  

// Find the .summary-container element first
let summaryContainer = document.querySelector(".summary-container");

// Find the h1 element within that container
let zillowAddressH1 = summaryContainer ? summaryContainer.querySelector("h1") : null;

// Define a function called copyAlertZillowAddress that accepts zillowAddressH1 as a parameter
function copyAlertZillowAddress(zillowAddressH1) {
  // Save the original text content of zillowAddressH1 into a variable called oldText
  let oldText = zillowAddressH1.textContent;

  // Change the text content of zillowAddressH1 to "Zillow Address Copied!"
  zillowAddressH1.textContent = "Zillow Address Copied!";

  // Add a CSS class called animate to zillowAddressH1
  zillowAddressH1.classList.add("animate");

  // Change the color of the text to red
  zillowAddressH1.style.color = "red";

  // Add an event listener that listens for the animationend event
  zillowAddressH1.addEventListener("animationend", function() {
    // Remove the animate class from zillowAddressH1
    zillowAddressH1.classList.remove("animate");

    // Restore the original text content
    zillowAddressH1.textContent = oldText;

    // Set the text color back to black
    zillowAddressH1.style.color = "black";
  });
}

// Add a click event listener to zillowAddressH1
if (zillowAddressH1) { // Make sure the element exists before adding an event listener
  zillowAddressH1.addEventListener("click", function() {
    // Copy the Zillow address to the clipboard
    navigator.clipboard.writeText(zillowAddressH1.textContent).then(function() {
      // If successful, log "copied" to the console
      console.log("copied");

      // Call the copyAlertZillowAddress function
      copyAlertZillowAddress(zillowAddressH1);
    }).catch(function() {
      // If failed, log "failed" to the console
      console.log("failed");
    });
  });
} else {
  console.log("Element not found");
}


}

/////////////////////Replacing Zillow Logos for Lamassu Logos
if (window.location.href.includes('zillow.com')) {
  function createNewImage(src, width = 'auto', height = 'auto') {
      const img = document.createElement('img');
      img.src = chrome.runtime.getURL(src);
      img.style.width = width;
      img.style.height = height;
      img.style.visibility = 'hidden';
      img.onload = () => { img.style.visibility = 'visible'; };
      return img;
  }

  function replaceLogos() {
      // Handle z-logo-default.svg or svg with ds-zillow-logo
      document.querySelectorAll('img[src*="z-logo-default.svg"], svg[data-testid="ds-zillow-logo"]').forEach(logo => {
          if (!logo.classList.contains('replaced-logo')) {
              logo.style.display = 'none'; // Hide the original logo
              logo.classList.add('replaced-logo');

              const newLogo = createNewImage("img/lamassucrm/lamassu_logo.png");
              newLogo.classList.add('custom-logo');
              logo.parentNode.insertBefore(newLogo, logo.nextSibling);
          }
      });

      // Handle z-logo-white.svg
      document.querySelectorAll('img[src*="z-logo-white.svg"]').forEach(logo => {
          if (!logo.classList.contains('replaced-logo')) {
              logo.style.display = 'none'; // Hide the original logo
              logo.classList.add('replaced-logo');

              const newLogo = createNewImage("img/lamassucrm/lamassu_logo-white.png");
              newLogo.classList.add('custom-logo');
              logo.parentNode.insertBefore(newLogo, logo.nextSibling);
          }
      });
  }

  const zillowLogoObserver = new MutationObserver(mutations => {
      let shouldReplace = false;
      mutations.forEach(mutation => {
          if (mutation.addedNodes.length || mutation.type === 'attributes') {
              shouldReplace = true;
          }
      });
      if (shouldReplace) {
          replaceLogos();
      }
  });

  zillowLogoObserver.observe(document.body, { childList: true, subtree: true, attributes: true });

  replaceLogos();

  setInterval(replaceLogos, 3000); // Reapply changes periodically
}



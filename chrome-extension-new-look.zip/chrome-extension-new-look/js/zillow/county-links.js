//"Est. refi" payment block
// html > body > div:first-of-type > div:nth-of-type(6) > div:first-of-type > div:first-of-type > div > div > div:first-of-type > div > div > div:first-of-type > div:nth-of-type(2) > div:nth-of-type(2) > div:nth-of-type(2) > div > div:first-of-type > div:nth-of-type(3)
/*
 step 0: Using javascript document.evaluate save the result for the xpathSelector = '/html/body/div[1]/div[6]/div[1]/div[1]/div/div/div[1]/div/div/div[1]/div[2]/div[2]/div[2]/div/div[1]/div[2]/h1';
 
 then, please create a js function named countyBlock that when the page loads, do the following:
 step 1: if the node with class .countyLink exists on the DOM, fetches the json: https://webtools.lamassucrm.com:3000/rs/counties/list. The json example of this API is:
 [{"us_state": "FL", "county": "Columbia", "COUNTY_ID": 12023, "link": "http://columbia.floridapa.com/gis/", "search_by": "ADDRESS"},{"us_state": "FL", "county": "Hillsborough", "COUNTY_ID": 12057, "link": "https://gis.hcpafl.org/PropertySearch/#/nav/Basic%20Search", "search_by": "ADDRESS"}]

 step 2: parse the parameter COUNTY_ID of the link of countyLink, For example, if the countyLink is:
 <a class="countyLink" href="https://www.zillow.com/CountyAssessorPage.htm?COUNTY_ID=12023&amp;FORCE_GENERIC=false&amp;LINK_LOCATION=TaxHistory&amp;PARCEL_NUM=03604527" target="_blank" rel="nofollow">county website</a> parsedCOUNTY_ID = 12023

 step 2.1: Compare if the COUNTY_ID exists on the fetched json, if it exists, then:
 step 2.2: create a new link with the link value of the fetched json having inside a div with id countyLinkBlock. 
 step 2.3: Also, inside this countyLinkBlock div, create a text with label "SEARCH BY: " and in front of it, the corresponding value of "search_by" from the json. Example. "SEARCH BY: ADDRESS"
 step 2.4: Place this new countyLinkBlock div before the node of the xpathSelector of step 0.



For example, if the countyLink is:
<a class="countyLink" href="https://www.zillow.com/CountyAssessorPage.htm?COUNTY_ID=22033&amp;FORCE_GENERIC=false&amp;LINK_LOCATION=TaxHistory&amp;PARCEL_NUM=03604527" target="_blank" rel="nofollow">county website</a>
*/
// Step 0: XPath selector
const xpathSelector = "/html/body/div[1]/div[6]/div[1]/div[1]/div/div/div[1]/div/div/div[1]/div[2]/div[2]/div[2]/div/div[1]/div[3]";

function countyBlock() {
    const countyLinkNode = document.querySelector(".countyLink");
    if (countyLinkNode) {
      fetch("https://webtools.lamassucrm.com:3000/rs/counties/list")
        .then(response => response.json())
        .then(data => {
          const countyId = parseCountyId(countyLinkNode.href);
          const parcelNum = parseParcelNum(countyLinkNode.href);
          const countyData = data.find(item => item.COUNTY_ID === countyId);
  
          if (countyData) {
            const newLink = document.createElement("a");
            newLink.href = getNewLink(countyData, parcelNum, countyLinkNode.href);
            newLink.target = "_blank";
            newLink.rel = "nofollow";
            newLink.textContent = "County Website ";
            newLink.onclick = function(event) {
              event.preventDefault();
              handleCopyToClipboard(countyData, parcelNum)
                .then(() => {
                  window.open(newLink.href, '_blank');
                });
            };
  
            const searchByLabel = document.createElement("span");
            searchByLabel.textContent = `| SEARCH BY: ${countyData.search_by}`;
  
            const countyLinkBlock = document.createElement("div");
            countyLinkBlock.id = "countyLinkBlock";
            countyLinkBlock.appendChild(newLink);
            countyLinkBlock.appendChild(searchByLabel);

            if (countyData.comment) {
                const commentLabel = document.createElement("span");
                commentLabel.textContent = `| Instruction: ${countyData.comment}`;
                countyLinkBlock.appendChild(commentLabel);
              }
  
            const xpathResult = document.evaluate(xpathSelector, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null);
            const targetNode = xpathResult.singleNodeValue;
            targetNode.parentNode.insertBefore(countyLinkBlock, targetNode);
          }
        })
        .catch(error => {
          console.error("Error fetching county data:", error);
        });
    }
  }
  
  async function handleCopyToClipboard(countyData, parcelNum) {
    switch (countyData.search_by) {
      case "ADDRESS":
        const xpathZillowAddress = '/html/body/div[1]/div[6]/div[1]/div[1]/div/div/div[1]/div/div/div[1]/div[2]/div[2]/div[2]/div/div[1]/div[2]/h1';
        const zillowAddress = document.evaluate(xpathZillowAddress, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.innerText;
        const partialAddress = zillowAddress.split(",")[0].trim();
        await navigator.clipboard.writeText(partialAddress);
        break;
  
      case "PARCEL NUMBER":
        if (parcelNum) {
          await navigator.clipboard.writeText(parcelNum);
        }
        break;
  
      default:
        break;
    }
  }

// Utility function to parse COUNTY_ID from countyLink
function parseCountyId(link) {
  const regex = /COUNTY_ID=(\d+)/;
  const match = link.match(regex);
  return match ? parseInt(match[1]) : null;
}

// Utility function to parse PARCEL_NUM from countyLink
function parseParcelNum(link) {
  const regex = /PARCEL_NUM=([^&]+)/;
  const match = link.match(regex);
  return match ? match[1] : null;
}

// Utility function to determine new link based on search_by value
function getNewLink(countyData, parcelNum, originalLink) {
    switch (countyData.search_by) {
      case "ADDRESS":
        const xpathZillowAddress = '/html/body/div[1]/div[6]/div[1]/div[1]/div/div/div[1]/div/div/div[1]/div[2]/div[2]/div[2]/div/div[1]/div[2]/h1';
        const zillowAddress = document.evaluate(xpathZillowAddress, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.innerText;
        const partialAddress = zillowAddress.split(",")[0].trim();
        navigator.clipboard.writeText(partialAddress);
        return countyData.link;
  
      case "PARCEL NUMBER":
        if (parcelNum) {
          navigator.clipboard.writeText(parcelNum);
        }
        return countyData.link;
  
      case "DIRECT":
        return originalLink;
  
      case "QUERY PARCEL NUMBER":
        if (parcelNum) {
          return `${countyData.link}${parcelNum}`;
        }
        return countyData.link;
  
      default:
        return countyData.link;
    }
  }

// Execute the countyBlock function when the webpage loads
window.addEventListener("load", countyBlock);
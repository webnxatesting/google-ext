//Check if "Begin Captcha" button exists
window.onload = function() {
    var btn = document.getElementById("amzn-captcha-verify-button");
    if(btn !== null) {
        setTimeout(function(){
            btn.click();
        }, 500);
    }
};

// read url and save it to url var
let url = window.location.href;
//if url contains captchaPerimeterX then do something

let counter


function modifyCaptchaURL () {
    if (url.includes("captchaPerimeterX")) {
    var newUrl = url.replace(/^.*?\?url=(.*?)&.*$/, "$1");
    newUrl = newUrl.replace(/%2f/g, '/');
    newUrl = "https://zillow.com" + newUrl;
    
    setTimeout(function() {
        location.replace(newUrl);
    },Math.floor(Math.random() * 2000));
}
}
///////////////////////////
// modifyCaptchaURL() after waiting for counter to reach 1
// and add 1 to counter in the chrome.storage.local
function executeModifyCaptchaURL () {
  setTimeout(function() {
      chrome.storage.local.get(['counter'], function(result) {
          result.counter = result.counter + 1;
          counter = result.counter;
          console.log("Counter: " + counter);
          chrome.storage.local.set({counter: counter}, function() {
              modifyCaptchaURL();
          });
      });
  }, 100);
}

// check if counter is = 5 or url doesn't include captchaPerimeterX
// and reset counter to 0
function resetCounter () {
  setTimeout(function() {
      chrome.storage.local.get(['counter'], function(result) {
          if (result.counter === 5 || !url.includes("captchaPerimeterX")) {
              result.counter = 0;
              counter = result.counter;
              console.log("Counter: " + counter);
              chrome.storage.local.set({counter: counter}, function() {
                  if (url.includes("captchaPerimeterX")) {
                      modifyCaptchaURL();
                  }
              });
          }
      });
  }, 100);
}

//set counter to 1 if url includes "captchaPerimeterX"
function setCounter () {
  if (url.includes("captchaPerimeterX")) {
      chrome.storage.local.set({counter: 1}, function() {
          counter = 1;
          console.log("Counter: " + counter);
          resetCounter();
          executeModifyCaptchaURL();
      });
  }
}


setCounter();


///////////////////////////
var bodyCaptcha = document.getElementById("captcha-container");

var observerCapcha = new MutationObserver(function (mutations) {
  if (mutations.length != 0) {
    // console.log("There's a change in node");
    console.log(mutations);
    console.log(mutations[0].target.innerText);
    setTimeout(function () {
      // console.log(mutations[0].target.innerText);
      // console.log(mutations[0].target.innerText.includes("Slide the image"));
      if (mutations[0].target.innerText.includes("Slide the image") || mutations[0].target.innerText.includes("rompecabezas")) {
        console.log("I'm here");
        window.location.reload();
      }
      if (mutations[0].target.innerText.includes("Incorrect")) {
        console.log("I'm there");
        window.location.reload();
      }
    }, 500);
  }
});

observerCapcha.observe(bodyCaptcha, {
  childList: true,
  attributes: true,
  subtree: true,
});
//Code prepared in case Five9 fixes the info of the incoming messages
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
  if (request.type === "create_notification") {
    const { campaign, sd_last_disposition, photo_url, name, agentTeam } =
      request.data;

    const notificationOptions = {
      type: "basic",
      iconUrl: photo_url,
      title: `${sd_last_disposition}!!!`,
      message: `${name}\nTeam: ${agentTeam} \n\nCampaign: ${campaign}`,
    };

    chrome.notifications.create(notificationOptions);
    
    chrome.notifications.onClosed.addListener(function(){
        chrome.notifications.clear();
        setTimeout(function() {
            chrome.notifications.block();
        }, 15000);
    });
  }
});

//temporary code until Five9 fixes the data of the lead notifications

// chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
//   if (request.type === "create_notification") {
//     const { campaign, sd_last_disposition, photo_url, name, agentTeam } =
//       request.data;

//     const notificationOptions = {
//       type: "basic",
//       iconUrl: photo_url,
//       title: `${sd_last_disposition}!!!`,
//       message: `\nTeam: ${agentTeam} \n\nCampaign: ${campaign}`,
//     };

//     chrome.notifications.create(notificationOptions);
    
//     chrome.notifications.onClosed.addListener(function(){
//         chrome.notifications.clear();
//         setTimeout(function() {
//             chrome.notifications.block();
//         }, 15000);
//     });
//   }
// });



//import { initializeApp } from './firebase_local/9.9.0/firebase-app.js';
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.9.0/firebase-app.js";
//import { getAuth, onAuthStateChanged } from "./firebase_local/9.9.0/firebase-auth.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/9.9.0/firebase-auth.js";
//import { getFirestore, collection, query, where, getDocs } from "./firebase_local/9.9.0/firebase-firestore.js";
import { getFirestore, collection, doc, setDoc, addDoc, getDocs } from "https://www.gstatic.com/firebasejs/9.9.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAJK-PZxO1W8JN5EpxQL1CbQhxxQTaOnUI",
  authDomain: "lamassu-affiliates.firebaseapp.com",
  projectId: "lamassu-affiliates",
  storageBucket: "lamassu-affiliates.appspot.com",
  messagingSenderId: "604840466188",
  appId: "1:604840466188:web:33de69873b0605431d9b29"
};

const firebaseConfigRebuttals = {
  apiKey: "AIzaSyAqGdqGaoQFeVYlhMuZjRu3rvyB9aJiiiQ",
  authDomain: "lamassu-rebuttals.firebaseapp.com",
  projectId: "lamassu-rebuttals",
  storageBucket: "lamassu-rebuttals.appspot.com",
  messagingSenderId: "109189807020",
  appId: "1:109189807020:web:f23a4eab1df522ee4ed809"
};

const app = initializeApp(firebaseConfigRebuttals);
const db = getFirestore(app);
const auth = getAuth(app);

/* const urlRebuttals = "https://jsonlmsu1.herokuapp.com/api?id=1DNFwXOUhETrqXuieP644GzIwXFY2ycWOecJ5HLBpKac&columns=false&&sheet=rebuttals#";
const urlPhrases = "https://jsonlmsu1.herokuapp.com/api?id=1DNFwXOUhETrqXuieP644GzIwXFY2ycWOecJ5HLBpKac&columns=false&&sheet=phrases#"; */

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.command){
    case "list": {
      getDocs(collection(db, request.collection))
        .then((querySnapshot) => {
          let list = querySnapshot.docs
            .map(qds => qds.data());
          sendResponse(list);
        });
      return true;
    }
    /* case "rebuttals": {
      fetch(urlRebuttals).then((response) => response.json()).then((data) => {
        sendResponse(data);
      });
    }
    case "phrases": {
      fetch(urlPhrases).then((response) => response.json()).then((data) => {
        sendResponse(data);
      });
    } */
  }
  return true;
});
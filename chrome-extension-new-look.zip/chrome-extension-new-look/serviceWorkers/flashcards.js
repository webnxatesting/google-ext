//const urlRebuttals = "https://jsonlmsu1.herokuapp.com/api?id=1DNFwXOUhETrqXuieP644GzIwXFY2ycWOecJ5HLBpKac&columns=false&&sheet=rebuttals#";
//const urlPhrases = "https://jsonlmsu1.herokuapp.com/api?id=1DNFwXOUhETrqXuieP644GzIwXFY2ycWOecJ5HLBpKac&columns=false&&sheet=phrases#";

const urlPhrases = "https://sheets.googleapis.com/v4/spreadsheets/1DNFwXOUhETrqXuieP644GzIwXFY2ycWOecJ5HLBpKac/values/phrases?alt=json&key=AIzaSyAjb-bx_ucVlJ3JzgM--kpR8X6aHAarEv8";
const urlRebuttals = "https://sheets.googleapis.com/v4/spreadsheets/1DNFwXOUhETrqXuieP644GzIwXFY2ycWOecJ5HLBpKac/values/rebuttals?alt=json&key=AIzaSyAjb-bx_ucVlJ3JzgM--kpR8X6aHAarEv8";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.command){
    case "rebuttals": {
        chrome.storage.local.get(["flashcardRebuttalsDB"], function(data){
            if (typeof data.flashcardRebuttalsDB === "undefined"){
                fetch(urlRebuttals).then((response) => response.json()).then((data) => {
                    chrome.storage.local.set({"flashcardRebuttalsDB" : data.values});
                    sendResponse(data.values);
                });
            } else {
                if ( data.flashcardRebuttalsDB.length > 0 ) {
                    sendResponse(data.flashcardRebuttalsDB);
                } else {
                    fetch(urlRebuttals).then((response) => response.json()).then((data) => {
                        chrome.storage.local.set({"flashcardRebuttalsDB" : data.values});
                        sendResponse(data.values);
                    });
                }
            }
        });
    }
    case "phrases": {
        chrome.storage.local.get(["flashcardPhrasesDB"], function(data){
            if (typeof data.flashcardPhrasesDB === "undefined"){
                fetch(urlPhrases).then((response) => response.json()).then((data) => {
                    chrome.storage.local.set({"flashcardPhrasesDB" : data.values});
                    sendResponse(data.values);
                });
            } else {
                if ( data.flashcardPhrasesDB.length > 0 ) {
                    sendResponse(data.flashcardPhrasesDB);
                } else {
                    fetch(urlPhrases).then((response) => response.json()).then((data) => {
                        chrome.storage.local.set({"flashcardPhrasesDB" : data.values});
                        sendResponse(data.values);
                    });
                }
            }
        });
    }
  }
  return true;
});
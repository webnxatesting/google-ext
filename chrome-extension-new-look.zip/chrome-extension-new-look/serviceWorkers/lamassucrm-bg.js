chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    // Check if the message contains the expected data
    if (request.message === 'fullAddress') {
        // Access the request.url property and perform further processing
        let fullAddress = request.url;

const getZestimateFromTab = () => {
    return document.querySelector('span[class="Text-c11n-8-84-0__sc-aiai24-0 eIEmla"] span').innerText;
}

chrome.tabs.query({}, function(tabs) {
    let found = false;
    let tabId;
    let fullAddress = request.url;

    tabs.forEach(function(tab) {
        let tabUrl = tab.url;
        if (tabUrl.includes('zillow.com/home') || tabUrl.includes('redfin.com') || tabUrl.includes('realtor.com')) {
            let tabTitle = tab.title;
            tabTitle = tabTitle.replace(' | Zillow', '').replace(' | Redfin', '').replace(' | realtor.com®', '');
            let similarity = calculateSimilarity(fullAddress, tabTitle);
            if (similarity >= 90) {
                found = true;
                tabId = tab.id;
            }
        }
    });

    if (tabId) {
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: getZestimateFromTab
        }).then(injectionResults => {
            let zestimate = injectionResults[0].result;
            sendResponse({ found: found, zestimate: zestimate });
        });
    } else {
        // Handle the case when no matching tab is found
        sendResponse({ found: false, zestimate: null });
    }
});

function calculateSimilarity(fullAddress, tabTitle) {
    let similarLetters = 0;
    for (let i = 0; i < fullAddress.length; i++) {
        if (fullAddress[i] === tabTitle[i])
            similarLetters++;
    }

    const similarity = (similarLetters / fullAddress.length) * 100;
    return similarity;
}

}
});


/////////// Adjust Zoom levels on lamassucrm.com when portview is less than 700px width
// Listen for the window resize event
// Function to adjust zoom level based on window width
// Monitor tab updates
// Function to handle zoom level based on window width
const setZoomLevel = (tabId, width) => {
    let zoomLevel;
    
    if (width < 700) {
      zoomLevel = 0.75;
    } else if (width < 800) {
      zoomLevel = 0.85;
    } else {
      return; // Exit if the width is more than 800px
    }
    
    // Set the zoom level for the given tab
    chrome.tabs.setZoom(tabId, zoomLevel);
  };
  
  // Listen for tab URL changes
  chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.url) {
      const url = changeInfo.url;
      // Check if the URL matches the condition
      if (url.includes("lamassucrm.com/lamassu_leadcapture.php")) {
        // Get the window's size
        chrome.windows.get(tab.windowId, {populate: true}, (window) => {
          setZoomLevel(tabId, window.width);
        });
      }
    }
  });
  
  // Listen for window resize events
  chrome.windows.onBoundsChanged.addListener((window) => {
    chrome.tabs.query({active: true, windowId: window.id}, (tabs) => {
      const activeTab = tabs[0];
      const url = activeTab.url;
  
      // Check if the URL matches the condition
      if (url && url.includes("lamassucrm.com/lamassu_leadcapture.php")) {
        setZoomLevel(activeTab.id, window.width);
      }
    });
  });
  
//Auto close slackchannel links when they're opened with slack-links-new.js
function queryTabs() {
  chrome.tabs.query({}, function(tabs) {
    tabs.forEach(function(tab) {
      parseTabs(tab.url, tab.id);
    });
  });
}

chrome.tabs.onUpdated.addListener(function(id) {
  chrome.tabs.get(id, function(tabs) {
      if (tabs !== undefined) parseTabs(tabs.url, tabs.id);
  });
});

chrome.tabs.onCreated.addListener(function(tabs) {
  parseTabs(tabs.url, tabs.id);
});

function parseTabs(url, id) {
  if (url.includes("https://lamassumedia.slack.com/archives/" || "https://lamassumedia.slack.com/channels/")) {
    setTimeout(() => {
      chrome.tabs.remove(id);
    }, 10000);
  }
}

//Sends press ctrl+alt+d event to the active tab
// chrome.runtime.onMessage.addListener(function(message,sender,sendResponse){
//   if(message.pressCtrlAltD){
//       chrome.tabs.query({active: true}, function(tabs) {
//           chrome.debugger.attach({ tabId: tabs[0].id }, "1.2");
//           chrome.debugger.sendCommand({ tabId: tabs[0].id }, 'Input.dispatchKeyEvent', { type: 'keyDown', windowsVirtualKeyCode:17, nativeVirtualKeyCode : 17, macCharCode: 17  });
//           chrome.debugger.sendCommand({ tabId: tabs[0].id }, 'Input.dispatchKeyEvent', { type: 'keyDown', windowsVirtualKeyCode:18, nativeVirtualKeyCode : 18, macCharCode: 18  });
//           chrome.debugger.sendCommand({ tabId: tabs[0].id }, 'Input.dispatchKeyEvent', { type: 'keypress', windowsVirtualKeyCode:68, nativeVirtualKeyCode : 68, macCharCode: 68  });
//           console.log("Ctrl+Alt+D pressed from background");
//           chrome.debugger.sendCommand({ tabId: tabs[0].id }, 'Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode:68, nativeVirtualKeyCode : 68, macCharCode: 68  });
//           chrome.debugger.sendCommand({ tabId: tabs[0].id }, 'Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode:18, nativeVirtualKeyCode : 18, macCharCode: 18  });
//           chrome.debugger.sendCommand({ tabId: tabs[0].id }, 'Input.dispatchKeyEvent', { type: 'keyUp', windowsVirtualKeyCode:17, nativeVirtualKeyCode : 17, macCharCode: 17  });
//           chrome.debugger.detach({ tabId: tabs[0].id });
//       });
//   }
// });


/*
The following function is to help avoid lost of data when installing a new update of the extension to the user.
Before this, when an update was installed, we needed to manually duplicate any webform tab that the agent had opened so the info in the input is not erased.
*/
// Listen for the onInstalled event and execute the callback function
chrome.runtime.onInstalled.addListener(function() {
  // Get all open tabs
  chrome.tabs.query({}, function(tabs) {
    // Filter the tabs to only include ones from the synergycrm.io domain
    var synergyTabs = tabs.filter(tab => tab.url.includes("lamassucrm.com"));
	
	// Filter the tabs to only include ones from the five9.com domain
	var five9Tabs = tabs.filter(tab => tab.url.includes("five9.com/clients/agent/main.html"));

    // Wait 1 second
    setTimeout(function() {
      // Duplicate each tab
      synergyTabs.forEach(function(tab) {
        chrome.tabs.duplicate(tab.id);
      });
	  
	  // Refresh each tab
      five9Tabs.forEach(function(tab) {
        chrome.tabs.reload(tab.id);
      });

      // Wait another second
      setTimeout(function() {
        // Close the original tabs
        synergyTabs.forEach(function(tab) {
          chrome.tabs.remove(tab.id);
        });
      }, 1000);
    }, 1000);
  });
});


// reads the version number from the manifest and sets it as the badge text.
// Get the manifest details
const manifestData = chrome.runtime.getManifest();
const versionText = manifestData.version;

// Function to set the badge details
function setBadgeDetails() {
    // Set the badge text
    chrome.action.setBadgeText({ text: versionText });

    // Optionally, set the badge background color
    chrome.action.setBadgeBackgroundColor({ color: '#4688F1' });
    chrome.action.setBadgeTextColor({ color: '#FFFFFF' });
}

// Listen for when the extension is first installed, updated, or Chrome is updated
chrome.runtime.onInstalled.addListener((details) => {
    setBadgeDetails();
});

// Listen for when Chrome starts up
chrome.runtime.onStartup.addListener(() => {
    setBadgeDetails();
});
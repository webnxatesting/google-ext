"use strict";

describe("activitySpec", function() {
  describe("toOutboundSpec", function() {
    it ("test campaign is undefined", function() {
      expect(() => toOutbound(undefined)).toThrowMatching(
        thrown => thrown.message === "campaign was undefined");
    });

    it ("test campaign is null", function() {
      expect(() => toOutbound(null)).toThrowMatching(
        thrown => thrown.message === "campaign was null");
    });

    it ("test campaing is not string", function() {
      const arg = { value: "campaign" };
      expect(() => toOutbound(arg)).toThrowMatching(
        thrown => thrown.message === "campaign was not string");
    });

    it ("test campaign is empty", function() {
      const arg = "";
      expect(toOutbound(arg)).toBe("");
    });

    it ("test campaign contains _INBOUND", function() {
      const arg = "MY_INBOUND";
      expect(toOutbound(arg)).toBe("MY_OUTBOUND");
    });

    it ("test campaign contains _OUTBOUND", function() {
      const arg = "MY_OUTBOUND";
      expect(toOutbound(arg)).toBe("MY_OUTBOUND");
    });

    it ("test campaign is without Suffix", function() {
      const arg = "BARRINGTON";
      expect(toOutbound(arg)).toBe("BARRINGTON_OUTBOUND");
    });
  });
});
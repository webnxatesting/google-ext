describe("five9Spec", function() {

  describe("extractNumberSpec", function() {
    it ("test null", function() {
      const phone = null;
      expect(extractNumbers(phone)).toBe("");
    });

    it ("test undefined", function() {
      const phone = undefined;
      expect(extractNumbers(phone)).toBe("");
    });

    it ("test empty string", function() {
      const phone = "";
      expect(extractNumbers(phone)).toBe("");
    });

    it ("test phone number with different characters", function() {
      const phone = "(321) 804-2376";
      expect(extractNumbers(phone)).toBe("3218042376");
    });

    it ("test phone number with pure numbers", function() {
      const phone = "3218042376";
      expect(extractNumbers(phone)).toBe("3218042376");
    });

    it  ("test phone number with different characters 2", function() {
      const phone = "3218042376 (Primary)";
      expect(extractNumbers(phone)).toBe("3218042376");
    });
  });

  describe("SectionChangingSpec", function() {
    function fakedExtObserver() {
      let modalObserver = fakedObserver();
      let sectionObserver = fakedObserver();
      sectionObserver.modalObserver = modalObserver;
      sectionObserver.message = undefined;
      return sectionObserver;
    }

    function fakedObserver() {
      return {
        observedElement: undefined,
        options: undefined,
        disconnected: true,

        observe: function (element, options) {
          this.observedElement = element;
          this.options = options;
          this.disconnected = false;
        },

        disconnect: function () {
          this.observedElement = undefined;
          this.options = undefined;
          this.disconnected = true;
        }
      };
    }

    function createFakedListener(fakedObserver) {
      const urlState = () => urlInActivity.value;
      return createStateSection(
        fakedObserver,
        element,
        modal,
        urlState);
    }

    const element = {
      html: "element is observed"
    };

    const modal = {
      html: "modal is observed"
    };

    const urlInActivity = {
      value: undefined
    };

    let extObserver;
    let listener;

    beforeEach(function () {
      extObserver = fakedExtObserver();
      listener = createFakedListener(extObserver);
      urlInActivity.value = undefined;
    });


    it ("test start observer", function() {
      urlInActivity.value = true;
      listener();

      expect(false).toBe(extObserver.disconnected);
      expect(false).toBe(extObserver.modalObserver.disconnected);
      expect(element.html).toBe(extObserver.observedElement.html);
      expect(modal.html).toBe(extObserver.modalObserver.observedElement.html);
    });

    it ("test stop observer", function() {
      urlInActivity.value = true;
      listener();
      urlInActivity.value = false;
      listener();

      expect(true).toBe(extObserver.disconnected);
      expect(true).toBe(extObserver.modalObserver.disconnected);
      expect(undefined).toBe(extObserver.observedElement);
      expect(undefined).toBe(extObserver.modalObserver.observedElement);
    });

    it ("test After Stop message is cleared", function() {
      urlInActivity.value = true;
      extObserver.message = {campaign: "MY_OUTBOUND"};
      listener();
      urlInActivity.value = false;
      listener();

      expect(undefined).toBe(extObserver.message);
    });
  });
});
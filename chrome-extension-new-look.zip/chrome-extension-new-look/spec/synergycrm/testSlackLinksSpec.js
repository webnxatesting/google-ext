"use strict";

describe("slackLinksSpec", function() {
  let subdomain = {value: ""};
  const mySubdomain = () => subdomain.value;
  
  nonGenericSlackRoom = subdomain => {
    let slackRooms = {
      core: "st-louis-closer-needed",
      corekc: "kansas-city-core-closer-needed",
      solval: "solv-closer-needed"
    };
    return slackRooms[subdomain];
  };

  nonGenericCampaignNames = subdomain => {
    let campaigns = {
      core: "CORE",
      corekc: "CORE KC",
      solval: "SOLV AL"
    };
    return campaigns[subdomain];
  };

  describe("campaignSpec", function() {

    function _campaign() {
      return campaign(mySubdomain);
    }

    it ("test subdomain is undefined", function() {
      subdomain.value = undefined;
      expect(_campaign).toThrowMatching(
        thrown => thrown.message === "subdomain was undefined");
    });
    
    it ("test subdomain is null", function() {
      subdomain.value = null;
      expect(_campaign).toThrowMatching(
        thrown => thrown.message === "subdomain was null");
    });

    it ("test subdomain is not string", function() {
      subdomain.value = {myValue: "royal"};
      expect(_campaign).toThrowMatching(
        thrown => thrown.message === "subdomain was not string");
    });

    it ("test subdomain is empty", function() {
      subdomain.value = "";
      expect(_campaign).toThrowMatching(
        thrown => thrown.message === "subdomain was empty");
    });

    it ("test subdomain is royal", function() {
      subdomain.value = "royal";
      expect(_campaign()).toBe("royal");
    });

    it ("test subdomain is core", function() {
      subdomain.value = "core";
      expect(_campaign()).toBe("CORE");
    });
  });


  describe("slackRoomSpec", function() {
    function _slackRoom() {
      return slackRoom(mySubdomain);
    }

    it ("test subdomain is undefined", function() {
      subdomain.value = undefined;
      expect(_slackRoom).toThrowMatching(
        thrown => thrown.message === "subdomain was undefined");
    });
    
    it ("test subdomain is null", function() {
      subdomain.value = null;
      expect(_slackRoom).toThrowMatching(
        thrown => thrown.message === "subdomain was null");
    });

    it ("test subdomain is not string", function() {
      subdomain.value = {myValue: "royal"};
      expect(_slackRoom).toThrowMatching(
        thrown => thrown.message === "subdomain was not string");
    });

    it ("test subdomain is empty", function() {
      subdomain.value = "";
      expect(_slackRoom).toThrowMatching(
        thrown => thrown.message === "subdomain was empty");
    });

    it ("test subdomain is royal", function() {
      subdomain.value = "royal";
      expect(_slackRoom()).toBe("royal-closer-needed");
    });

    it ("test subdomain is core", function() {
      subdomain.value = "core";
      expect(_slackRoom()).toBe("st-louis-closer-needed");
    });
  });


  describe("slackChatRoomUrlSpec", function() {
    function _slackChatRoomUrl() {
      return slackChatRoomUrl(mySubdomain);
    }

    it ("test subdomain is royal", function() {
      subdomain.value = "royal";
      expect(_slackChatRoomUrl())
        .toBe("https://lamassumedia.slack.com/channels/royal-closer-needed");
    });

    it ("test subdomain is core", function() {
      subdomain.value = "core";
      expect(_slackChatRoomUrl())
        .toBe("https://lamassumedia.slack.com/channels/st-louis-closer-needed");
    });
  });
});
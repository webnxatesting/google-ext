"use strict";

describe("eventsSpec", function() {

  describe("registerSpec", function() {

    it ("test no template found", function () {
      const register = () => {
        const empty = {};
        const domNode = {};
        registerHtmlTemplate(empty, domNode);
      };
      expect(register).toThrowMatching(
        thrown => thrown.message === "No template property found");
    });

    it ("test no model found", function () {
      const register = () => {
        const missingModel = {template: "<div></div>"};
        const domNode = {};
        registerHtmlTemplate(missingModel, domNode);
      };
      expect(register).toThrowMatching(
        thrown => thrown.message === "No model property found");
    });

    it ("test template written to innerHtml", function () {
      const templateObj = {
        template: "<div></div>",
        model: function () {
          const self = this;
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      expect(domNode.innerHTML).toBe(templateObj.template);
    });

    it ("test modelObj created", function () {
      const templateObj = {
        template: "<div></div>",
        model: function () {
          const self = this;
          self.testVariable = "testing variable";
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      expect(domNode.modelObj).not.toBe(undefined);
      expect(domNode.modelObj.testVariable).toBe("testing variable");
    });

    it ("test one placeholder in text node", function () {
      const templateObj = {
        template: "<div>{{myVariable}}</div>",
        model: function () {
          const self = this;
          self.myVariable = "Hello";
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      expect(domNode.innerText).toBe("Hello");
    });

    it ("test one placeholder in deeper text node", function () {
      const templateObj = {
        template: `
          <div>
            <span id='first'>{{myVariable}}</span>
            <div>
              <span id='second'>{{myVariable}}</span>
            </div>
          </div>
        `,
        model: function () {
          const self = this;
          self.myVariable = "Hello";
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      expect(domNode.querySelector("#first").innerText).toBe("Hello");
      expect(domNode.querySelector("#second").innerText).toBe("Hello");
    });
  });

  describe("registerSpec manipulating data", function() {

    it ("test one variable", function () {
      const templateObj = {
        template: `
          <div>
            <span id='first'>{{myVariable}}</span>
          </div>
        `,
        model: function () {
          const self = this;
          self.myVariable = "Hello";
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      expect(domNode.querySelector("#first").innerText).toBe("Hello");
      domNode.modelObj.myVariable = "Hello, World";
      expect(domNode.querySelector("#first").innerText).toBe("Hello, World");
    });

    it ("test variable multiple times marked", function () {
      const templateObj = {
        template: `
          <div>
            <span id='first'>{{myVariable}} - {{myVariable}}</span>
          </div>
        `,
        model: function () {
          const self = this;
          self.myVariable = "Hello";
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      expect(domNode.querySelector("#first").innerText).toBe("Hello - Hello");
      domNode.modelObj.myVariable = "World";
      expect(domNode.querySelector("#first").innerText).toBe("World - World");
    });

    it ("test multiple variables in one text", function () {
      const templateObj = {
        template: `
          <div>
            <span id='first'>{{myVar1}}, {{myVar2}}, {{myVar1}}, {{myVar2}}</span>
          </div>
        `,
        model: function () {
          const self = this;
          self.myVar1 = 1;
          self.myVar2 = 2;
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      expect(domNode.querySelector("#first").innerText).toBe("1, 2, 1, 2");
      domNode.modelObj.myVar2 = "Hello";
      expect(domNode.querySelector("#first").innerText).toBe("1, Hello, 1, Hello");
    });
  });

  describe("registerSpec with functions as members", function() {
    it ("test one variable", function () {
      const templateObj = {
        template: `
          <div>
            <span id='first'>{{myVariable}}</span>
          </div>
        `,
        model: function () {
          const self = this;

          self.func = function () {
            self.myVariable = "Hello";
            return 0;
          };
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      expect(domNode.querySelector("#first").innerText).toBe("{{myVariable}}");
      domNode.modelObj.func();
      expect(domNode.querySelector("#first").innerText).toBe("Hello");
    });

    it ("test onInit function as member", function () {
      const templateObj = {
        template: `
          <div>
            <span id='first'>{{myVariable}}</span>
          </div>
        `,
        model: function () {
          const self = this;

          self.onInit = function () {
            self.myVariable = "Hello";
            return 0;
          };
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      expect(domNode.querySelector("#first").innerText).toBe("Hello");
    });
  });

  describe("registerSpec with widgets", function () {

    it ("test select widget reading options", function () {
      const templateObj = {
        template: `
          <div>
            <select id='first' [change]='onChangeEvent' options='myVariable'></select>
            <select id='second' [change]='onChangeEvent' options='myVariable2'></select>
          </div>
        `,
        model: function () {
          const self = this;
            self.myVariable = [
              {text:"option1", value:1},
              {text:"option2", value:2},
              {text:"option3", value:3},
            ];

          self.onInit = function () {
            self.myVariable2 = [
              {text:"option1", value:1},
              {text:"option2", value:2},
              {text:"option3", value:3},
            ];
          };

          self.onChangeEvent = function (evt) {
            // TODO:
            // should be registered, dont know how to test the event.
            self.changePassed = true;
          };
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      const select = domNode.querySelector("#first");
      expect(select.options.length).toBe(3);
      const select2 = domNode.querySelector("#second");
      expect(select2.options.length).toBe(3);
      // select2.options.item(0).click();
      // console.log(select2.options.item(0));
      // expect(domNode.modelObj.changePassed).toBe(true);
    });

    it ("test input text with out attribute", function () {
      const templateObj = {
        template: `
          <div>
            <input id='first' out='myVariable1'>
            <input id='second' out='myVariable2'>
          </div>
        `,
        model: function () {
          const self = this;
          self.myVariable1 = "Hello";

          self.onInit = function () {
            self.myVariable2 = "World";
          };
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      const input1 = domNode.querySelector("#first");
      const input2 = domNode.querySelector("#second");
      expect(input1.value).toBe("Hello");
      expect(input2.value).toBe("World");
    });
  });

  describe ("registerSpec with classes", function () {

    it ("test classes", function () {
      const templateObj = {
        template: `
          <div>
            <span id="first" class='first' [class]='myClass'>Hello, Wolrd</span>
          </div>
        `,
        model: function () {
          const self = this;

          self.onInit = function () {
            self.myClass = {
              second:true,
              third:true
            };
          };
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      let span = domNode.querySelector("#first");
      expect([...span.classList]).toEqual(["first","second","third"]);
    });

    it ("test classes removing token", function () {
      const templateObj = {
        template: `
          <div>
            <span id="first" class='first' [class]='myClass'>Hello, Wolrd</span>
          </div>
        `,
        model: function () {
          const self = this;

          self.onInit = function () {
            self.myClass = {
              second:true,
              third:true
            };
          };
        }
      };
      const domNode = document.createElement("div");
      registerHtmlTemplate(templateObj, domNode);
      let span = domNode.querySelector("#first");
      expect([...span.classList]).toEqual(["first","second","third"]);
      domNode.modelObj.myClass = {second:true,third:false};
      expect([...span.classList]).toEqual(["first","second"]);
    });
  });

  describe ("registerSpec with dependencies", function () {

    it ("test input as dependency", function () {
      const templateObj = {
        template: `
          <div></div>
        `,

        dependencies: [
          {
            selector: "#myInput",
            event: "keyup",
            callback: "keyupEvent"
          }
        ],

        model: function () {
          const self = this;

          self.keyupEvent = function (evt) {
            self.registered = "eventListener";
          };
        }
      };
      const domNode = document.createElement("div");
      const myInput = document.createElement("input");
      myInput.id = "myInput";
      const templateNode = document.createElement("div");
      domNode.appendChild(myInput, templateNode);
      registerHtmlTemplate(templateObj, templateNode, domNode);
      myInput.dispatchEvent(new KeyboardEvent("keyup"));
      expect(templateNode.modelObj.registered).toBe("eventListener");
    });

    it ("test input as dependency with name", function () {
      const templateObj = {
        template: `
          <div></div>
        `,

        dependencies: [
          {
            selector: "#myInput",
            event: "keyup",
            name: "myInputWidget",
            callback: "keyupEvent"
          }
        ],

        model: function () {
          const self = this;
        }
      };
      const domNode = document.createElement("div");
      const myInput = document.createElement("input");
      myInput.id = "myInput";
      const templateNode = document.createElement("div");
      domNode.appendChild(myInput, templateNode);
      registerHtmlTemplate(templateObj, templateNode, domNode);
      expect(templateNode.modelObj.myInputWidget).toEqual(myInput);
    });
  });
});